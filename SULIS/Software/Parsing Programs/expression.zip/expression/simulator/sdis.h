#ifndef   SDISHEADER
/*
        sdis.h

*/

#define  SDISHEADER
#include "sim.h"

void Disassemble( INSTRUCTION *inst, char *buffer );
#endif
