##==============================================================================
##
## slr.py
##
## A Python program that builds the LR0 CFSM and the corresponding Action
## and GoTo tables for an SLR grammar.  It inherits its basic capabilities,
## such as the ability to construct the LR0 CFSM, from its superclass,
## 'LR0Machine'.
##
## Use:
##
##     >>> from grammars import *    ## <-- Get some grammar definitions.
##     >>> slrg1=SLRMachine(G1)      ## <-- Create an SLR automation for G1.
##     >>> slrg1.displayCFSM()       ## <-- Show the LR(0) CFSM for G1.
##     >>> slrg1.displayAction()     ## <-- Show the SLR Action table for G1.
##     >>> slrg1.displayGoTo()       ## <-- Show the SLR GoTo table for G1.
##     >>> slrg1.parse('a b b a')    ## <-- Parse an input string, displaying
##                                   ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, 'abab' would be scanned as the single
## token 'abba', not the four tokens 'a', 'b', 'b', 'a'.
##
##
##     >>> slrg1.outputDot('s.dot')  ## <-- Output a description of the CFSM 
##                                   ##     of this SLR automaton to file 
##                                   ##     's.dot' in a form suitable for
##                                   ##     processing by 'dot -Tps2'.
##
##
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      SLRMachine -- This represents the SLR recogniser for a given
##                    grammar.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  This flag argument
##              defaults to True.
##
##          buildCFSM.  Builds the CFSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##              (This method is inheritied from base class "LR0Machine".)
##
##          displayCFSM.  Outputs the CFSM in "pretty-printed" style.
##
##          checkSLR.  Checks to see if the CFSM built by 'buildCFSM' is
##              in fact, SLR, i.e., that it does not contain any inadequate
##              states which cannot be resolved by single-token lookahead
##              (using global follow sets for lookahead on reduce items)
##              Called automatically by constructor.
##
##          genActions.  Generates the Action table for an SLR automaton
##              from its CFSM and the Follow sets of the grammar
##              nonterminals. Called automatically by constructor.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          displayActions.  Displays the LALR(1) Action table 
##              associated with this LALR(1) automaton in "pretty-printed"
##              tabular style.
##              Calls implementation in abstract base class LRBase.
##
##          genGoTo.  Generates the GoTo table for an LR(0) automaton
##              from its CFSM. Called automatically by constructor.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          displayGoTo.  Displays the GoTo table associated with
##              this CFSM in "pretty-printed" tabular style.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this SLRMachine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(0) CFSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.  Note that this version
##              of "genDot" shows lookahead associated with Reduce Items,
##              and identifies SLR inadequate states of the CFSM (this
##              is what distinguishes it from "genDot" from the base
##              class LR0Machine, which generates the LR(0) CFSM of an
##              automation, showing LR(0) inadequate Items and no
##              lookahead).
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(0) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG.
##              This method is inheritied from parent class LR0Machine.
##
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
## LR(0) Items (dotted prodictions) are represented as tuples, the first
## element of the tuple indexing into the grammar associated with the item,
## giving the production, and the second element being the position of the
## "dot" (virtual read-head) in the item.  So, given a grammar
##
##      <Aug> --> S $          (0)   <-- "augmenting" production
##      S     --> A B B A      (1)
##            .
##            .
##
## then the tuple (1,2) represents the item [S --> A B _ B A], with the
## 'dot' (here represented by an underscore) before the third element
## of the production's right-hand-side.
##
## Why as a tuple? Because in Python we can have sets of tuples (needed
## or the LR(0) state, which is a set of items. Class "LR0State" encapsulates
## an item set and various utility routines associated with LR(0) state
## creation and manipulation (e.g., closure, finding transitions out of an
## LR(0) state, etc.).
##
##------------------------------------------------------------------------------
##
##

from defs import Production, isterminal, isnonterminal, \
     findallsyms, augmentGrammar, formatSetAsHtml
from grammars import genHtmlGrammar
from lrbase import LRBase
from lr0 import LR0Machine, LR0State, getDottedSym, formatItem, formatItemAsHtml
from ff import fill_follow_sets

##==============================================================================
##
## class SLRMachine -- This represents the SLR recogniser for a given
##      grammar.  Inherits from LR0Machine.
##
##      N.B. the grammar is quietly augmented before the CFSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##      --------
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Default to True.
##
##          buildCFSM.  Builds the CFSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).  (This method is
##              inheritied from base class "LR0Machine".)
##
##          displayCFSM.  Outputs the CFSM in "pretty-printed" style.
##               (This method is inheritied from base class "LR0Machine".)
##
##          genActions.  Generates the Action table for an SLR automaton
##               from its CFSM and the Follow sets of the grammar's
##               nonterminals (N.B., this is a 2-d table, indexed by
##               top-of-stack symbol and current lookahead. Called
##               automatically by constructor.  This method overrides
##               the version in base class "LR0Machine".
##
##          displayAction.  Displays the Action table associated with
##              this SLR automaton in "pretty-printed" tabular style.
##              This method overrides the version in base class "LR0Machine".
##
##          genGoTo.  Generates the GoTo table for an SLR automaton
##              from its CFSM. Called automatically by constructor.
##              (This method is inheritied from base class "LR0Machine".)
##
##          displayGoTO.  Displays the GoTo table associated with
##              this SLR automaton in "pretty-printed" tabular style.
##              (This method is inheritied from base class "LR0Machine".)
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this SLRMachine.  Displays operation
##              to terminal, showing each step of the parse.
##              (This method is inheritied from base class "LR0Machine".)
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(0) CFSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.  Note that this version
##              of "genDot" shows lookahead associated with Reduce Items,
##              and identifies SLR inadequate states of the CFSM (this
##              is what distinguishes it from "genDot" from the base
##              class LR0Machine, which generates the LR(0) CFSM of an
##              automation, showing LR(0) inadequate Items and no
##              lookahead).
##
##
##
##      Utility Methods needed by method 'parse' -- not for general use:
##      ----------------------------------------------------------------
##
##          lookupAction.  Looks up the next Action needed by method
##              'parse' based on the current top-of-stack at a
##              particular point in the parse.  This method overrides
##              the version in base class "LR0Machine".
##
##          rejectMessage.  Returns a string representing a 'Reject'
##              action coming from the Action table.  This should never
##              happen for an LR0Machine's Action table, and is an error
##              condition if it does, but is fine for an SLRMachine.
##              This method overrides the verison in base class
##              "LR0Machine".
##
##
##      Utility Methods needed by method 'genDot' -- not for general use:
##      -----------------------------------------------------------------
##
##          genDotHtmlforSLRstate.  Generates a GraphViz format string
##              representing a particular state of the SLR automaton
##              being processed by 'genDot'.
##
##
##          getSLRInadequateItems.  Returns the set of Items in a
##              particular state of this SLR machine which are
##              inadequate.
##
##
class SLRMachine(LR0Machine):
    "The SLR recogniser for a grammar."
    def __init__(this,grammar,verbose=True):
        this.grammar = augmentGrammar(grammar)  ## Note augmentation.
        this.cfsm = this.buildCFSM(verbose)     ## Build the CFSM.
        this.follow = fill_follow_sets(this.grammar) ## Generate the Follow sets.
        if verbose: print 35*"=="
        this.isSLR = this.checkSLR(verbose)
        if this.isSLR:
            this.actionTable = this.genActions()
            this.gotoTable = this.genGoTo()
        else:
            this.actionTable = None
            this.gotoTable = None

    ##----------------------------------------------------------------------
    ##
    ## checkSLR -- Check to see if the grammar is SLR-parsable.
    ##
    ## Assumes that the LR(0) CFSM for the grammar and the (global)
    ## follow sets for the nonterminals of the grammar have already been
    ## constructed and are available in "this.grammar" and "this.follow".
    ##
    ## Flag "verbose" (which defaults to True) controls printing of
    ## messages about the check to the output stream.
    ## If it is set to True, detailed progress information is displayed,
    ## including information about conflicts. If False, noting is displayed
    ## and the only feedback from the method is the True/False status of
    ## the check.
    ##
    def checkSLR(this,verbose=True):
        isSLR = True
        if verbose: print "SLR check\n========="
        for stateNum,lr0state in enumerate(this.cfsm):
            if verbose: print "Checking state %d" % stateNum
            shiftItems = []
            reduceItems = []
            for item in lr0state.kernel.union(lr0state.closure):
                lookahead = getDottedSym(item,this.grammar)
                if lookahead == 'eps':
                    productionNum = item[0]
                    nonterminal = this.grammar[productionNum].lhs
                    reduceItems.append((item,this.follow[nonterminal]))
                elif isterminal(lookahead):
                    shiftItems.append((item,lookahead))
            for reduceItem,reduceLookaheadSet in reduceItems:
                for shiftItem,shiftLookahead in shiftItems:
                    if shiftLookahead in reduceLookaheadSet:
                        isSLR = False
                        if verbose:
                            print "-------------------------------------------------"
                            print "CFRM State %d, shift-reduce conflict" % stateNum
                            print "  Item %s (shift on %s) conflicts with" % \
                                  (formatItem(shiftItem,this.grammar),shiftLookahead)
                            print "  item %s (reduce on %s)" % \
                                  (formatItem(reduceItem,this.grammar), \
                                   reduceLookaheadSet)
            for i in range(len(reduceItems)):
                reduceSetA = reduceItems[i][1]
                for j in range(i+1,len(reduceItems)):
                    reduceSetB = reduceItems[j][1]
                    if len(reduceSetA.intersection(reduceSetB)) != 0:
                        isSLR = False
                        if verbose:
                            print "-------------------------------------------------"
                            print "CFRM State %d, reduce-reduce conflict" % stateNum
                            print "  Item %s (reduce on %s) conflicts with" % \
                                  (formatItem(reduceItems[i][0],this.grammar), \
                                   reduceSetA)
                            print "  item %s (reduce on %s)" % \
                                  (formatItem(reduceItems[j][0],this.grammar), \
                                   reduceSetB)
        if verbose:
            if isSLR: print "Grammar is SLR"
            else: print "Grammar is not SLR"
        return isSLR   

   
    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an SLR automaton
    ##               from its CFSM and the Follow sets of the nonterminals
    ##               in the grammar.
    ##
    ## Note: Assumes that the grammar has been checked by "checkSLR".  This
    ## happens automatically in the constructor.  If the grammar is not SLR,
    ## this routine simple returns None.  Otherwise, what is generated is a
    ## dictionary indexed by (sym,stateNumber) tuples indicating the action
    ## to take with "stateNumber" on the top of the parse stack and lookahead
    ## "sym".  An entry in the dictionary is either 'S' (a shift action),
    ## 'A' (an accept action), or a positive number corresponding to a
    ## production number in the augmented grammar associated with the SLR
    ## machine.  Blank entries in the table are not represented explictly.
    ## 
    ##
    def genActions(this):
        if this.isSLR:
            actionTable = dict()
            for stateNum,lr0state in enumerate(this.cfsm):
                for item in lr0state.kernel.union(lr0state.closure):
                    lookahead = getDottedSym(item,this.grammar)
                    if lookahead == 'eps':
                        productionNum = item[0]
                        nonterminal = this.grammar[productionNum].lhs
                        for lookahead in this.follow[nonterminal]:
                            if lookahead != 'eps':
                                actionTable[(lookahead,stateNum)] = productionNum
                            else:
                                if productionNum == 0: ## Augmenting production
                                    actionTable[('$',stateNum)] = 'A'
                                else:
                                    print "Error in Action Table construction"
                                    print "Lookahead of eps encountered on item %s" %\
                                          formatItem(item,this.grammar)
                                    return None
                    elif isterminal(lookahead):
                        actionTable[(lookahead,stateNum)] = 'S'
            return actionTable
        else:
            return None
        
    ##----------------------------------------------------------------------
    ##
    ## displayAction -- Display the Action table associated with this
    ##                  LALR(1) automaton.  Use LRBase method.
    ##
    def displayAction(this):
        LRBase.displayAction(this)

    ##----------------------------------------------------------------------
    ##
    ## lookupAction --  Return the action the SLR machine should perform
    ##                  at this point in the parse, based on the state of
    ##                  the current stack and lookahead.  Overrides a
    ## version of this method in the superclass 'LR0Machine' and calls the
    ## default method from LRBase directly.
    ##
    def lookupAction(this,stack,lookahead):
        return LRBase.lookupAction(this,stack,lookahead)

    ##----------------------------------------------------------------------
    ##
    ## rejectMessage --  Returns a reject message suitable to a Reject
    ##                   action comming back from the Action table. This 
    ##                   should never happen in a proper LR(0) parse, so
    ## is an error (an LR(0) parse will pick up on illegal input when it
    ## looks at the GoTo table).  For an SLR parse, on the other hand,
    ## rejects in the Action table represent perfectly normal behaviour
    ## on illegal input, so we have this trivial method to allow for
    ## differentiated reporting for an LR0Machine and an SLRMachine.
    ##
    def rejectMessage(this):
        return "Reject"


    ##----------------------------------------------------------------------
    ##
    ## genDot -- Generate a GraphViz format string representing the
    ##           CFSM of this SLR automaton.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## The argument "includeGrammar" governs whther or node to include
    ## a dummy state in the GraphViz output that contains a list of the
    ## grammar's productions.  This is included in the GrapViz as a
    ## "free-floating" state, i.e., one not connected to anything.
    ##
    ##
    def genDot(this,outputForPS=True,includeGrammar=True):
        s = "digraph slrcfsm {\nrankdir=LR;\n"
        for i,state in enumerate(this.cfsm):
            s += this.genDotforSLRstate(state,i,outputForPS=outputForPS)
            s += "\n"
        if includeGrammar:
            s += "grammar [shape=none, label=<\n%s>];\n" % \
                 genHtmlGrammar(this.grammar,targetPS=outputForPS)
        for i,state in enumerate(this.cfsm):
            for ch,target in state.transitions.iteritems():
                s += "%d -> %d [label=\"%s\" fontname=\"Helvetica\""% \
                     (i,target,ch)
                s += " fontcolor=\"#40a040\" fontsize=\"11\"];\n"
        s += "}"
        return s

    ##----------------------------------------------------------------------
    ##
    ## genDotforSLRstate -- Generate a GraphViz "HTML-like" format string
    ##                      representing a particular state of this
    ##                      SLR automaton.
    ##
    def genDotforSLRstate(self,state,dotInternalName,stateDisplayName=None,\
                          outputForPS=True):
        """Generate a Graphviz language HTML representation of this SLR state.
           If the state is inadequate, outline it in red and display inadequate
           items in red.
           
           If parameter 'outputForPS' is True (the default),
           generate HTML designed to be processed by the -Tps and -Tps2
           drivers of the 'dot' program.  If 'outputForPS' is False,
           generate HTML designed to be processed by the -Tsvg driver of
           the 'dot' program.

           If paramter 'stateDisplayName' is omitted, generate the name
           of the state by prefixing 'State' in front of the
           'dotInternalName' of the state."""
        inadequateItems = self.getSLRInadequateItems(state)
        shiftItems = self.getShiftItems(state)
        reduceItems = self.getReduceItems(state)
        if len(inadequateItems) > 0: stateBorderColour = "red"
        else: stateBorderColour = "black"
        if len(reduceItems) > 0: columnCount = 5
        elif len(shiftItems) > 0: columnCount = 4
        else: columnCount = 3
        if not stateDisplayName: stateDisplayName = "State %s" % str(dotInternalName)
        s = """%s [shape=box, style="rounded", color="%s", """ %\
            (dotInternalName,stateBorderColour)
        if len(state.transitions) == 0:   ## A final state of the CFSM, with no transitions out.
            s += "peripheries=\"2\", "
        s += 'label=<\n<table border="0" cellborder="0" cellspacing="2" cellpadding="0">\n'
        s += '<tr>\n    <td colspan="%d"><font color="#40a040">%s</font></td>\n</tr>\n' %\
               (columnCount,stateDisplayName)
        for item in state.kernel:
            if item in inadequateItems: itemColour = "red"
            else: itemColour = "black"
            s += '<tr>\n%s    ' % formatItemAsHtml(item,self.grammar,itemColour,outputForPS)
            if len(reduceItems) > 0 and item in reduceItems:
                s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                pnum = item[0]
                if pnum != 0:
                    s += 'R%d</font></td>\n' % item[0]
                    theSet = self.follow[self.grammar[pnum].lhs]
                else:
                    s += 'A</font></td>\n'
                    theSet = set(['$'])
                s += '<td align="left"><font point-size="8" face="Helvetica" color="#40a040">&#32;%s</font></td>\n' %\
                     formatSetAsHtml(theSet,outputForPS)
            elif len(shiftItems) > 0 and item in shiftItems:
                s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                s += 'S</font></td>\n'
            s += '</tr>'
        for item in state.closure:
            if item in inadequateItems: itemColour = "red"
            else: itemColour = "black"
            s += '<tr>\n%s    ' % formatItemAsHtml(item,self.grammar,itemColour,outputForPS)
            if len(reduceItems) > 0 and item in reduceItems:
                s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                s += 'R%d</font></td>\n' % item[0]
                s += '<td align="left"><font point-size="8" face="Helvetica" color="#40a040">&#32;%s</font></td>\n' %\
                     formatSetAsHtml(self.follow[self.grammar[item[0]].lhs],outputForPS)
            elif len(shiftItems) > 0 and item in shiftItems:
                s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                s += 'S</font></td>\n'
            s += '</tr>'
        s += "</table>>];"
        return s


    ##----------------------------------------------------------------------
    ##
    ## getSLRInadequateItems -- Return the set of Items in a particular 
    ##                          state of this SLR machine which are
    ##                          inadequate.
    ##
    def getSLRInadequateItems(self,state):
        shiftitems = []
        shiftlookaheads = []
        reduceitems = []
        reducelookaheads = []
        conflictitems = set([])
        for item in state.kernel.union(state.closure):
            sym = getDottedSym(item,self.grammar)
            if sym == 'eps':
                reduceitems.append(item)
                reducelookaheads.append(self.follow[self.grammar[item[0]].lhs])
            elif isterminal(sym):
                shiftitems.append(item)
                shiftlookaheads.append(sym)
        for ri in range(len(reduceitems)):
            conflict = False
            for si in range(len(shiftitems)):
                if shiftlookaheads[si] in reducelookaheads[ri]:
                    conflictitems.add(shiftitems[si])
                    conflict = True
            if conflict: conflictitems.add(reduceitems[ri])
            conflict = False
            for rj in range(ri+1,len(reduceitems)):
                if len(reducelookaheads[ri].union(reducelookaheads[rj])) > 0:
                    conflictitems.add(reduceitems[rj])
                    conflict = True
            if conflict: conflictitems.add(reduceitems[ri])
        return conflictitems

                
    ##----------------------------------------------------------------------
    ##
    ## getReduceItems -- Return a set of all the reduce items in a 
    ##                   particular state of this SLR machine (i.e., items
    ##                   which have their dots at the right-hand-end, and 
    ##                   hence predict reductions).
    ##
    def getReduceItems(self,state):
        reduceset=set([])
        for item in state.kernel.union(state.closure):
            if getDottedSym(item,self.grammar) == "eps": reduceset.add(item)
        return reduceset

    ##----------------------------------------------------------------------
    ##
    ## getShiftItems --  Return a set of all the shift items in a 
    ##                   particular state of this SLR machine.
    ##
    def getShiftItems(self,state):
        shiftset=set([])
        for item in state.kernel.union(state.closure):
            sym = getDottedSym(item,self.grammar)
            if sym != "eps" and isterminal(sym): shiftset.add(item)
        return shiftset




##==============================================================================
##==============================================================================
##==============================================================================
##
## Debugging
## 
##
##
##from grammars import *
##print "G1 = ", G1
##print "G2 = ", G2
##print "G3 = ", G3
##print "G4 = ", G4
##print "G5 = ", G5
##
##slrg1=SLRMachine(G1,False)
##slrg2=SLRMachine(G2,False)
##slrg3=SLRMachine(G3,False)
##slrg4=SLRMachine(G4,False)
##slrg5=SLRMachine(G5,False)
##
##print "slrg1 = ", slrg1
##print "slrg2 = ", slrg2
##print "slrg3 = ", slrg3
##print "slrg4 = ", slrg4
##print "slrg5 = ", slrg5
##
