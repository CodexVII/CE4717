##==============================================================================
##
## ff.py
##
## A Python program to analyse grammars to see if they meet the LL1
## criterion.
##
##
## A grammar is represented as a list of "Production" objects (see below).
##
##
## The routines provided for grammar analysis are as follows:
##
##
## checkLL1(grammar,predictors)
##                      - Check if the argument 'grammar' (a list of
##                        Productions) is LL1.  The second (optional)
##                        argument is a list of the predict sets for the
##                        grammar, with predictors[i] corresponding to the
##                        predict set for grammar[i], the i'th production.
##                        (N.B., productions are indexed from 0, i.e., the
##                        first production of the grammar is productions[0].)
##                        Note that no attempt is made to verify that the
##                        list of predict sets is correct, so if you supply
##                        this argument, make sure it is right!  If you omit
##                        argument 2, the routine will calculate the required
##                        predict sets for you.
##
## gen_predict_sets(grammar,do_augment)
##                      - Generate a list of the predict sets for the
##                        grammar. If 'do_augment' is True (the default)
##                        the routine will quietly augment the grammar with
##                        '$' (the end-of-input symbol) if necessary.
##
## fill_first_sets(grammar,nullable)
##                      - Generate a dict (indexed by grammar symbols) of the
##                        first sets of single terminal and nonterminal
##                        symbols of this grammar. If nullable is not supplied
##                        the routine will quietly augment generate the set
##                        of nullable nonterminals as needed.  Since the set
##                        of nullables is typically required elsewhere, it
##                        makes sense to precompute it and pass it in,
##                        however.
##
## compute_first(symlist,first_sets)
##                      - Generate the first set of the sentential form
##                        'symlist' (supplied as a list of grammar symbols).
##                        'first_sets' is the dict of first sets of single
##                        grammar symbols calculated by 'fill_first_sets'.
##
## fill_follow_sets(grammar,first_sets)
##                      - Generate a dict (indexed by nonterminals) of the
##                        follow sets of the nonterminals of the grammar.
##                        'first_sets' is the dict of first sets of single
##                        grammar symbols calculated by 'fill_first_sets'.
##                        This will be calculated automatically if omitted.
##
## make_nullable(gramar)
##                      - Generate a set of those nonterminal symbols which
##                        can generate the null string (epsilon).
##
##
## N.B.  The null string (epsilon) is represented two ways in this program.
## It is represented implicitly in Productions by the empty list.
## When it needs to be represented explicitly (for example, in first or
## follow sets), the string 'eps' is used.  Moral of this: **don't** use
## 'eps' as the name of a terminal, or things will get horribly confused.
##
##
## The routines doing the hard work of calculating the first and follow
## sets (and nullable), are adapted from the pseudo-code in Fischer &
## LeBlanc, "Crafting a Compiler".
##

from defs import Production, isterminal, isnonterminal, findallsyms

##==============================================================================
##
##
## Grammar analysis routines.  These do the work of finding first, follow and
## predict sets, checking whether a grammar is LL(1), etc.
##
##
##------------------------------------------------------------------------------
##
## checkLL1
##
## Check a grammar to see if it meets the LL(1) criterion.
## Returns a tuple (True/False,list), where the first element of the tuple
## indicates whether or not the grammar is LL(1), and the second is a list
## of tuples, each tuple indicating a conflicting pair of productions.
##
##

def checkLL1(gram,predictors=None):
    "Check to see if the grammar supplied as an argument is LL(1)."
    if not predictors: predictors = gen_predict_sets(gram)
    isLL1 = True
    conflicting = []
    for i in range(len(gram)):
        sym = gram[i].lhs
        pset = predictors[i]
        for j in range(i+1,len(gram)):
            if gram[j].lhs == sym and len(pset.intersection(predictors[j])) > 0:
                isLL1 = False
                conflicting.append((i,j))
    return (isLL1,conflicting)


##------------------------------------------------------------------------------
##
## gen_predict_sets
##
## Generate the predict sets for each production in the grammar.
## Return as a list of sets.  The index entry corresponds to the
## production.
##
## do_augment: set if the grammar is to be automatically "augmented"
## with the end-of-input symbol '$'.  Default: True.  If set, causes
## a "pseudo-production" <Aug0000> --> S $ to be introduced for the
## analysis (and quietly dropped on return - !!!!!!!).  This eliminates eps
## symbols from the follow, and hence predictor sets.
##
##

def gen_predict_sets(gram,do_augment=True):
    "Generate a list of the Predict Sets of this grammar."
    augmenting = False
    if len(gram[0].rhs) > 0:
        if do_augment and gram[0].rhs[-1] != '$':
            startsym = gram[0].lhs
            gram = gram[:]
            gram.insert(0,Production('<Aug0000>',[startsym,'$']))
            augmenting = True
    firsts = fill_first_sets(gram,make_nullable(gram))
    followers = fill_follow_sets(gram,firsts)
    predictors = len(gram)*[None]
    for i in range(len(gram)):
        pred_i = compute_first(gram[i].rhs,firsts)
        if 'eps' in pred_i:
            pred_i.remove('eps')
            pred_i.update(followers[gram[i].lhs])
        predictors[i] = pred_i
    if augmenting:
        return predictors[1:]
    else:
        return predictors


##------------------------------------------------------------------------------
##
## fill_first_sets from the pseudo code, pp 105-6 in F & LeB
##
## Fill all the first sets of terminals and nonterminals in gram.
##
## First argument is the grammar, the second is the set of nullable
## nonterminals in the grammar.  If this is omitted, the routine
## calculates it.
##

def fill_first_sets(gram,nullable=None):
    "Return a dict of the first sets of single grammar symbols."
    if not nullable: nullable = make_nullable(gram)
    first_set = dict()
    for nt in findallsyms(gram,isnonterminal):
        if nt in nullable: first_set[nt] = set(['eps'])
        else: first_set[nt] = set()
    for ter in findallsyms(gram,isterminal):
        first_set[ter] = set([ter])
        for prod in gram:
            if len(prod.rhs) > 0 and isterminal(prod.rhs[0]):
                first_set[prod.lhs].add(prod.rhs[0])
    changes = True
    while changes:
        changes = False
        for prod in gram:
            first_rhs = compute_first(prod.rhs,first_set)
            if not first_rhs.issubset(first_set[prod.lhs]):
                first_set[prod.lhs].update(first_rhs)
                changes = True
    return first_set


##------------------------------------------------------------------------------
##
## compute_first from the pseudo code, pp 105 in F & LeB.
##
## Compute the first set of a sentential form, given a
## (possibly partially complete) set of first sets for single
## terminals and nonterminals.
##
## There seem to be some errors in F & LB's code, so I've
## modified it here.
##
##

def compute_first(symlist,first_sets):
    "Return the first set of a single sentential form, symlist."
    if len(symlist) == 0: return set(['eps'])
    else:
        result = first_sets[symlist[0]].copy()
        i = 0
        max_index = len(symlist) - 1
        while i < max_index and 'eps' in result:
            result.remove('eps')
            i += 1
            result.update(first_sets[symlist[i]].copy())
    return result


##------------------------------------------------------------------------------
##
## fill_follow_sets from the pseudo code, pp 106, F & LeB
##
## Generate follow sets for all nonterminals in the grammar.
##
## First argument is the grammar, the second is the dict of first
## sets of single grammar symbols. If this is omitted, the routine
## calculates it.
##
##

def fill_follow_sets(gram,first_sets=None):
    "Return a dict of the follow sets of the nonterminals of the grammar."
    if not first_sets: first_sets = fill_first_sets(gram)
    follow_sets = dict()
    for nt in findallsyms(gram,isnonterminal): follow_sets[nt] = set()
    follow_sets[gram[0].lhs].add('eps')
    changes = True
    while changes:
        changes = False
        for p in gram:
            for i in range(len(p.rhs)):
                s = p.rhs[i]
                if isnonterminal(s):
                    new_followers = compute_first(p.rhs[i+1:],first_sets)
                    if 'eps' in new_followers:
                        new_followers.remove('eps')
                        new_followers.update(follow_sets[p.lhs])
                    if not new_followers.issubset(follow_sets[s]):
                        changes = True
                        follow_sets[s].update(new_followers)
    return follow_sets


##------------------------------------------------------------------------------
##
## make_nullable is an adaptation of the pseudo-code on pp 103-4 of
## Fischer & LeBlanc, "Crafting a Compilier".
##
##

def make_nullable(gram):
    "Return a set of those nonterminal symbols which can derive epsilon."
    nullable = set()
    changes = True
    while changes:
        changes = False
        for p in gram:
            if not p.lhs in nullable:
                rhs_derives_epsilon = True
                for s in p.rhs:
                    rhs_derives_epsilon = rhs_derives_epsilon and s in nullable
                if rhs_derives_epsilon:
                    nullable.add(p.lhs)
                    changes = True
    return nullable
