##==============================================================================
##
## lalr1-propagate.py
##
## A Python program that builds LALR(1) parsing tables from a grammar.  It does
## this using the "fast" (i.e., practical) approach of first building the
## LR(0) CFSM, then constructing the LALR(1) "Item Lookahead Propagation Graph",
## which it uses to propagate item-specific lookahead contexts around the CFSM.
##
## This code inherits its basic capabilities, such as the ability to construct
## the LR0 CFSM, from its superclass, 'LR0Machine'.
##
## This user can choose to allow Shift-Reduce parsing conflicts in the
## generated Action table for a grammar.  If this option is chosen, any CFSM
## state that has shift-reduce conflicts will default to applying the
## shift action where there is an appropriate transition out of the state on
## the terminal being shifted.  This is the approach taken by Yacc/Bison, and
## allows "dangling-else" type grammar constructs to be handled (N.B., the 
## default behaviour of this code is to disallow such conflicts).  Note also
## that *only* shift-reduce conflicts can be resolved in this fashion.  If a
## generated CFSM has a state with multiple reduce-reduce conflicts, then
## no action table can be generated (unlike yacc, this program does not resolve
## reduce-reduce conflicts).
##
##------------------------------------------------------------------------------
##
## Use:
##
##     >>> from grammars import *      ## <-- Get some grammar definitions.
##     >>> lalr1g11=LALR1Machine(G11)  ## <-- Create LALR(1) automation for G11.
##     >>> lalr1g11.displayCFSM()      ## <-- Show the LALR(1)/LR(0) FSM for G11.
##     >>> lalr1g11.displayAction()    ## <-- Show the LALR(1) Action table.
##     >>> lalr1g11.displayGoTo()      ## <-- Show the GoTo table.
##     >>> lalr1g11.parse('( id  )')   ## <-- Parse an input string, displaying
##                                     ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, '(id)' would be scanned as the single
## token '(id)', not the three tokens '(', 'id', ')'.
##
##
##     >>> lalrg11.outputDot('l.dot')  ## <-- Output a description of the CFSM 
##                                     ##     of this LALR(1) automaton to file 
##                                     ##     'l.dot' in a form suitable for
##                                     ##     processing by 'dot -Tps2'.
##
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LALR1Machine -- This represents the LALR(1) recogniser for a given
##                    grammar.
##
##
##      Methods:
##          Constructor.  Takes three arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction (defaults to True), the
##              third a flag that controls whether shift-reduce conflicts
##              are allowable in the generated machine (defaults to False).
##
##          displayCFSM.  Outputs the CFSM in "pretty-printed" style.
##              Inherited from LR0Machine.
##
##          displayGoTo.  Displays the GoTo table associated with
##              this LALR(1) automaton in "pretty-printed" tabular style.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          displayActions.  Displays the LALR(1) Action table 
##              associated with this LALR(1) automaton in "pretty-printed"
##              tabular style.
##              Calls implementation in abstract base class LRBase.
##
##          parse.  Parses an input string (of simple, space-separated
##              terminal symbols) according to the Action and GoTo
##              tables of this LALR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          parseST. "Quietly" parses an input string and returns a data
##              structure representing the Syntax Tree of the input.
##              N.B., If the parse fails (bad input, causing a syntax
##              error), the routine returns None.  It will also print
##              out some terse diagnostic information about the source
##              of the error, but, in general, it is best to run
##              "parse" (or better, "parseER") to get detailed info
##              about the problem.
##              Inherited from abstract base class LRBase via LR0Machine.
##
##          genDot.  Return a multi-line string containing a description
##              of the LALR(1) CFSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.  Note that this version
##              of "genDot" identifies inadequate states of the CFSM.
##              If a state has reduce-reduce conflicts or shift-reduce
##              conflicts and these are not allowed, the state is 
##              outlined in red and the inadequate items in the state
##              are highlighted in red.  If the state has shift-reduce
##              conflicts only, and such conflicts are specifically 
##              allowed by the machine, the stateis outlined in orange
##              and those items in s-r conflicts are highlighted in
##              orange also.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(0) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG.
##              This method is inheritied from parent class LR0Machine.
##
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
##------------------------------------------------------------------------------
##
##

from defs import Production, isterminal, isnonterminal, findallsyms, \
     augmentGrammar, formatSetAsHtml
from grammars import genHtmlGrammar
from ff import fill_first_sets, compute_first, make_nullable
from lrbase import LRBase
from lr0 import *


##==============================================================================
##
## class LALR1Machine -- This represents the LALR(1) recogniser for a given
##      grammar.  Inherits from LR0Machine.
##
##      N.B. the grammar is quietly augmented before the CFSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##          Constructor.  Takes three arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction (defaults to True), the
##              third a flag that controls whether shift-reduce conflicts
##              are allowable in the generated machine (defaults to False).
##
##
## The propagation graph is a map of vertices.  Each vertex represents a
## unique (state,item) combination.  A vertex is represented by a 2-tuple.
##
##      Element 0 is a list of all other vertices this vertex connects to in
##         the propagation graph (as (statenumber,item) keys).
##      Element 1 is a set containing the lookaheads of this vertex (state/item
##          combination).
##
##      The map is keyed by (statenumber,item) pairs.
##

class LALR1Machine(LR0Machine):
    "The LALR(1) recogniser for a grammar."
    def __init__(this,grammar,verbose=True,allowSRconflicts=False):
        this.allowSRconflicts = allowSRconflicts
        this.grammar = augmentGrammar(grammar)          ## Note augmentation.
        this.cfsm = this.buildCFSM(False)               ## Quietly build LR(0) CFSM (no verbose messages).
        this.firsts = fill_first_sets(this.grammar)     ## Build first sets for nts & ters.
        this.gotoTable = this.genGoTo()                 ## Build GoTo table from LR(0) CFSM.
        ## Build LALR(1) item lookahead propagation graph (put it into propGraph).
        this.propGraph = this.buildItemPropGraph(verbose)
        ## Propagate item lookaheads through the graph.
        this.evalItemPropGraph(verbose)
        this.isLALR1 = this.checkLALR1(verbose)
        if this.isLALR1:
            this.actionTable = this.genActions()
        else:
            this.actionTable = None
        
    ##----------------------------------------------------------------------
    ##
    ## buildItemPropGraph -- "Initialise" the Item lookahead propagation
    ##                       graph for this automaton.
    ##
    ## This is essentially the code from Fischer & LeBlanc, "Crafting a
    ## Compiler, 2nd ed." (see pseudocode listing on page 245).
    ##
    ## This method first generates a list of unique items in the CFSM (which
    ## is assumed to exist at this point).  This list is called "vertices"
    ## below, and is a list of 3-tuples representing a graph.  Element[0]
    ## of each vertex is its name, a pair (statenumber,item), that uniquely
    ## identifies the vertex by CFSM state and the item in that state.
    ## Element[1] is a list of other vertices in the graph which this node
    ## should propagate lookaheads to, and element[2] is a set of 
    ## predictors (or lookaheads) associated with this node of the graph.
    ## (While it is doing this, it also generates a map (vertexIndices)
    ##  from (statenum,item) pairs to indices in the vertex list.)
    ##
    ## The method then initialses the "propagate links" between vertices 
    ## in the graph.  This happens in one of two ways:
    ##     (1)  If an item in the graph is of the form A --> alpha _ B gamma,
    ##          (where B is either a terminal or a nonterminal), it links
    ##          the vertex with this (state,item) pair to a vertex which
    ##          with an item looking like this: A --> alpha B _ gamma.
    ##     (2)  If an item in the graph (in a particular state) is of the
    ##          form A --> alpha _ B gamma, where B this time is a
    ##          nonterminal, and there are closure items of the
    ##          form B --> _ delta in that state, and gamma can disappear 
    ##          during the course of the parse (i.e., "gamma derives 'eps'"),
    ##          then anything that follows A --> alpha _ B gamma can also
    ##          potentially follow B --> _ delta, so a propagate link is
    ##          created from the (statenum,"A --> alpha _ B gamma") node
    ##          and all nodes of the form (statenum,"B --> _ delta").
    ##
    ## The method also initialises the "spontaneous lookaheads" of various
    ## items.  "Spontaneous lookaheads" arise from closure operations.
    ## Assume that an item "A --> alpha _ B gamma" exists, and has an
    ## associated closure item "B --> _ delta".  Clearly, the things
    ## that can follow B in a parse are the elements of the first set
    ## of s.f. delta.  These become the spontaneous lookaheads of the item
    ## "B --> _delta".  Note that if the first set of delta contains the
    ## null string ('eps'), this is *not* included in the spontaneous
    ## lookaheads for "B --> _ delta" (since it can't be seen in the input,
    ## hence is no good as a predictor).  Instead, a propagate link is
    ## included as described in point (2) above.
    ##
    def buildItemPropGraph(this,verbose):
        ##
        ## Initial graph setup, build a list of all items and initialise it with $ followers.
        ##
        vertices = {}        ## Prop graph vertex map, keyed by (statenum,item) tuples.
        for statenum,state in enumerate(this.cfsm):
            for item in state.kernel.union(state.closure):   ## Iterate over both kernel and closure items.
                vertices[(statenum,item)] = ([],set())
        ## Search for all items in the item list (vertices) that have the dot at the left end of
        ## the RHS of all productions that have the start symbol on their left-hand-sides.
        ## Such items have a forced lookahead context of '$' (i.e., end of input).
        ## Note that such items can only occur in CFSM state 0.
        startSymbol = this.grammar[0].lhs               ## Start Symbol is the LHS of the first production.
        cfsmState0 = this.cfsm[0]
        for (prodIndex,dotPos) in cfsmState0.kernel.union(cfsmState0.closure):
            if dotPos == 0 and this.grammar[prodIndex].lhs == startSymbol:
                vertices[(0,(prodIndex,dotPos))][1].add('$')
                if verbose:
                    print "Added $ to predict set of item",(0,(prodIndex,dotPos))
                                       
        if verbose: print "Total items detected: %d"%len(vertices)
        
        ##
        ## Add propagation edges to vertex graph due to dot advances. Also add edges to closure items
        ## due to potentially null following gammas, and add spontaneous lookaheads.
        ##
        for statenum,state in enumerate(this.cfsm):
            for item in state.kernel.union(state.closure):             ## Iterate over both kernel and closure items of current state.
                dottedSymbol = getDottedSym(item,this.grammar)         ## dottedSymbol is the symbol to the right of the dot in this item.
                if dottedSymbol != 'eps':                              ## Dot not at end of RHS of item, so there must be a transition.
                    ## Insert lookaheads do to dot advances.
                    targetStateIndex = state.transitions[dottedSymbol] ## Look up the target state in the state transitions map.
                    targetItem = (item[0],item[1]+1)                   ## targetItem is item with dot shifted one pos to the right.
                    vertices[(statenum,item)][0].append((targetStateIndex,targetItem))
                    ## Now consider spontaneous lookaheads on closure items and edges to closure items
                    ## due to potentailly null gammas in the current item A --> alpha _ B gamma, this
                    ## of course only happens if the symbol to the right of the dot is a nonterminal.
                    if isnonterminal(dottedSymbol):
                        gamma = this.grammar[item[0]].rhs[item[1]+1:]  ## item is (prodNumber,dotIndex)
                        firstGamma = compute_first(gamma,this.firsts)  ## first set of s.f. Gamma
                        if 'eps' in firstGamma:      ## If Gamma can be null, need to note this as an edge
                            gammaDerivesNull = True  ## will be needed from the current vertex to the
                            firstGamma.remove('eps') ## target (closure) vertex, also must remove null
                        else:                        ## from the first set, as not appropriate as a
                            gammaDerivesNull = False ## spontaneous lookahead.
                        for cItem in state.closure:
                            if this.grammar[cItem[0]].lhs == dottedSymbol:
                                vertices[(statenum,cItem)][1].update(firstGamma)  ## Add spontaneous lookaheads to this item.
                                if gammaDerivesNull:
                                    vertices[(statenum,item)][0].append((statenum,cItem))  ## If gamma possible null, add prop link.
        if verbose:
            itemlist = []
            for vkey,vertex in vertices.iteritems():       ## Display prop graph with edges due to dot advances.
                s = "%3d,%s,%-30s Edges: %s, spontaneous lk: %s" %\
                    (vkey[0], vkey[1], formatItem(vkey[1], this.grammar), vertex[0], vertex[1])
                itemlist.append(s)
            itemlist.sort()
            for s in itemlist: print s
        return vertices

    ##----------------------------------------------------------------------
    ##
    ## evalItemPropGraph -- Perform the transitive closure of the
    ##                      lookahead sets for the items of the item
    ##                      propagate graph.
    ##
    ## This is essentially the code from Fischer & LeBlanc, "Crafting a
    ## Compiler, 2nd ed." (see pseudocode listing on page 245).
    ##
    ## This method simply propagates lookahead sets from vertex to vertex
    ## in the item propagate graph until a stable point is found, when
    ## further propagate will not change any of the sets.
    ##
    def evalItemPropGraph(this,verbose):
        changed = True
        while changed:
            if verbose: print "iterating"
            changed = False
            for vkey,vertex in this.propGraph.iteritems():
                ##if verbose: print "  working with vertex (state %d, item %s %s): lookahead: %s" %\
                ##                  (vkey[0], vkey[1], formatItem(vkey[1], this.grammar), vertex[1])
                vLookahead = vertex[1]
                for targetIndex in vertex[0]:
                    targetVertex = this.propGraph[targetIndex]
                    oldTargetLookahead = targetVertex[1].copy()
                    targetVertex[1].update(vLookahead)
                    if oldTargetLookahead != targetVertex[1]:
                        changed = True
                    ##    if verbose:
                    ##        print "    target vertex", targetVertex, "lookahead modified"
                    ##else:
                    ##    if verbose:
                    ##        print "    target vertex", targetVertex, "NOT modified"
        if verbose:
            itemlist = []
            for vkey,vertex in this.propGraph.iteritems():       ## Display modified prop graph with lookaheads propagated.
                s = "%3d,%s,%-30s Propagated lookahead: %s" %\
                    (vkey[0], vkey[1], formatItem(vkey[1], this.grammar), vertex[1])
                itemlist.append(s)
            itemlist.sort()
            for s in itemlist: print s
            
    ##----------------------------------------------------------------------
    ##
    ## checkLALR1 -- Check to see if the grammar is LALR(1)-parsable.
    ##
    ## Argument:
    ##
    ##       verbose  -- controls debug/status-reporting.
    ##
    ##
    def checkLALR1(this,verbose=True):
        srConflicts = 0   ## Initially assume no S-R conflicts.
        rrConflicts = 0   ## Ditto for Reduce-Reduce conflicts.
        if verbose: print "LALR(1) check\n============="
        for stateNum,lr0state in enumerate(this.cfsm):
            if verbose: print "Checking CFSM state %d" % stateNum
            shiftItems = []
            reduceItems = []
            for item in lr0state.kernel.union(lr0state.closure):
                dottedSymbol = getDottedSym(item,this.grammar)
                if dottedSymbol == 'eps':  ## dot at end of item, so lookahead from prop graph
                    key = (stateNum,item)
                    reducePredictorSet = this.propGraph[key][1]
                    reduceItems.append((item,reducePredictorSet))
                elif isterminal(dottedSymbol): ## dodted symbol is a terminal => shift
                    shiftItems.append((item,dottedSymbol))
            ##if verbose:
            ##    print "State %d, shift items %s, reduce items %s"%\
            ##          (stateNum,shiftItems,reduceItems)
            for reduceItem,reducePredictors in reduceItems:
                for shiftItem,shiftPredictor in shiftItems:
                    if  shiftPredictor in reducePredictors:
                        srConflicts += 1
                        if verbose:
                            print "-------------------------------------------------"
                            print "CFSM State %d, shift-reduce conflict" % stateNum
                            print "  Item %s (shift on %s) conflicts with" % \
                                  (formatItem(shiftItem,this.grammar),shiftPredictor)
                            print "  item %s (reduce on %s)" % \
                                  (formatItem(reduceItem,this.grammar),reducePredictors)
            for i in range(len(reduceItems)):
                reduceSetA = reduceItems[i][1]
                for j in range(i+1,len(reduceItems)):
                    reduceSetB = reduceItems[j][1]
                    if len(reduceSetA.intersection(reduceSetB)) != 0:
                        rrConflicts += 1
                        if verbose:
                            print "-------------------------------------------------"
                            print "CFRM State %d, reduce-reduce conflict" % stateNum
                            print "  Item %s (reduce on %s) conflicts with" % \
                                  (formatItem(reduceItems[i][0],this.grammar), \
                                   reduceSetA)
                            print "  item %s (reduce on %s)" % \
                                  (formatItem(reduceItems[j][0],this.grammar), \
                                   reduceSetB)

        if rrConflicts > 0 or (srConflicts > 0 and not this.allowSRconflicts):
            isLALR1 = False 
        else:
            isLALR1 = True

        if verbose:
            print "-------------------------------------------------"
            print "Reduce-Reduce conflicts: %d" % rrConflicts
            print "Shift-Reduce conflicts:  %d" % srConflicts,
            if srConflicts > 0:
                if this.allowSRconflicts: s = ""
                else: s = "NOT"
                print "(S-R conflicts are %s allowed in this grammar)" % s
            else: print ""
            if isLALR1: print "Grammar is LALR(1)"
            else: print "Grammar is not LALR(1)"
            
        return isLALR1

    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an LALR(1) automaton
    ##               from its CFSM and the various item predictors in the
    ##               item propagarion graph.
    ##
    ## Note: Assumes that the grammar has been checked by "checkLALR1".  This
    ## happens automatically in the constructor.  If the grammar is not LALR(1),
    ## this routine simple returns None.  Otherwise, what is generated is a
    ## dictionary indexed by (sym,stateNumber) tuples indicating the action
    ## to take with "stateNumber" on the top of the parse stack and lookahead
    ## "sym".  An entry in the dictionary is either 'S' (a shift action),
    ## 'A' (an accept action), or a positive number corresponding to a
    ## production number in the augmented grammar associated with the LALR(1)
    ## machine.  Blank entries in the table are not represented explictly.
    ##
    ## Note that this code gives preference to Shift actions over Reduce ones
    ## (this is the yacc default).  The idea is that if there is an available
    ## transition out of a state on a lookahead, the lookahead should be shifted
    ## onto the stack to allow this to happen (see Dragon book p250).  This
    ## approach allows "natural" handling of, for example, "dangling-else"
    ## grammars.
    ## 
    ##
    def genActions(this):
        if this.isLALR1:
            actionTable = dict()
            for stateNum,lr0state in enumerate(this.cfsm):
                for item in lr0state.kernel.union(lr0state.closure):
                    dottedSymbol = getDottedSym(item,this.grammar)
                    if dottedSymbol == 'eps':   ## dot at end of item, lookahead from prop graph
                        productionNum = item[0]
                        if productionNum == 0:  ## Reduce on production 0 => accept.
                            action = 'A'
                        else:                   ## else just reduce by the production.
                            action = productionNum
                        reducePredictorSet = this.propGraph[(stateNum,item)][1]
                        for reducePredictor in reducePredictorSet:
                            ## Only allow an entry to be made in a slot if it is
                            ## currently empty -- gives precedence to shifts over
                            ## reductions (yacc default).  This is an approach that
                            ## allows, for example, "dangling-else" grammars to be
                            ## handled naturally.
                            key = (reducePredictor,stateNum)
                            if not actionTable.has_key(key): actionTable[key] = action
                    elif isterminal(dottedSymbol):
                        key = (dottedSymbol,stateNum)
                        actionTable[key] = 'S'
            return actionTable
        else:
            return None



    ##----------------------------------------------------------------------
    ##
    ## genDot -- Generate a GraphViz format string representing the
    ##           CFSM of this LALR(1) automaton.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## The argument "includeGrammar" governs whther or node to include
    ## a dummy state in the GraphViz output that contains a list of the
    ## grammar's productions.  This is included in the GrapViz as a
    ## "free-floating" state, i.e., one not connected to anything.
    ##
    ## Note that this version of "genDot" identifies inadequate states 
    ## of the CFSM.  If a state has reduce-reduce conflicts or shift-            
    ## reduce conflicts and these are not allowed, the state is           
    ## outlined in red and the inadequate items in the state are              
    ## highlighted in red.  If a state has shift-reduce conflicts only,             
    ## and such conflicts are specifically allowed by the machine, the              
    ## state is outlined in orange and those items in s-r conflicts are             
    ## highlighted in orange also.             
    ##               
    ##             
    ##
    ##
    def genDot(this,outputForPS=True,includeGrammar=True):
        s = "digraph lalr1cfsm {\nrankdir=LR;\n"
        for i,state in enumerate(this.cfsm):
            s += this.genDotforLALRstate(state,i,outputForPS=outputForPS)
            s += "\n"
        if includeGrammar:
            s += "grammar [shape=none, label=<\n%s>];\n" % \
                 genHtmlGrammar(this.grammar,targetPS=outputForPS)
        for i,state in enumerate(this.cfsm):
            for ch,target in state.transitions.iteritems():
                s += "%d -> %d [label=\"%s\" fontname=\"Helvetica\""% \
                     (i,target,ch)
                s += " fontcolor=\"#40a040\" fontsize=\"11\"];\n"
        s += "}"
        return s

    ##----------------------------------------------------------------------
    ##
    ## genDotforLALRstate -- Generate a GraphViz "HTML-like" format string
    ##                       representing a particular state of this
    ##                       LALR(1) automaton.
    ##
    def genDotforLALRstate(this,state,stateNum,stateDisplayName=None,\
                           outputForPS=True):
        """Generate a Graphviz language HTML representation of this LALR(1)
           state.  If the state is inadequate, outline it in red and display
           inadequate items in red.  If the state is inadequate because of
           shift-reduce conflicts only, and these are allowed in the
           machine, display the state outlined in orange, and with those
           items in shift-reduce conflicts in orange.
           
           If parameter 'outputForPS' is True (the default),
           generate HTML designed to be processed by the -Tps and -Tps2
           drivers of the 'dot' program.  If 'outputForPS' is False,
           generate HTML designed to be processed by the -Tsvg driver of
           the 'dot' program.

           If paramter 'stateDisplayName' is omitted, generate the name
           of the state by prefixing 'State' in front of the
           number of the state."""
        ORANGE = "#ff8040"
        inadequateItems,srConflictItems = this.getLALRInadequateItems(state,stateNum)
        shiftItems = this.getShiftItems(state)
        reduceItems = this.getReduceItems(state)
        if len(inadequateItems) > 0: stateBorderColour = "red"
        elif len(srConflictItems) > 0: stateBorderColour= ORANGE
        else: stateBorderColour = "black"
        if len(reduceItems) > 0 or len(shiftItems) > 0: columnCount = 5
        else: columnCount = 4
        if not stateDisplayName: stateDisplayName = "State %s" % str(stateNum)
        s = """%s [shape=box, style="rounded", color="%s", """ %\
            (stateNum,stateBorderColour)
        if len(state.transitions) == 0:   ## A final state of the CFSM, with no transitions out.
            s += "peripheries=\"2\", "
        s += 'label=<\n<table border="0" cellborder="0" cellspacing="2" cellpadding="0">\n'
        s += '<tr>\n    <td colspan="%d"><font color="#40a040">%s</font></td>\n</tr>\n' %\
               (columnCount,stateDisplayName)
        for stateSet in (state.kernel,state.closure):
            for item in stateSet:
                if item in inadequateItems: itemColour = "red"
                elif item in srConflictItems: itemColour = ORANGE
                else: itemColour = "black"
                s += '<tr>\n%s    ' % formatItemAsHtml(item,this.grammar,itemColour,outputForPS)
                theSet = this.propGraph[(stateNum,item)][1]  ## LALR(1) predictor set.
                s += '<td align="left"><font point-size="8" face="Helvetica">&#32;&#32;%s</font></td>\n' %\
                     formatSetAsHtml(theSet,outputForPS)
                if len(reduceItems) > 0 and item in reduceItems:
                    s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                    pnum = item[0]
                    if pnum != 0:
                        s += 'R%d</font></td>\n' % item[0]
                    else:
                        s += 'A</font></td>\n'
                elif len(shiftItems) > 0 and item in shiftItems:
                    s += '<td align="left"><font point-size="9" face="Helvetica" color="#2020f0">&#32;&#32;'
                    s += 'S</font></td>\n'
                s += '</tr>'
        s += "</table>>];"
        return s


    ##----------------------------------------------------------------------
    ##
    ## getLALRInadequateItems -- Return a 2-tuple.  The first element of
    ##                           the tuple is the set of Items in a
    ##                           particular state of this LALR(1) machine
    ## which are inadequate.  The second element of the tuple is a list
    ## of those items which have S-R conflicts.  
    ##
    def getLALRInadequateItems(this,state,stateNum):
        shiftitems = []
        shiftlookaheads = []
        reduceitems = []
        reducelookaheads = []
        conflictitems = set([])
        srconflictitems = set([])
        for item in state.kernel.union(state.closure):
            sym = getDottedSym(item,this.grammar)
            if sym == 'eps':
                reduceitems.append(item)
                reducelookaheads.append(this.propGraph[(stateNum,item)][1])
            elif isterminal(sym):
                shiftitems.append(item)
                shiftlookaheads.append(sym)
        for ri in range(len(reduceitems)):
            conflict = False
            srconflict = False
            for si in range(len(shiftitems)):
                if shiftlookaheads[si] in reducelookaheads[ri]:
                    if not this.allowSRconflicts:
                        conflict = True
                        conflictitems.add(shiftitems[si])
                    srconflictitems.add(shiftitems[si])
                    srconflict = True
            if conflict: conflictitems.add(reduceitems[ri])
            if srconflict: srconflictitems.add(reduceitems[ri])
            conflict = False
            for rj in range(ri+1,len(reduceitems)):
                if len(reducelookaheads[ri].union(reducelookaheads[rj])) > 0:
                    conflictitems.add(reduceitems[rj])
                    conflict = True
            if conflict: conflictitems.add(reduceitems[ri])
        return conflictitems,srconflictitems


                
    ##----------------------------------------------------------------------
    ##
    ## getReduceItems -- Return a set of all the reduce items in a 
    ##                   particular state of this LALR(1) machine (i.e., 
    ##                   items which have their dots at the right-hand-end, 
    ##                   and hence predict reductions).
    ##
    def getReduceItems(this,state):
        reduceset=set([])
        for item in state.kernel.union(state.closure):
            if getDottedSym(item,this.grammar) == "eps": reduceset.add(item)
        return reduceset

    ##----------------------------------------------------------------------
    ##
    ## getShiftItems --  Return a set of all the shift items in a 
    ##                   particular state of this LALR(1).
    ##
    def getShiftItems(this,state):
        shiftset=set([])
        for item in state.kernel.union(state.closure):
            sym = getDottedSym(item,this.grammar)
            if sym != "eps" and isterminal(sym): shiftset.add(item)
        return shiftset


        
    ##----------------------------------------------------------------------
    ##
    ## displayAction -- Display the Action table associated with this
    ##                  LALR(1) automaton.  Use LRBase method.
    ##
    def displayAction(this):
        LRBase.displayAction(this)

    ##----------------------------------------------------------------------
    ##
    ## lookupAction --  Return the action the LALR(1) machine should perform
    ##                  at this point in the parse, based on the state of
    ##                  the current stack and lookahead.  Overrides a
    ## version of this method in the superclass 'LR0Machine' and calls the
    ## default method from LRBase directly.
    ##
    def lookupAction(this,stack,lookahead):
        return LRBase.lookupAction(this,stack,lookahead)

    ##----------------------------------------------------------------------
    ##
    ## rejectMessage --  Returns a reject message suitable to a Reject
    ##                   action comming back from the Action table. This 
    ##                   should never happen in a proper LR(0) parse, so
    ## is an error (an LR(0) parse will pick up on illegal input when it
    ## looks at the GoTo table).  For an LALR(1) parse, on the other hand,
    ## rejects in the Action table represent perfectly normal behaviour
    ## on illegal input, so we have this trivial method to allow for
    ## differentiated reporting for an LR0Machine and an LAR1Machine.
    ##
    def rejectMessage(this):
        return "Reject"


##-------------------------------------------------------------------------
##
## Debug setup.
##
print "+-----------------------------------------------------------------------+"
print "Importing grammars."
from grammars import *
## print "Generating LALR(1) machine for G100 (result in lalrg100)"
## lalrg100=LALR1Machine(G100)
## print "+-----------------------------------------------------------------------+"

