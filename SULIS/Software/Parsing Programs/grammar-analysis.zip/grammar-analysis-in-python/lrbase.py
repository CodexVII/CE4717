﻿##==============================================================================
##
## lrbase.py
##
## Code implementing the abstract base class of all the LR parsing classes
## (LR0Machine, LR1Machine, LALR1Machine, etc.).  Not to be instantiated.
## Just provides some common services (parse, displayAction, displayGoTo)
## to its children.
##
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, 'abab' would be scanned as the single
## token 'abab', not the four tokens 'a', 'b', 'a', 'b'.
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LRBase -- Abstract base class for the LRxmachine classes.
##
##          displayAction.  Displays the Action table associated with
##              this parsing FSM in "pretty-printed" tabular style.
##
##          genGoTo.  Generate a GoTo table for the current parsing
##              FSM as a Python dict.  The keys od the dict are
##              (symbol,stateNum) tuples, the entries in the dict
##              are the target state numbers.
##
##          displayGoTo.  Displays the GoTo table associated with
##              this parsing FSM in "pretty-printed" tabular style.
##
##          parse.  Parses an input string (of simple, space-separated
##              terminal symbols) according to the Action and GoTo
##              tables of this parsing automaton.  Displays operation
##              to terminal, showing each step of the parse.
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##
##          parseST. "Quietly" parses an input string and returns a data
##              structure representing the Syntax Tree of the input.
##              N.B., If the parse fails (bad input, causing a syntax
##              error), the routine returns None.  It will also print
##              out some terse diagnostic information about the source
##              of the error, but, in general, it is best to run
##              "parse" (or better, "parseER") to get detailed info
##              about the problem.
##
##------------------------------------------------------------------------------
##
## N.B., Any class inheriting from this one needs to provide
##       implementations for
##              "getFSMStateCount"
##              "getFSM" and
##              "rejectMessage".
## These methods are used by methods of this base class, but not defined
## by it.  The child class may also need to provide an implementation for
## method "lookupAction" (even if only to call explicitly the default
## version supplied in this base class).
##
##------------------------------------------------------------------------------
##
##      Utility Methods needed by "display" methods -- not for general use:
##      ------------------------------------------------------------------
##
##          getColWidth.  Works out the appropriate size for the left
##              hand column containing grammar symbols in the Action and
##              GoTo tables.  This will be the width of the longest
##              symbol in the grammar (ignoring symbol "<Aug>", which is
##              never displayed) plus 2, but will be, in any case, at
##              least four characters.  N.B., this is implemented here.
##
##          getFSMStateCount.  Return the number of states in the
##              parsing FSM for this machine.  Note that this has to
##              be provided by the children of this class, as the
##              way of counting the number of states in the machine
##              will differ according to whether this is an LR(0)
##              SLR, or LALR(1) transitions-based machine or an LR(1)
##              or LALR(1) cognates-based one
##
##      Utility Methods needed by methods 'parse' and 'parseER'
##      -- not for general use:
##      ----------------------------------------------------------------
##
##          lookupAction.  Looks up the next Action needed by method
##              'parse' based on the current top-of-stack at a
##              particular point in the parse.
##
##          rejectMessage.  Returns a string representing a 'Reject'
##              action coming from the Action table.  This should never
##              happen for an LR0Machine's Action table, and is an error
##              condition if it does, but is fine for an SLRMachine,
##              LR1Machine or LALR1Machine.
##
##          updateHistory.  Updates a history list (for stack and input
##              histories).
##
##          syntaxError.  Does the major work associated with yacc/Bison
##              style error recovery.  Used exclusively by 'parseER'.
##
##
##      Utility Method needed by method 'genGoTo' -- not for general use:
##      -----------------------------------------------------------------
##
##          getFSM.  Returns the LR(0) CFSM or the LR(1) FSM of a 
##              parsing automaton.  Note that this has to be provided
##              by children of this base class.
##
##
##
from defs import Production, isterminal, isnonterminal, \
     findallsyms, augmentGrammar


class LRBase(object):
    "Abstract base class for LR parser generators."
    def __init__(this,grammar):
        this.grammar = augmentGrammar(grammar)  ## Note augmentation.
        this.actionTable = None
        this.gotoTable = None

    ##----------------------------------------------------------------------
    ##
    ## displayAction -- Display the Action table associated with this
    ##                  SLR, LR(1) or LALR(1) automaton.
    ##
    ## The Action table is a list of parse actions, 'S' for shift, 'A' for
    ## accept, 'E' for table error and positive integers for reduce actions,
    ## (as generated by 'genAction').  Blank entries in the table are
    ## reject actions. This routine just prints out the table in a neat
    ## formatted style.  Note that it assumes the table is a dict indexed
    ## by (sym,state) tuples, which is should be for any 2-d Action table
    ## (i.e., any Action table from SLR, LR(1) or LALR(1)).  Since an
    ## LR(0) automaton doesn't use lookahead, the LR0Machine will have to
    ## override this method.
    ##
    def displayAction(this):
        if this.actionTable:
            firstColumnWidth=this.getColWidth()
            s    = (firstColumnWidth*' ') + '|'
            line = (firstColumnWidth*'-') + '+'
            stateRange = range(this.getFSMStateCount())
            for stateNum in stateRange:
                s += '%3d |' % stateNum
                line += '----+'
            print s
            print line
            for sym in findallsyms(this.grammar,isterminal):
                s = sym.center(firstColumnWidth) + '|'
                for stateNum in stateRange:
                    key = (sym,stateNum)
                    if this.actionTable.has_key(key):
                        action = this.actionTable[key]
                        if isinstance(action,int): s += ' R%-2d|' % action
                        else: s += '  %s |' % action
                    else:
                        s += '    |'
                print s
            print line
        else:
            print "Action table not available."


    ##----------------------------------------------------------------------
    ##
    ## lookupAction --  Return the action that a lookahead machine with a
    ##                  2-d Action table should perform at this point in 
    ##                  the parse, based on the state of the current parse
    ## and lookahead.  Returns 'Reject' if there is no valid action, else
    ## 'S' for shift, 'A' for accept and the integer production number if
    ## a reduction is required (note that this is the normal behaviour of
    ## a 2-d Action table, assumed but not forced here). Assumes the Action 
    ## table is a Python dict indexed by (lookahead,top-of-stack) tuples.
    ##
    def lookupAction(this,stack,lookahead):
        ## N.B., 'lookahead' can be a list, in which case it is the rest
        ## of the input available at this point in the parse, or just
        ## a string, where it is the current lookahead.
        if isinstance(lookahead,list):
            lk = lookahead[0]
        else:
            lk = lookahead
        return this.actionTable.get((lk,stack[-1]),'Reject')

    
    ##----------------------------------------------------------------------
    ##
    ## genGoTo -- Generate the GoTo table for an automaton from
    ##            its FSM.
    ##
    ## What is generated is a dictionary indexed by (sym,stateNumber) tuples
    ## indicating the new state to go to when transiting out of state 
    ## 'stateNumber' on symbol 'sym'.  Blank entries in the table are not
    ## represented explictly.
    ##
    def genGoTo(this):
        gotoTable = dict()
        states = this.getFSM()
        for (stateNum,state) in enumerate(states):
            for (sym,targetState) in state.transitions.iteritems():
                gotoTable[(sym,stateNum)] = targetState
        return gotoTable

    
    ##----------------------------------------------------------------------
    ##
    ## displayGoTo -- Display the GoTo table associated with this LR
    ##                automaton.
    ##
    ## Try to keep the ordering of nonterminal symbols (hence table rows)
    ## the same as the order in the original grammar. This accounts for
    ## the messy code building the list of grammar symbols. N.B., assumes
    ## that the GoTo table is a dict indexed by (sym,state) tuples.
    ## (which is should be for all the various LR machines).
    ##
    def displayGoTo(this):
        if this.gotoTable:
            firstColumnWidth=this.getColWidth()
            s    = (firstColumnWidth*' ') + '|'
            line = (firstColumnWidth*'-') + '+'
            stateRange = range(this.getFSMStateCount())
            for stateNum in stateRange:
                s += '%3d |' % stateNum
                line += '----+'
            print s
            print line
            syms = []
            for p in this.grammar[1:]:
                if not p.lhs in syms: syms.append(p.lhs)
            syms.extend(findallsyms(this.grammar,isterminal))
            for sym in syms:
                s = sym.center(firstColumnWidth) + '|'
                for stateNum in stateRange:
                    key = (sym,stateNum)
                    if this.gotoTable.has_key(key):
                        s += '%3d |' % this.gotoTable[key]
                    else:
                        s += '    |'
                print s
            print line
        else:
            print "GoTo table not available."

    ##----------------------------------------------------------------------
    ##
    ## getColWidth -- Find out how wide to make the column of symbols at
    ##                the left-hand side of an Action or GoTo table display.
    ##                This should be at least as wide as the widest symbol
    ##                in the grammar (plus two spaces for padding).  Note
    ##                that this routine ignores the "<Aug>" symbol because
    ## this is never displayed in Action or GoTo tables.  It will always
    ## return a width of at least four columns.
    ## 
    def getColWidth(this):
        width = max(map(len,findallsyms(this.grammar,lambda(x): x != "<Aug>")))+2
        return max(width,4)


    ##----------------------------------------------------------------------
    ##
    ## parse -- Parse an input string of terminals using an LR automaton.
    ##          Assumes that the machine's Action nad GoTo tables have 
    ##          already been constructed.  Needs methids "lookupAction"
    ##          and "rejectMessage" to be supplied by its child classes.
    ##
    def parse(this,inputString):
        if this.actionTable and this.gotoTable:
            inputSyms = inputString.split()
            inputSyms.append('$')
            stack = [0]
            stop = False
            stack_history = []   ## A list of strings representing stack states
                                 ## one for each step of the parse.
            input_history = []   ## Ditto for the input.
            comment_history = [] ## and for the comment on the op performed on
                                 ## the current statck/input combination.

            while not stop:
                updateHistory(stack_history, stack) 
                updateHistory(input_history, inputSyms)
                ## Perform Action (accept, shift, reduce, reject).
                action = this.lookupAction(stack,inputSyms)
                if action == 'A':
                    stop = True
                    comment_history.append('Accept')
                elif action == 'S':
                    sym = inputSyms[0]
                    if sym != '$': inputSyms.pop(0)
                    stack.append(sym)
                    comment_history.append('Shift')
                elif isinstance(action,int):
                    for i in range(2*len(this.grammar[action].rhs)): stack.pop()
                    stack.append(this.grammar[action].lhs)
                    comment_history.append('R%d, %s' % \
                                           (action,this.grammar[action]))
                else:
                    stop = True  ## Shouldn't happen for LR(0), fine for SLR.
                    comment_history.append(this.rejectMessage())

                ## Perform goto new state if not halted already on accept/reject.
                if not stop:
                    updateHistory(stack_history, stack)
                    updateHistory(input_history, inputSyms)
                    goto = this.gotoTable.get((stack[-1],stack[-2]),False)
                    if goto:
                        stack.append(goto)
                        comment_history.append('Goto %d' % goto)
                    else:
                        stop = True
                        comment_history.append('Reject')  # LR(0) rejects in GoTo.

            ## Machine has finished run, so now do the display.
            displayParseRun(stack_history,input_history,comment_history)
        else:
            print "Can't parse input, machine not available."




    ##----------------------------------------------------------------------
    ##
    ## parseER -- "Error Recovery" parsing.  A version of parse that
    ##            implements a basic version of the Yacc/Bison error-
    ##            recovery scheme.  Uses the same "pretty-printed"
    ##            output style as "parse".
    ##
    ##          Assumes that the machine's Action nad GoTo tables have 
    ##          already been constructed.  Needs methids "lookupAction"
    ##          and "rejectMessage" to be supplied by its child classes.
    ##
    ## The parseER routine calls 'syntaxError' (see below) to do the
    ## real work of handling and recovering from syntax errors.  A grammar
    ## that wants to use this style of error recovery should be specified
    ## using 'error productions', i.e., productions including the 'error'
    ## pseudotoken.  As far as table construction is concerned, 'error'
    ## behaves just like a terminal, but 'parseER' and its submethod
    ## 'syntaxError' use the 'error' token to mark 'synchronisation
    ## points' on the parse stack.  When a syntax error is encountered
    ## in the parse (which can be detected in a lookahead automaton as
    ## a blank (aka 'Reject') entry in the Action table), stacked states
    ## are stripped until one is encountered that has 'error' as a
    ## valid lookahead. At this point, 'error' is shifted onto the parse
    ## stack, a GoTo state advance is performed, and input tokens are
    ## dumped until a valid lookahead for the new state is encountered.
    ## Details are in 'syntaxError'.
    ##
    ##
    ##
    def parseER(this,inputString):
        if not this.actionTable or not this.gotoTable:
            print "Can't parse input, machine not available"
            return
        stack_history = []    ## History lists: stack_history is a list of the stacks in the parse.
        input_history = []    ## The input list states during the course of the parse.
        comment_history = []  ## Comments associated with each stack/input state pair.

        ## Chop up the input string into space-delimited symbols, and append a $ if one isn't there.
        inputSyms = inputString.split()
        if len(inputSyms) == 0 or inputSyms[-1] != '$': inputSyms.append('$')

        ## Start the parse.  Stack is initially empty. 'stop' is asserted on Accept.
        stack = [0]
        stop = False
        while len(stack) > 0 and not stop:
            updateHistory(stack_history, stack) 
            updateHistory(input_history, inputSyms)

            ## Action phase of a parsing cycle.  Lookup Action using top of stack and lookahead
            action = this.lookupAction(stack,inputSyms)
            if action == 'A':                      ## Accept action, halt parse. Success.
                stop = True
                comment_history.append('Accept')
            elif action == 'S':                    ## Shift action, shift input to ToS.
                sym = inputSyms[0]
                stack.append(sym)
                if sym != '$': inputSyms.pop(0)
                comment_history.append('Shift')
            elif isinstance(action,int):           ## Reduce action, 'action' is production index.
                prod = this.grammar[action]
                popCount = 2 * len(prod.rhs)       ## popCount is number of elements to remove from stack.
                if popCount > len(stack):          ## Problem, stack too small.
                    print "FATAL ERROR: attempt to pop %d symbols from stack via R%d (%s)" %\
                          (popCount,action,prod)
                    print "Parse aborted, dump of steps completed follows"
                    comment_history.append("R%d, %s:: FATAL" % (action,prod))
                    displayParseRun(stack_history,input_history,comment_history)
                    return
                else:                              ## Pop the 2N elments (state/symbol) of a handle.
                    for i in range(popCount): stack.pop()
                    stack.append(prod.lhs)         ## And push the LHS of the handle's production.
                    comment_history.append("R%d, %s" % (action,prod))
            else:                                  ## Syntax error handling using 'error' pseudoterminal.
                if this.syntaxError(stack,inputSyms,stack_history,input_history,comment_history):
                    ## If syntaxError returns True, this indicates that parsing cycles can continue.
                    ## Since syntax error handling implements its own 'GoTo' phase, skip directly to
                    ## the Action phase on the next parse cycle in this case.
                    continue  
                else:
                    ## If syntaxError returns False, this indicates that parsing has terminated
                    ## within the syntax error routine (because of, for example, no suitable
                    ## synchronisation state being available on the parse stack, or no suitable
                    ## synchronisation lookahead being available in the input).  In this case,
                    ## exit parseER immediately (the stack display will already have been
                    ## generated by syntaxError).
                    return
            ##
            ## GoTo phase of parse cycle.  This is executed unless either (i) an Accept action has
            ## occured above (which will have asserted 'stop'), or (ii) error-recovery mode has
            ## been run, in which case the GoTo phase for this cycle essentially happened there.
            ##
            if not stop:
                updateHistory(stack_history, stack)
                updateHistory(input_history, inputSyms)
                goto = this.gotoTable.get((stack[-1],stack[-2]),False)
                if goto:
                    stack.append(goto)
                    comment_history.append('Goto %d' % goto)
                else:
                    stop = True
                    comment_history.append('Reject')  # LR(0) rejects in GoTo.
        ##
        ## End of while loop for state machine, now do the display.
        ##
        displayParseRun(stack_history,input_history,comment_history)
        return

    ##----------------------------------------------------------------------
    ##
    ## syntaxError -- Core error handling section of a yacc/Bison style
    ##                "Error Recovery" parser.  Does the "heavy lifting"
    ##                associated with error-recovery for "parseER"
    ##                above.
    ##
    ## Returns: boolean:
    ##        True:   Returns True if the error-recovery has been
    ##                successful and the overall parse should continue.
    ##        False:  Returns False if the error-recovery could not
    ##                successfully re-synchronise and the parse has
    ##                terminated early.
    ##
    ##                Note that in the case of early termination,
    ##                this routine takes responsiblity for printing
    ##                out the history of the parse run, so its
    ##                caller doesn't need to do this.
    ##
    ## In Yacc/Bison error-recovery the parser attempts to re-synchronise
    ## the parse on the 'closest' 'error' production.  An error production
    ## is one that includes the 'error' pseudotoken.  As far as table
    ## construction by an LR(1), SLR or LALR(1) parser is concerned, this
    ## is just another production, but when a syntax error occurs the
    ## parser will take the following actions.  It will:
    ##
    ## (1) Report an error message.
    ## (2) Force the 'error' pseudoterminal onto the input stream (so that
    ##     it looks like the current lookahead.
    ## (3) Pop states off the parse stack until a state is seen that
    ##     has the 'error' pseudoterminal as a valid lookahead.
    ##     (if no such state exists, the stack is emptied, and the
    ##     parse is terminated at this point).
    ## (4) Given that a suitable state is found on the parse stack,
    ##     shift the 'error' pseudoterminal onto the top of the stack,
    ##     and goto the state indicated by the (state,'error') pair.
    ## (5) Discard input until a terminal is found that is a valid
    ##     lookahead for the state currently on the ToS (if no such
    ##     terminal is found, the parse is terminated).
    ##
    ## Basically, step (3) "winds back" the stack until a state with
    ## an 'error' item is seen.  This corresponds to "junking" the
    ## offending input and any parsing structure associated with it,
    ## and returning to an "error synchronization point".  Step (5)
    ## then corresponds to searching for a "beacon", or resynchronisation
    ## token following the 'error' pseudoterminal.
    ##
    ##
    def syntaxError(this,stack,inputSyms,stack_history,input_history,comment_history):
        "Handle a SR syntax error using Yacc-style error recovery."
        comment_history.append("SYNTAX ERROR on '%s'. (Force 'error' on i/p)" % inputSyms[0])
        inputSyms.insert(0,"error")        ## Force 'error' pseudoterminal into input
        updateHistory(stack_history, stack)
        updateHistory(input_history, inputSyms)
        ## Now scan down the stack, popping elements off it until a state is seen that has
        ## the 'error' pseudoterminal as a valid lookahead, sync on this state.
        while len(stack) > 0 and this.lookupAction(stack,inputSyms) == 'Reject':
            comment_history.append("  ER: Pop stack (looking for sync state)")
            stack.pop()
            updateHistory(stack_history, stack)
            updateHistory(input_history, inputSyms)
        if len(stack) == 0: ## Stack is empty, no sync point found, parse aborts with REJECT.
            comment_history.append("  ER: stack empty: REJECT")
            displayParseRun(stack_history,input_history,comment_history)
            return False  ## False tells caller not to run any more parse cycles.
        ## If a sync point is found, shift the 'error' pseudoterminal and goto the next state
        ## given by the ('error',tos_state) pair.
        sync = stack[-1]                                ## 'sync' is sync state.
        comment_history.append("  ER: Found sync (%d). Shift 'error'" % sync)                
        inputSyms.pop(0)                                ## Shift 'error' from input and
        stack.append('error')                           ## push it onto the stack.
        updateHistory(stack_history, stack)
        updateHistory(input_history, inputSyms)
        goto = this.gotoTable[(stack[-1],stack[-2])]    ## look up goto state on (error,state)
        comment_history.append("  ER: Goto %d" % goto)
        stack.append(goto)
        updateHistory(stack_history, stack)
        updateHistory(input_history, inputSyms)
        ## Now look for a valid lookahead token to allow a shift from this state. Do this
        ## by scanning over the input, looking for a (tos,lookahead) Action that is not
        ## Reject.  Any lookahead symbols that don't work are dropped from the input.
        while len(inputSyms) > 1 and this.lookupAction(stack,inputSyms) == 'Reject':
            comment_history.append("  ER: Bad lk (%s) drop!" % inputSyms[0])
            inputSyms.pop(0)
            updateHistory(stack_history, stack)
            updateHistory(input_history, inputSyms)
        ## Check that the search for a good lookahead token has succeeded.  If not,
        ## display the history and return False, indicating that further parse
        ## cycles can't be run.
        if len(inputSyms) == 1 and this.lookupAction(stack,inputSyms) == 'Reject':
            comment_history.append("  ER: Lookahead sync failed. REJECT")
            displayParseRun(stack_history,input_history,comment_history)
            return False
        ## Bit of fiddling needed here.  If the re-sync has succeeded, we need
        ## to remove the last itmes on the stack and input histories, because
        ## the caller routine (parseER) will push them again at the start of
        ## its next cycle. But we don't need to do this with the comment history.
        ## Yes, it's messy!
        stack_history.pop()
        input_history.pop()
        return True


    ##----------------------------------------------------------------------
    ##
    ## parseST -- Quietly parse an input string of terminals using an LR
    ##            automaton.  Instead of doing any "pretty-printed" output
    ##            to the terminal, instead return a data-structure
    ##            representing the parse tree (aka "syntax tree", hence
    ##            the name of the routine) of the input string.
    ##            N.B., If the parse fails (bad input, causing a syntax
    ##            error), the routine returns None.  It will also print
    ##            out some terse diagnostic information about the source
    ##            of the error, but, in general, it is best to run
    ##            "parse" (or better, "parseER") to get detailed info
    ##            about the problem.
    ##
    ## Note that this routine has the same restrictions on input as
    ## the other parsing routines, the symbols in the input have
    ## to be separated by spaces (i.e., we don't implement a "proper"
    ## scanner.
    ##
    ##
    ## The format of the data structure returned to represent the
    ## syntax tree is as follows:
    ##
    ## (1) A syntax tree is either a string or a Python 2-tuple
    ##
    ## (2) If it is a simple Python string, this is the name of a terminal.
    ##
    ## (3) If it is a 2-tuple, it represents a nonterminal along with its
    ##     expansion in the syntax tree.
    ##
    ##        Element 0 of the tuple is a Python string which is the
    ##        nonterminal's name
    ##
    ##        Element 1 represents how this nonterminal has been expanded.
    ##        It is either a single element or a list of N elements,
    ##        corresponding to the symbol(s) on the RHS of the production
    ##        being expanded.  Each element is *recursively* a syntax tree,       
    ##        i.e., a simple string representing a terminal, or a 2-tuple
    ##        representing a subtree of the syntax tree.
    ##        
    ##
    ## For example, consider the LR(1) grammar:
    ##
    ##          E --> E + T   (1)
    ##          E --> T       (2)
    ##          T --> T * id  (3)
    ##          T --> id      (4)
    ##
    ## and input string "id + id * id". This method will parse
    ## the input and return the Python data structure:
    ##
    ## ('E', [('E', ('T', 'id')), '+', ('T', [('T', 'id'), '*', 'id'])])
    ##
    ## If this is "pretty-printed" the structure becomes clear:
    ##
    ##     ('E', [('E', ('T', 'id')),
    ##            '+',
    ##            ('T', [('T', 'id'),
    ##                   '*',
    ##                   'id'])])
    ##
    ## Note how "unit" expansions, e.g., "T --> id", generate
    ## 2-tuples without embedded lists: "('T', 'id')", but
    ## other expansions have embedded lists.
    ##
    ##
    ## Operation of this parser.
    ## -------------------------
    ##
    ## The parser maintains two stacks, a syntax stack, which is the
    ## usual S-R parse stack, containing parsing states and symbols,
    ## and a *semantic stack*.  The semantic stack contains partial
    ## parse trees.  It is only modified when the parser applies
    ## a reduction.  It works as follows.
    ##
    ## If the RHS of the production being used in the reduction
    ## contains *only* nonterminals, then the parser creates a new
    ## "expansion list" which is merely a list of these terminals.
    ## It then generates a new syntax tree as a tuple (<lhs-name>,
    ## <list>) and pushes this onto the semantic stack (note that
    ## if there is only one element in the <list>, this is used
    ## as the second element of the syntax-tree tuple).
    ##
    ## If the RHS of the production contains nonterminals, however,
    ## the situation is more interesting.  Basically the parser
    ## "walks" down the parse stack, discarding state numbers and
    ## prepending terminal symbols to the new <list>. But if it
    ## encounters a nonterminal on the parse stack, it pops an
    ## element off the semantic stack, and prepends that to the
    ## <list> being constructed.  Then it builds the 2-tuple
    ## for the syntax tree as above.
    ##
    ## Example:  Consider the same grammar as above and the
    ## same input.  Near the end of the parse a reduction by
    ## production 1 will be required (E --> E + T).  The parse
    ## (syntax) stack will look like the following:
    ##
    ##     [0, 'E', 1, '+', 4, 'T', 7]
    ##
    ## The parser will begin to walk this stack, discarding
    ## stacked states, but using stacked symbols to build
    ## a new syntax tree.  The first stacked nonterminal it
    ## sees is 'T', so it pops the semantic stack (which
    ## contains "('T', [('T', 'id'), '*', 'id'])") and
    ## prepends it to the rhs-list it is construction.
    ## It next sees "+", so this is prepended, giving
    ## "['+', ('T', [('T', 'id'), '*', 'id'])]". Finally
    ## it sees "E", so it pops the semantic stack again,
    ## yielding "('E', ('T', 'id'))", which it prepends
    ## to the list, to give:
    ## "[('E', ('T', 'id')), '+', ('T', [('T', 'id'), '*', 'id'])]".
    ## Finally it builds the new syntax-tree fragment from
    ## this list and the name of the LHS of the production
    ## (E --> E + T) by which it is currently reducing, and
    ## pushes this result onto the semantic stack.
    ##
    ## The key points here are (1): the use of the semantic
    ## stack to carry around partial syntax trees during the
    ## parse, and (2): the fact that the RHS of the reducing
    ## production is traversed *backwards* while the new
    ## syntax tree is being built.
    ##
    ##
    def parseST(this,inputString):
        "Quietly parse an input string and return a Syntax Tree for the input."
        if this.actionTable and this.gotoTable:
            inputSyms = inputString.split()
            inputSyms.append('$')
            stack = [0]
            semanticstack=[]
            while True:
                action = this.lookupAction(stack,inputSyms)
                if action == 'A':
                    stop = True
                    if len(semanticstack) > 0: return semanticstack[-1]
                    else: return None
                elif action == 'S':
                    sym = inputSyms[0]
                    if sym != '$': inputSyms.pop(0)
                    stack.append(sym)
                elif isinstance(action,int):
                    newnode = []
                    for i in range(len(this.grammar[action].rhs)):
                        stack.pop()         ## First thing on stack is a state number, discard.
                        sym = stack.pop()   ## Second is a symbol, terminal or nonterminal.
                        if isterminal(sym): newnode.insert(0,sym)
                        elif isnonterminal(sym):
                            val = semanticstack.pop()
                            newnode.insert(0,val)
                    stack.append(this.grammar[action].lhs)
                    if len(newnode) == 1: newnode = newnode[0]
                    semanticstack.append((this.grammar[action].lhs,newnode))
                else:
                    print "Action: Syntax error in input. Current parse stack: %s, lookahead: %s" %\
                          (stack,inputSyms[0])
                    return None

                goto = this.gotoTable.get((stack[-1],stack[-2]),False)
                if goto: stack.append(goto)
                else:
                    print "GoTo: Syntax error in input. Current parse stack: %s" % stack
                    return None   
        else:
            print "Can't build syntax tree, machine not available."
            return None



##==============================================================================
##
## Utility functions used only by the parsing routines "parse" and "parseER".
##
##
##------------------------------------------------------------------------------
##
## updateHistory  -- utility routine used only by "parseER".
##
## Utility routine, creates a shallow copy of the stack or input list passed to
## it as its second argument and appends this to the end of the history list 
## that is this routine's first argument.  
##
def updateHistory(history_list, element):
    history_list.append(element[:])  ## Create a shallow copy via '[:]'.

  
##------------------------------------------------------------------------------
##
## displayParseRun
##
## Utility routine, generates a nicely formatted record of the run of this
## machine to the standard output.  Used by "parse" and "parseER".
##    
def displayParseRun(stack_history,input_history,comment_history):
    ## First find max widths of the various fields, and do some format conversion.
    maxSlen = 35
    maxIlen = 20
    maxClen = 0
    if len(stack_history) != len(input_history) or len(stack_history) != len(comment_history):
        print "FATAL: history lengths do not match (stack %d, input %d, comment %d)"%\
              (len(stack_history),len(input_history),len(comment_history))
        return
    for state in range(len(stack_history)):
        stack = str(stack_history[state])
        if len(stack) > maxSlen: maxSlen = len(stack)
        stack_history[state] = stack
        inp = reduce(lambda a,b: a + ' ' + b, input_history[state])  ## Convert list to a space-separted string.
        if len(inp) > maxIlen: maxIlen = len(inp)
        input_history[state] = inp
        if len(comment_history[state]) > maxClen: maxClen = len(comment_history[state])
    ## Print out the display header.
    print '\n%s | %s |' % ('Stack'.center(maxSlen),'Input'.center(maxIlen))
    print (maxSlen+1)*'-' + '+' + (maxIlen+2)*'-' + '+' + (maxClen+2)*'-'
    ## Construct a formatting string using the information about
    ## the longest stack, input and comment to ensure that it is
    ## sized appropriately.
    formatStr = '%%-%ds | %%%ds | %%s' % (maxSlen,maxIlen)
    ## And now print all the stack/input/comment states (one per line)
    ## using this formatting string.
    for state in range(len(stack_history)):
        print formatStr % (stack_history[state],input_history[state],comment_history[state])

