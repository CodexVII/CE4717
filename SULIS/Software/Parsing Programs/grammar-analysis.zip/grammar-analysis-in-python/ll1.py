##==============================================================================
##
## ll1.py
##
## A Python program to build LL(1) table-driven parsers and show their
## operation on sample inputs.
##
## Use:
##
##     >>> from grammars import *     ## <-- Get some grammar definitions.
##     >>> ll1g1=LL1Machine(G1)       ## <-- Create an LL(1) automation for G1.
##     >>> ll1g1.displayTable()       ## <-- Show the LL1(1) parse table.
##     >>> ll1g1.parse('a b b a a')   ## <-- Parse an input string, displaying
##                                    ##     stack, input and actions/gotos.
##     >>> st=ll1g1.parseST('a b a')  ## <-- Parse input string 'a b a' and 
##                                    ##     return a syntax tree describing it.
##     >>> import syntaxtree as stree ## <-- Load up syn tree display routines.
##     >>> stree.outputASCII(st)      ## <-- Display the syntax tree on the
##                                    ##     terminal (i.e., sys.stdout).
##     >>> stree.outputTk(st)         ## <-- Display it in a Tk window.
##     >>> stree.outputPS(st,'s.ps')  ## <-- Write it as PostScript to the
##                                    ##     file 's.ps'.
##
## N.B. Parse and parseST both employ a primitive approach to identifying 
## tokens in the input string, they are simply separated by whitespace.  
## Neither parse nor parseST includes a full scanner, so, for example,
## 'abab' would be scanned as the single token 'abab', not the four tokens
## 'a', 'b', 'a', 'b'.
##
##
## A grammar is represented as a list of "Production" objects (see below).
##
## An LL(1) parse table is implemented as a Python dictionary with entries
## indexed by tuples (nonterminal,terminal).  
##
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LL1Machine -- This represents the LL(1) recogniser for a given
##                    grammar.
##
##      Methods:
##          Constructor.  Takes as argument the grammar for which a 
##              recogniser is to be built. Calls "buildLL1ParseTable"
##              to construct the recogniser.
##
##          displayTable.  Displays the LL(1) parse table of this
##              LL1machine in a "pretty-printed" format.
##
##          parse.  Parses an input string (of simple, space-separated
##              terminal symbols) according the LL(1) parse table of 
##              this LR1Machine.  Displays operation to terminal, 
##              showing each step of the parse.  Returns True on a
##              successful parse and False otherwise.
##
##          parseST. "Quietly" parses an input string and returns a data
##              structure representing the Syntax Tree of the input.
##              N.B., If the parse fails (bad input, causing a syntax
##              error), the routine returns None.  It will also print
##              out some terse diagnostic information about the source
##              of the error, but, in general, it is best to run
##              "parse" to get more detailed info about the problem.
##              
##
##
##
##==============================================================================
##
##
from defs import Production, isterminal, isnonterminal, findallsyms
from ff import gen_predict_sets, checkLL1
from lrbase import displayParseRun

class LL1Machine(object):
    DELTA = '<>'             ## Marker for the bottom of the parse stack.
    POP_RD = -1              ## Marks 'pop/read' action in parse table.
    ACCEPT = -2              ## Marks 'accept' action in parse table.
    REJECT = -3              ## Marks 'reject' action in parse table.
                             ## 'Replace' actions are indexed by (+ve)
                             ## production numbers (0-based).
    ILLEGAL = -4             ## Occurs if input which is not in the alphabet
                             ## of the parser is supplied to routine 'parse'.
    
    ##==========================================================================
    ##
    ## Constructor.  Takes a single argument, the grammar to work with, stashes
    ##               it and calls "buildLL1ParseTable" to build the LL(1)
    ##               parse table for it.  The grammar is stored in field
    ##               "grammar" and the parse table in "parseTable".
    ##
    ##
    def __init__(this,grammar):
        this.grammar = grammar
        this.parseTable = this.buildLL1ParseTable()


    ##==========================================================================
    ##
    ## buildLL1ParseTable
    ##
    ## Build and return an LL(1) parse table for the grammar of this machine, 
    ## that grammar is LL(1).  If it isn't, complain to the user and return
    ## None.
    ##
    ##
    def buildLL1ParseTable(this):
        "Build an LL(1) parse table for the object's grammar."
        predictors = gen_predict_sets(this.grammar)
        (isLL1,conflictset) = checkLL1(this.grammar,predictors)
        if isLL1:
            parseTable = dict()
            terminals = findallsyms(this.grammar,isterminal)
            allsyms   = findallsyms(this.grammar, lambda x : True)
            terminals.add('$')
            allsyms.add(LL1Machine.DELTA)
            for row in terminals:
                for col in allsyms:
                    if ( row == col ): action = LL1Machine.POP_RD
                    elif row == '$' and col == LL1Machine.DELTA:
                        action = LL1Machine.ACCEPT
                    else:
                        action = LL1Machine.REJECT
                    parseTable[(row,col)] = action
            for pr_index in range(len(this.grammar)):
                lhs = this.grammar[pr_index].lhs
                for lookahead in predictors[pr_index]:
                    parseTable[(lookahead,lhs)] = pr_index
            return parseTable
        else:
            print "This grammar is not LL(1), conflicts %s" % conflictset
            return None


    ##==========================================================================
    ##
    ## displayTable
    ##
    ## Display a parse table built by buildLL1ParseTable
    ##
    ##
    def displayTable(this):
        "Display the LL(1) parse table of this machine."
        if this.parseTable == None:
            print "Can't display table: not available for this grammar."
            return
        row_indices = list(findallsyms(this.grammar,isterminal))
        col_indices = []
        for p in this.grammar:
            lhs = p.lhs
            if lhs not in col_indices: col_indices.append(lhs)
        col_indices.extend(row_indices)
        col_indices.append(LL1Machine.DELTA)
        row_indices.append('$')
        s   = '    |'
        sep = '----+'
        for col_index in col_indices:
            s += ' %3s |' % col_index
            sep += '-----+'
        print s
        print sep
        for row_index in row_indices:
            s = '%3s |' % row_index
            for col_index in col_indices:
                action = this.parseTable[(row_index,col_index)]
                if action == LL1Machine.REJECT:  s += '     |'
                elif action == LL1Machine.POP_RD:  s += ' p/r |'
                elif action == LL1Machine.ACCEPT:  s += ' acc |'
                else: s += ' %3d |' % action
            print s
            print sep


    ##==========================================================================
    ##
    ## parse
    ##
    ## Parse an input string using an LL(1) parse table. Terminal tokens are
    ## assumed separated by whitespace so a "real" scanner isn't needed.
    ##
    ## Pop/read, Reject and Accept actions are coded by negative integers 
    ## whereas Replace actions are coded (implicitly) by the positive indices 
    ## of their associated grammar productions.  This is a typical approach.
    ##
    ## It is always possible for an illegal token to be returned (something 
    ## that isn't part of the input alphabet of terminal tokens).  A special 
    ## 'ILLEGAL' action is reserved for these circumstances.
    ##
    ## Note how the replace action pops the current top-of-stack symbol and 
    ## then pushes the symbols of the right-hand-side of the associated 
    ## production in reverse order.
    ##
    ##
    def parse(this,input_string):
        tokenlist = input_string.split()    # Split input into a list of tokens.
        tokenlist.append('$')       # Augment the list with end of input marker.
        # Initialise the stack with the bottom pf stack marker and the start 
        # symbol (the LHS of the first production).
        stack_history=[]
        input_history=[]
        comment_history=[]
        stack = [LL1Machine.DELTA,this.grammar[0].lhs] 
        index = 0                           # Reader index.
        while True:
            stack_history.append(stack[:])
            input_history.append(tokenlist[index:])
            # -----
            token = tokenlist[index]                        # Get current input token
            tos_symbol = stack[-1]                          # and top of parse stack
            # Look up the Action. ILLEGAL is returned if no Action defined.
            action = this.parseTable.get((token,tos_symbol),LL1Machine.ILLEGAL)
            if action == LL1Machine.POP_RD:
                comment_history.append("Pop/Rd")
                stack.pop()                                 # Pop/read, pop stack
                index += 1                                  # and read to next token.
            elif action == LL1Machine.ACCEPT:
                comment_history.append("Accept")
                break
            elif action == LL1Machine.REJECT:
                comment_history.append("Reject")
                break
            elif action == LL1Machine.ILLEGAL:
                comment_history.append("Illegal")
                break
            else:                         # The Replace action.
                stack.pop()               # Pop parse stack and push the rhs of
                rhs = this.grammar[action].rhs # production(i).  Note reverse push order.
                for i in range(len(rhs)-1,-1,-1): stack.append(rhs[i])
                comment_history.append("A%s, %s" % (action,this.grammar[action]))
        ##
        ## End of while loop -- machine has halted, display results nicely formatted.
        ## (displayParseRun comes from lrbase.py).
        ##
        displayParseRun(stack_history,input_history,comment_history)


    ##==========================================================================
    ##
    ## parseST
    ##
    ## Parse an input string using an LL(1) parse table, returning a Syntax
    ## Tree data structure representing the input.  The syntax tree is as
    ## described in "syntaxtree.py".  If the input has a syntax error, a 
    ## brief error message is printed and the routine returns None.
    ##
    ## Terminal tokens are assumed separated by whitespace so a "real" scanner
    ## isn't needed.
    ##
    ## The parse tree is accumulated in "parseTree".  The big change between
    ## 'parse' and this routine is how the parse stack is managed.  In 'parse'
    ## this stack simply holds lists of terminals and nonterminals.  For this
    ## routine, a stack entry representing a nonterminal is maintained as
    ## a 2-tuplt (<nonterminal>, <list of elements>), where the "list of 
    ## elements is a list of the elements making up the substitution of this
    ## nonterminal. This list always starts empty, and is built up from the
    ## right hand side of an applied production.  The nice part about this
    ## is that the syntax tree can be built as the parse is conducted just
    ## by ensuring that 'parseTree' points at the first such 2-tuple on the
    ## stack.  The substitution list in this tuple will initially be empty,
    ## but will get built up as the productions are applied during the
    ## parse.
    ##
    ## 
    def parseST(this,input_string):
        tokenlist = input_string.split()    # Split input into a list of tokens.
        tokenlist.append('$')       # Augment the list with end of input marker.
        # Initialise the stack with the bottom pf stack marker and the start 
        # symbol (the LHS of the first production).
        stack = [LL1Machine.DELTA,(this.grammar[0].lhs,[])]
        parseTree=stack[1] ## Make the parse tree point at the first 2-tuple.         
        index = 0                           # Reader index.
        while True:
            token = tokenlist[index]        # Get current input token
            tos = stack[-1]                 # And the symbol on the top of the
            if isinstance(tos,tuple):       # parse stack
                tos_symbol = tos[0]
            else:
                tos_symbol = tos
            # Look up the Action. ILLEGAL is returned if no Action defined.
            action = this.parseTable.get((token,tos_symbol),LL1Machine.ILLEGAL)
            if action == LL1Machine.POP_RD:        
                stack.pop()                                 # Pop/read, pop stack
                index += 1                                  # and read to next token.
            elif action == LL1Machine.ACCEPT:
                ## print "    Accept: String is valid"
                return postProcess(parseTree)
            elif action == LL1Machine.REJECT:
                print "    Reject: String is invalid, (%s,%s) => Reject" % \
                      (token,tos_symbol)
                return None
            elif action == LL1Machine.ILLEGAL:
                print "    Input %s is not a valid terminal for this grammar" % token
                return None
            else:                         # The Replace action.
                lhs=stack.pop()           # Pop parse stack and push the rhs of
                rhs = this.grammar[action].rhs # production(i).  Note reverse push order.
                for i in range(len(rhs)-1,-1,-1):
                    sym = rhs[i]
                    if isterminal(sym):
                        stack.append(sym)
                        lhs[1].insert(0,sym)
                    else:
                        subtree=(sym,[])
                        stack.append(subtree)
                        lhs[1].insert(0,subtree)


##------------------------------------------------------------------------------
##
## postProcess.  This utility routine post-processes the syntax trees generated
##               by "parseST" so that they conform to the definition of a 
##               syntax tree laid down in "syntaxtree.py".  This reduces to
## ensuring that "singleton lists" in the second element of tuples are removed
## and replaced by their contents (recursively).  This is because the definition
## of a syntax tree states that the "rhs" of a syntax tree should not contain
## single-element lists.  It proves to be easier to let "parseST" generate
## single-element lists and then to remove them afterwards.
##
def postProcess(parseTree):
    if isinstance(parseTree,tuple):
        newlist = []
        for sym in parseTree[1]: newlist.append(postProcess(sym))
        if len(parseTree[1]) == 1:
            pt = (parseTree[0],newlist[0])
        else:
            pt = (parseTree[0],newlist)
    else: pt = parseTree
    return pt
        

##------------------------------------------------------------------------------
##
## Experimental parse tree display routine.
##
##
##
##def displayST(st,indent1='',indent2=''):
##    if isinstance(st,tuple):
##        if isinstance(st[1],list):
##            if len(st[1]) == 0:
##                print indent1+('%s ---> \\eps' % st[0])
##            elif len(st[1]) == 1:
##                displaySTv3(st[1][0],indent1+'%s ---> ' % st[0],indent2)
##            else:
##                spaces = len(st[0])*' '
##                displayST(st[1][0],
##                          indent1+('%s -+-> ' % st[0]),
##                          indent2+('%s  |   ' % spaces))
##                for i in range(1,len(st[1])-1):
##                    print indent2+('%s  |   ' % spaces)              
##                    displayST(st[1][i],
##                              indent2+('%s  +-> ' % spaces),
##                              indent2+('%s  |   ' % spaces))
##                print indent2+('%s  |   ' % spaces)
##                displayST(st[1][-1],
##                          indent2+('%s  +-> ' % spaces),
##                          indent2+('%s      ' % spaces))
##        else:
##            displaySTv3(st[1],
##                        indent1+('%s ---> ' % st[0]),
##                        indent2)
##    else:
##        print indent1+st
##                            
##                
##        
##==============================================================================
##
## Debug.
##
##


    

from grammars import G1,G2,G6
m1 = LL1Machine(G1)
pt1=m1.parseST("a b a")
m2 = LL1Machine(G2)
pt2=m2.parseST("a b a b")
m6 = LL1Machine(G6)
pt6=m6.parseST("e g f")

