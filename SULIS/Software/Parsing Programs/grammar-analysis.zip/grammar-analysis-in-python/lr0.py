##==============================================================================
##
## lr0.py
##
## A Python program that builds the LR0 CFSM and the corresponding Action
## and GoTo tables for an LR(0) grammar.
##
## Use:
##
##     >>> from grammars import *    ## <-- Get some grammar definitions.
##     >>> lr0g2=LR0Machine(G2)      ## <-- Create an LR(0) automation for G2.
##     >>> lr0g2.displayCFSM()       ## <-- Show the LR(0) CFSM.
##     >>> lr0g2.displayAction()     ## <-- Show the LR(0) Action table for G2.
##     >>> lr0g2.displayGoTo()       ## <-- Show the GoTo table for G2.
##     >>> lr0g2.parse('a b a b')    ## <-- Parse an input string, displaying
##                                   ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, 'abab' would be scanned as the single
## token 'abab', not the four tokens 'a', 'b', 'a', 'b'.
##
##
##     >>> lr0g2.outputDot('l.dot')  ## <-- Output a description of the CFSM 
##                                   ##     of this LR(0) automaton to file 
##                                   ##     'l.dot' in a form suitable for
##                                   ##     processing by 'dot -Tps2'.
##
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LR0Machine -- This represents the LR(0) recogniser for a given
##                    grammar.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  This flag argument
##              defaults to True.
##
##          buildCFSM.  Builds the CFSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayCFSM.  Outputs the CFSM in "pretty-printed" style.
##
##          checkLR0.  Checks to see if the CFSM built by 'buildCFSM' is
##              in fact, LR(0), (i.e., that it does not contain any
##              inadequate states).  Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(0) automaton
##               from its CFSM.  Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this CFSM in "pretty-printed" tabular style.
##
##          genGoTo.  Generates the GoTo table for an LR(0) automaton
##              from its CFSM.  Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayGoTo.  Displays the GoTo table associated with
##              this CFSM in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          parse.  Parses an input string (of simple, space-separated
##              terminal symbols) according to the Action and GoTo
##              tables of this LR0Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from LRBase (abstract base class).
##
##          parseST. "Quietly" parses an input string and returns a data
##              structure representing the Syntax Tree of the input.
##              N.B., If the parse fails (bad input, causing a syntax
##              error), the routine returns None.  It will also print
##              out some terse diagnostic information about the source
##              of the error, but, in general, it is best to run
##              "parse" (or better, "parseER") to get detailed info
##              about the problem.
##              Inherited from LRBase (abstract base class).
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(0) CFSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(0) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##
##      Utility Methods needed by base class methods and implemented here
##      -----------------------------------------------------------------
##
##          lookupAction.  Looks up the next Action needed by method
##              'parse' based on the current top-of-stack at a
##              particular point in the parse.
##
##          rejectMessage.  Returns a string representing a 'Reject'
##              action coming from the Action table.
##
##          getFSMStateCount.  Returns a count of the number of states in
##              this parsing automaton's LR(0) FSM.
##
##          getFSM.  Returns the LR(0) CFSM of this parsing automaton.
##
##
##------------------------------------------------------------------------------
##
##      LR0State --  Represents a set of LR(0) Items making up a state of the
##                   LR(0) Characteristic Finite State Machine.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(0) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation of the Item in terms of the
##              underlying grammar production and the ot position.
##
##          equals.  Check to see if this LR(0) state and the argument, 
##              another such state, are equal.  Two LR(0) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR0State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR0States.
##
##          isAdequate.  Return True if this LR0State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              name as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              name to identify the state.
##
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
## LR(0) Items (dotted prodictions) are represented as tuples, the first
## element of the tuple indexing into the grammar associated with the item,
## giving the production, and the second element being the position of the
## "dot" (virtual read-head) in the item.  So, given a grammar
##
##      <Aug> --> S $          (0)   <-- "augmenting" production
##      S     --> A B B A      (1)
##            .
##            .
##
## then the tuple (1,2) represents the item [S --> A B _ B A], with the
## 'dot' (here represented by an underscore) before the third element
## of the production's right-hand-side.
##
## Why as a tuple? Because in Python we can have sets of tuples (needed
## or the LR(0) state, which is a set of items. Class "LR0State" encapsulates
## an item set and various utility routines associated with LR(0) state
## creation and manipulation (e.g., closure, finding transitions out of an
## LR(0) state, etc.).
##
##------------------------------------------------------------------------------
##
##

from defs import Production, isterminal, isnonterminal, \
     findallsyms, augmentGrammar
from grammars import genHtmlGrammar
from lrbase import LRBase

##==============================================================================
##
## class LR0Machine -- This represents the LR(0) recogniser for a given
##      grammar.
##
##      N.B. the grammar is quietly augmented before the CFSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Default to True.
##
##          buildCFSM.  Builds the CFSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayCFSM.  Outputs the CFSM in "pretty-printed" style.
##
##          checkLR0.  Checks to see if the CFSM built by 'buildCFSM' is
##              in fact, LR(0), that is does not contain any inadequate
##              states. Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(0) automaton
##               from its CFSM. Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this LR(0) automaton in "pretty-printed" tabular style.
##
##          genGoTo.  Generates the GoTo table for an LR(0) automaton
##              from its CFSM. Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayGoTo.  Displays the GoTo table associated with
##              this LR(0) automaton in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this LR0Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from LRBase (abstract base class).
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(0) CFSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(0) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##

class LR0Machine(LRBase):
    "The LR(0) recogniser for a grammar."
    def __init__(this,grammar,verbose=True):
        LRBase.__init__(this,grammar)
        this.cfsm = this.buildCFSM(verbose)     ## Build the CFSM.
        if verbose: print 35*"=="
        if this.checkLR0(verbose):
            this.actionTable = this.genActions()
            this.gotoTable = this.genGoTo()

    ##----------------------------------------------------------------------
    ##
    ## Build the CFSM for the grammar. Verbose is a flag controlling whether
    ## or not to do lots of output to the terminal describing the progress
    ## of the build. Returns a list of LR0state objects.
    ##
    def buildCFSM(this,verbose):
        "Build the LR(0) CFSM for the supplied grammar."
        states = [LR0State(this.grammar,[(0,0)])]
        states[0].close()
        stateQueue = [0]
        while stateQueue != []:
            stateNum = stateQueue.pop(0)
            state = states[stateNum]
            if verbose:
                print "-------------------------------------------------------"
                print "Working with state %d (%s)" % (stateNum, state)
            for sym,itemSet in state.findTransitions().items():
                candidateNewState = LR0State(this.grammar,itemSet)
                if verbose:
                    s = "   Working with transition on '%s' to { " % sym
                    for targetItem in itemSet:
                        s += "%s" % formatItem(targetItem,this.grammar)
                    s += '}'
                    print "%s\n      Candidate new state is %s" % \
                          (s,candidateNewState)
                isNewState = True
                for i,s in enumerate(states):
                    if candidateNewState.equals(s):
                        isNewState = False
                        state.transitions[sym] = i
                        if verbose:
                            print "            Not new, is existing state %d." % i
                        break
                if isNewState:
                    newStateNumber = len(states)
                    state.transitions[sym] = newStateNumber
                    candidateNewState.close()
                    states.append(candidateNewState)
                    stateQueue.append(newStateNumber)
                    if verbose:
                        print "            New, adding as state %d." \
                              % newStateNumber
        return states

    ##----------------------------------------------------------------------
    ##
    ## displayCFSM -- output the CFSM in "pretty-printed" style.
    ##
    def displayCFSM(this):
        for i,lr0state in enumerate(this.cfsm):
            print "=====================================\nState %d" % i
            for item in lr0state.kernel: print "    (k) %s" % \
                formatItem(item,this.grammar)
            if len(lr0state.closure) > 0:
                for item in lr0state.closure: print "    (c) %s" % \
                    formatItem(item,this.grammar)
            if len(lr0state.transitions) > 0:
                print "  Transitions:"
                for (sym,target) in lr0state.transitions.iteritems():
                    print "    '%s' ==> %d" % (sym,target)
            else:
                print "  No transitions out of this state"

    ##----------------------------------------------------------------------
    ##
    ## checkLR0 -- Check to see if the LR(0) CFSM is correct, i.e., that
    ##      it contains no inadequate states (i.e., no shift-reduce or
    ##      reduce-reduce conflicts).  Returns True if no inadequate LR(0)
    ##      states are found, False otherwise.  If the automaton contains
    ##      inadequate states, reports on them to the output as well.
    ##
    def checkLR0(this,verbose=False):
        if verbose:
            print "Checking if grammar is LR(0)"
            print "============================"
        status = []
        for stateNum,lr0state in enumerate(this.cfsm):
            status.append(lr0state.isAdequate(stateNum,verbose))
        for s in status:
            if not s:
                if verbose: print "It is not LR(0)"
                return False
        if verbose: print "It is LR(0)"
        return True

    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an LR(0) automaton
    ##               from its CFSM.
    ##
    ## What is generated is a list indexed by state number. An entry in the
    ## list is either 'S' (a shift action), 'A' (an accept action), 'E'
    ## (an error -- which happens when there is a shift-reduce or a reduce-
    ## reduce conflict in a state), or a positive number corresponding to
    ## a production number in the augmented grammar associated with the CFSM.
    ##
    ## Note checking.  A dot at the right hand end of an item implies that
    ## the action associated with this state must be a reduce, whereas if
    ## the dot is followed by a terminal, this implies a shift.  Note however,
    ## if the dot is followed by a nonterminal, this implies neither reduce
    ## nor shift, nonterminals don't contribute to the action table.
    ## All that is needed for an state to be LR(0) is that we end up with
    ## a clear shift or reduce decision after examining all the items.
    ##
    ## This routine does not report errors (it just generates 'E' entries
    ## in the Action table).  It is assumed that method 'checkLR0' has been
    ## called previously (the constructor does this).
    ##
    def genActions(this):
        actionTable = []
        for lr0state in this.cfsm:
            doShift = False
            doReduce = False
            reduceIndex = -1
            stateItems = lr0state.kernel.union(lr0state.closure)
            for item in stateItems:
                sym = getDottedSym(item,this.grammar)
                if sym == 'eps':        ## Dot at end => reduce action.
                    if doReduce:        ## Reduce already found, R-R conflict
                        doShift = True  ## Force an error entry by setting a
                        break           ## (bogus) shift flag.
                    else:
                        doReduce = True
                        reduceIndex = item[0]  
                        if doShift: break  ## Error, a (real) S-R conflict.
                elif isterminal(sym):      ## Dot followed by terminal => shift.
                    doShift = True
                    if doReduce: break     ## Error, a (real) S-R conflict.
            if doReduce and not doShift: 
                if reduceIndex == 0:
                    theAction = 'A'  ## Accept on reduce by augmenting prod.
                else:
                    theAction = reduceIndex
            elif doShift and not doReduce:
                theAction = 'S'      ## Shift action
            else:
                ## An error, due to shift-reduce or reduce-reduce conflicts
                ## or no Action specified at all (which should never happen).
                theAction = 'E'
            actionTable.append(theAction)
        return actionTable
    
    ##----------------------------------------------------------------------
    ##
    ## displayAction -- Display the Action table associated with this
    ##                  LR(0) automaton.
    ##
    ## The Action table is a list of parse actions, 'S' for shift, 'A' for
    ## accept, 'E' for table error and positive integers for reduce actions,
    ## (as generated by 'genAction').  This routine just prints the table
    ## out neatly formatted.
    ##
    def displayAction(this):
        if this.actionTable:
            firstColumnWidth=this.getColWidth()
            s    = (firstColumnWidth*' ') + '|'
            line = (firstColumnWidth*' ') + '+'
            for state in range(len(this.actionTable)):
                s += '%3d |' % state
                line += '----+'
            print s
            print line
            s = (firstColumnWidth*' ') + '|'
            for action in this.actionTable:
                if isinstance(action,int): s += ' R%-2d|' % action
                else: s += '  %s |' % action
            print s
            print line
        else:
            print "Action table not available."


    ##----------------------------------------------------------------------
    ##
    ## genDot -- Generate a GraphViz format string representing the
    ##           CFSM of this LR(0) automaton.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## The argument "includeGrammar" governs whther or node to include
    ## a dummy state in the GraphViz output that contains a list of the
    ## grammar's productions.  This is included in the GrapViz as a
    ## "free-floating" state, i.e., one not connected to anything.
    ##
    ##
    def genDot(this,outputForPS=True,includeGrammar=True):
        s = "digraph cfsm {\nrankdir=LR;\n"
        for i,state in enumerate(this.cfsm):
            s += state.genDotHtml(i,outputForPS=outputForPS)
            s += "\n"
        if includeGrammar:
            s += "grammar [shape=none, label=<\n%s>];\n" % \
                 genHtmlGrammar(this.grammar,targetPS=outputForPS)
        for i,state in enumerate(this.cfsm):
            for ch,target in state.transitions.iteritems():
                s += "%d -> %d [label=\"%s\" fontname=\"Helvetica\""% \
                     (i,target,ch)
                s += " fontcolor=\"#40a040\" fontsize=\"11\"];\n"
        s += "}"
        return s

    ##----------------------------------------------------------------------
    ##
    ## outputDot -- Utility to output a GraphViz representation of the
    ##              CFSM of this LR(0) automaton to a file.  The work is
    ##              done by a call to 'genDot' above, this is just a
    ##              wrapper designed to write the results of 'genDot' to
    ##              a specified file.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## 1) Processing chain for default (i.e., GraphViz for PostScript):
    ##
    ## In Python:
    ##
    ##     >>>  lr0g2.outputDot('lr0g2.dot')
    ##
    ## At the shell prompt:
    ##
    ##     $ dot -Tps2 lr0g2.dot > lr0g2.ps
    ##     $ ps2pdf lr0g2.ps
    ##
    ## (or, in one go):
    ##
    ##     $ dot -Tps2 lr0g2.dot | ps2pdf - > lr0g2.pdf
    ##
    ## 2) Processing chain for "generic GraphViz" (i.e., for SVG):
    ##
    ## In Python:
    ##
    ##     >>>  lr0g2.outputDot('lr0g2.dot',outputForPS=False)
    ##
    ## At the shell prompt:
    ##
    ##     $ dot -Tsvg lr0g2.dot > lr0g2.svg
    ##
    def outputDot(this,filename,outputForPS=True,includeGrammar=True):
        f = open(filename,"w")
        print >>f,this.genDot(outputForPS)
        f.close()

        
    ##----------------------------------------------------------------------
    ##
    ## The following methods of this class are utilites needed by routines
    ## from LRBase, and are not designed to be called directly.
    ##
    ##----------------------------------------------------------------------
    ##
    ## lookupAction --  Return the action the LR(0) machine should perform
    ##                  at this point in the parse, based on the state of
    ##                  the current stack and lookahead.  The lookahead is
    ## irrelevant for an LR(0) parse, of course, but it is included in the
    ## argument list here so that the 'SLRMachine' class (which inherits
    ## from this 'LR0Machine' class) can override this method, and so be
    ## able to use the 'parse' method above (since the Action table is the
    ## only thing that differs between an LR(0) and an SLR automaton, this
    ## trivial method promotes code reuse!).  Ditto for an LALRMachine
    ## generated with lalr1-propagate.py.
    ##
    def lookupAction(this,stack,lookahead):
        return this.actionTable[stack[-1]]

    ##----------------------------------------------------------------------
    ##
    ## rejectMessage --  Returns a reject message suitable to a Reject
    ##                   action comming back from the Action table. This 
    ##                   should never happen in a proper LR(0) parse, so
    ## is an error (an LR(0) parse will pick up on illegal input when it
    ## looks at the GoTo table).  For an SLR parse, on the other hand,
    ## rejects in the Action table represent perfectly normal behaviour
    ## on illegal input, so we have this trivial method to allow for
    ## differentiated reporting. Ditto for an LALR(1) machine.
    ##
    def rejectMessage(this):
        return "Reject ERROR: LR(0)"

    ##----------------------------------------------------------------------
    ##
    ## getFSMStateCount --  Returns a count of the number of states in this
    ##                      machine.
    ##
    def getFSMStateCount(this):
        if this.cfsm:
            return len(this.cfsm)
        else:
            return 0

    ##----------------------------------------------------------------------
    ##
    ## getFSM --  Returns the CFSM of the current machine (a list of LR(0)
    ##            states).
    ##
    def getFSM(this):
        if this.cfsm:
            return this.cfsm
        else:
            return None

    ##----------------------------------------------------------------------

        
##==============================================================================
##
## class LR0State -- This represents an LR(0) state, which is a list of
##      items represented as tuples (grammar-index,position).  Separate
##      kernel and closure lists are maintained.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(0) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation of the Item in terms of the
##              underlying grammar production and the ot position.
##
##          equals.  Check to see if this LR(0) state and the argument, 
##              another such state, are equal.  Two LR(0) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR0State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR0States.
##
##          isAdequate.  Return True if this LR0State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state. Note that shift actions
##              only result from items with terminals to the right of
##              their dots.  Items with dots at their right hand ends
##              contribute reduce actions.  Items with nonterminals to
##              the right of their dots don't contribute any action,
##              (i.e., neither shift nor reduce).  An LR(0) state is
##              adequate if it has either (a) exactly one reduce item
##              but no shift items, or (b) one or more shift items but
##              no reduce items.  If it has neither shift nor reduce
##              items, this is an error, and should never happen.
##
##          getInadequateItems.  Return a triple (Boolean,List1,List2).
##              Boolean is True if this state has inadequate items,
##              False if it doesn't.  List1 is a list of all the items
##              in this state in reduce-reduce conflicts.  List2 is a
##              list of all the  shift items in shift-reduce conflicts
##              with the elements of List1.
##
##          genDotHtml.  Generate an HTML representation of this state
##              suitable for inclusion in a Graphviz description of the
##              automaton's graph (i.e., CFSM).
##              If the state is inadequate, outline it in red and display
##              inadequate items in red.
##              If this is a final state of the automaton, display the
##              action associated with the state (i.e., reduce by N or
##              Accept) in blue below the display of items.
##              If parameter 'outputForPS' is True (the default),
##              generate HTML designed to be processed by the -Tps and
##              -Tps2 drivers of the 'dot' program.  If 'outputForPS' is
##              False, generate HTML designed to be processed by the
##              -Tsvg driver of the 'dot' program.
##              If paramter 'stateDisplayName' is omitted, generate the
##              name of the state by prefixing 'State' in front of the
##              'dotInternalName' of the state.
##
##            
class LR0State(object):
    "An LR(0) state is a set of LR(0) items (kernel & closure)."
    def __init__(self,grammar,kernelItems=None):
        self.grammar = grammar
        self.kernel = set()
        self.closure = set()
        if kernelItems != None:
            for item in kernelItems: self.kernel.add(item)
        self.transitions = dict()
        
    def addItem(self,item):
        "Add another LR(0) item to the kernel set of this state."
        self.kernel.add(item)

    def close(self):
        "Close this state."
        itemQueue=list()
        for item in self.kernel:
            for newItem in makeItemClosure(item,self.grammar):
                if not newItem in self.kernel and not newItem in self.closure:
                    self.closure.add(newItem)
                    itemQueue.append(newItem)
        while len(itemQueue) > 0:
            item = itemQueue.pop(0)
            for newItem in makeItemClosure(item,self.grammar):
                if not newItem in self.kernel and not newItem in self.closure:
                    self.closure.add(newItem)
                    itemQueue.append(newItem)
            
    def __repr__(self):
        s = '{ kernel('
        for item in self.kernel:
            s += formatItem(item,self.grammar)
        s += ') closure('
        for item in self.closure:
            s += formatItem(item,self.grammar)
        s += ') }'
        return s

    def equals(self,lr0state):
        "Check for equality with another LR(0) State."
        return len(self.kernel.symmetric_difference(lr0state.kernel)) == 0

    def findTransitions(self):
        """Find symbols marking transitions out of this state & the
           associated items which result from these transitions."""
        trans = dict()
        for item in self.kernel.union(self.closure):
            sym = getDottedSym(item,self.grammar)
            if sym != 'eps':
                newItem = advanceDot(item,self.grammar)
                if trans.has_key(sym): trans[sym].add(newItem)
                else: trans[sym] = set([newItem])
        return trans

    def isAdequate(self,stateName=0,verbose=False):
        """Return True if this state is LR(0) adequate, False otherwise.
           Parameter "stateName" is only needed if verbose output is
           requested, and should, in this case, be the name of the state
           being checked."""
        (hasInadequates,rItems,sItems) = self.getInadequateItems()
        if hasInadequates:
            if verbose:
                print "State %s is inadequate" % str(stateName)
                if len(rItems) > 1:
                    print "  Reduce-Reduce conflicts"
                    for item in rItems:
                        print "    %s" % formatItem(item,self.grammar)
                if len(sItems) > 0:
                    print "  Shift-Reduce conflicts"
                    print "    Reduce items are:"
                    for item in rItems:
                        print "      %s" % formatItem(item,self.grammar)
                    print "    Shift items are:"
                    for item in sItems:
                        print "      %s" % formatItem(item,self.grammar)
        return not hasInadequates


    def getInadequateItems(self):
        """Return a triple (Boolean,List1,List2).  Boolean is True if this state has
           inadequate items, False if it doesn't.  List1 is a list of all the items
           in this state in reduce-reduce conflicts.  List2 is a list of all the 
           shift items in shift-reduce conflicts with the elements of List1."""
        sItems = []
        rItems = []
        for item in self.kernel.union(self.closure):
            sym = getDottedSym(item,self.grammar)
            if sym == 'eps': rItems.append(item)
            elif isterminal(sym): sItems.append(item)
        if len(rItems) > 1 or len(rItems) >= 1 and len(sItems) > 0:
            return (True,rItems,sItems)
        else:
            return (False,[],[])



    def genDotHtml(self,dotInternalName,stateDisplayName=None,outputForPS=True):
        """Generate a Graphviz language HTML representation of this state.  If
           the state is inadequate, outline it in red and display inadequate
           items in red.
           
           If this is a final state of the automaton, display the action
           associated with the state (reduce by N or Accept) in blue below
           the display of items.
           
           If parameter 'outputForPS' is True (the default),
           generate HTML designed to be processed by the -Tps and -Tps2
           drivers of the 'dot' program.  If 'outputForPS' is False,
           generate HTML designed to be processed by the -Tsvg driver of
           the 'dot' program.

           If paramter 'stateDisplayName' is omitted, generate the name
           of the state by prefixing 'State' in front of the
           'dotInternalName' of the state."""
        (hasInadequates,rItems,sItems) = self.getInadequateItems()
        if hasInadequates: stateBorderColour = "red"
        else: stateBorderColour = "black"
        if not stateDisplayName: stateDisplayName = "State %s" % str(dotInternalName)
        s = """%s [shape=box, style="rounded", color="%s", """ %\
            (dotInternalName,stateBorderColour)
        if len(self.transitions) == 0:   ## A final state of the CFSM, with no transitions out.
            s += "peripheries=\"2\", "
        s += 'label=<\n<table border="0" cellborder="0" cellspacing="2" cellpadding="0">\n'
        s += '<tr>\n    <td colspan="4"><font color="#40a040">%s</font></td>\n</tr>\n' %\
               stateDisplayName
        for item in self.kernel:
            if item in rItems or item in sItems: itemColour = "red"
            else: itemColour = "black"
            s += '<tr>\n%s    <td><font point-size="7">(k)</font></td>\n</tr>\n' %\
                 formatItemAsHtml(item,self.grammar,itemColour,outputForPS)
        for item in self.closure:
            if item in rItems or item in sItems: itemColour = "red"
            else: itemColour = "black"
            s += '<tr>\n%s    <td><font point-size="7">(c)</font></td>\n</tr>\n' %\
                 formatItemAsHtml(item,self.grammar,itemColour,outputForPS)
        ## If a final state, or a state *with only* one reducing item and *no*
        ## shift items, report reducing production, if possible.
        if not hasInadequates:
            if len(self.transitions) == 0: ## A final state of this CFSSM, with no transitions out.
                prodIndex = list(self.kernel)[0][0]
                if prodIndex == 0: action = 'Accept'
                else: action = "R%d" % prodIndex
            else: ## Not a final state, but maybe there is just one reducing item and no shift items.
                shiftItems = []
                reduceItems = []
                for item in self.kernel.union(self.closure):
                    context = getDottedSym(item, self.grammar)
                    if context == 'eps': reduceItems.append(item)
                    elif isterminal(context): shiftItems.append(item)
                if len(shiftItems) == 0 and len(reduceItems) == 1:
                    print "State '%s': discovered a single reduce action associated with " % stateDisplayName
                    print "this (non-terminal) state on item: %s" % formatItem(reduceItems[0], self.grammar)
                    action = 'R%d' % reduceItems[0][0]
                else:
                    action = None
            if action:
                s +='<tr>\n    <td colspan="4"><font point-size="9" face="Helvetica" '
                s += 'color="#2020f0">%s</font></td>\n</tr>' % action
        s += "</table>>];"
        return s


##==============================================================================
##
##
## Utility routines for working with LR(0) items represented as tuples.
##
##
##------------------------------------------------------------------------------
##
## advanceDot - Advance the dot one position to the right in an LR(0) item,
## returning a new LR(0) item representing the result of the advance.
##
## N.B., if the dot is already at the end of the rhs of the item, simply
## return the original item, as no advance is possible in this case.
##

def advanceDot(item,grammar):
    "Advance the dot one position to the right in an item (if possible)."
    (p_index,dot_index) = item
    if dot_index < len(grammar[p_index].rhs):
        return (p_index,dot_index+1)
    else:
        return item


##------------------------------------------------------------------------------
##
## formatItem - Return a "pretty-print" string representing an item in terms
## of its underlying Production (this is why the 'grammar' argument is needed.
##

def formatItem(item,grammar):
    "Generate a string representation of an item."
    DOT = ' _'
    (p_index,dot_index) = item
    prod = grammar[p_index]
    s = '[ %s -->' % prod.lhs
    l = len(prod.rhs)
    if l == 0:
        s += ' eps' + DOT
    else:
        for i in range(l):
            if i == dot_index: s += DOT
            s += ' %s' % prod.rhs[i]
        if dot_index >= l: s += DOT
    s += ' ]'
    return s


##------------------------------------------------------------------------------
##
## formatItemAsHtml - Return a representation of the item as an HTML-formatted
## string suitable for display in a Graphviz (i.e., DOT) representation.
##
## Note the parameter 'outputForPS'.  If this is True (the default), then
## this routine outputs HTML for the item that is optimised to be processed
## by the '-Tps' or '-Tps2' modes of the "dot" program.  This means that
## explicit switches are made into the 'Symbol' font by the HTML in order
## to display the "read-head dot" symbol and the "right arrow" symbol.
##
## If the parameter is False, then the code uses the Unicode "bull"
## character (code #8226) for the "read-ahead dot" and the Unicode
## "rarr" character (code #8594) for the "right arrow", along with the
## Unicode "epsilon" character (code #949) for epsilon, and omits explicit
## calls to switch into the 'Symbol' font.  The PostScript drivers in
## Graphviz unfortunately do not understand this cleaner HTML.  The
## SVG driver (-Tsvg), amongst others, does, but doesn't understand the
## explicit switches into the 'Symbol' font, and messes up its output
## if it sees these (n.b., unfortunately, the SVG driver doesn't
## understand the HTML names, &epsilon;, &rarr; and &bull;, so we
## need explicit character codes in this case too).
##
## Hence the need for the 'outputForPS' parameter, it's a workaround
## for the shortcomings of the Graphviz HTML parsers.
##
##

def formatItemAsHtml(item,grammar,itemColour,outputForPS=True):
    "Generate an HTML representation of an item (as part of a table)."
    DOT = '<font color="purple"'
    if outputForPS: DOT += ' face="Symbol">&#183;</font>' ## 183 is a filled circle in Symbol.
    else: DOT += '>&#8226;</font>'  ## SVG driver doesn't understand HTML &bull;, so need code.
    (p_index,dot_index) = item
    prod = grammar[p_index]
    ## Output the LHS of the Item. Note the check for < > brackets.
    if prod.lhs[0] == '<':  lhs = ('&lt;%s&gt;' % prod.lhs[1:-1])
    else: lhs = prod.lhs
    s =  '    <td align="right"><font face="Times-Italic"'
    s += ' color="%s" point-size="10">%s</font></td>\n' % (itemColour,lhs)
    ## Output the arrow '-->' according to whether this is for PS or SVG.
    s += '    <td align="center"><font color="%s" point-size="12"' % itemColour
    if outputForPS: s += ' face="Symbol">&#174;' ## 174 is a right-arrow in the Symbol font.
    else: s += '>&#8594;'  ## SVG driver doesn't understand HTML &rarr;, so need code.
    ## Output the RHS of the Item.  Note the special handling of the \eps Item.
    s += '&#32;</font></td>\n    <td align="left">'
    l = len(prod.rhs)
    if l == 0:  ## Item has an empty RHS, special handling of the dot.
        s += '<font point-size="10" color="%s"' % itemColour
        if outputForPS: s += ' face="Symbol">e'
        else: s += '>&#949;'  ## SVG driver doesn't understand HTML &epsilon;, so need code.
        s += DOT
    else:  ## Non-empty RHS, walk over the elements.
        s += '<font face="Times-Italic" color="%s" point-size="10">' % itemColour
        for i in range(l):
            if i == dot_index: s += DOT  ## Insert the dot.
            element = prod.rhs[i]
            ## Note special handing of < > brackets.
            if element[0] == '<':  s += ('&lt;%s&gt;' % element[1:-1])
            else: s += '%s' % element
        if dot_index >= l: s += DOT
    s += '</font></td>\n'
    return s




##------------------------------------------------------------------------------
##
## getDottedSym - Return the symbol immediately to the right of the dot in an
## item.  If the dot is at the end of an item, return 'eps' as a marker for
## the null string (i.e., there is no real symbol avaiable).
##

def getDottedSym(item,grammar):
    "Return the symbol immediately to the right of the dot."
    prod = grammar[item[0]]
    if item[1] >= len(prod.rhs): return 'eps'
    else: return prod.rhs[item[1]]


##------------------------------------------------------------------------------
##
## makeItemClosure - return a list of new items that are the closure of the
## first argument (an item), in the context of the second (a grammar).
##

def makeItemClosure(item,grammar):
    "Generate a list of new items that are the closure of the first argument."
    closure = []
    sym = getDottedSym(item,grammar)
    if isnonterminal(sym):
        for p_index,prod in enumerate(grammar):
            if prod.lhs == sym: closure.append((p_index,0))
    return closure


####==============================================================================
####==============================================================================
####==============================================================================
####
#### Debugging
#### 
####
##
##from grammars import *
##print "G1 = ", G1
##print "G2 = ", G2
##print "G3 = ", G3
##
##lr0g1=LR0Machine(G1,False)
##lr0g2=LR0Machine(G2,False)
##lr0g3=LR0Machine(G3,False)
##
##print "lr0g1 = ", lr0g1
##print "lr0g2 = ", lr0g2
##print "lr0g3 = ", lr0g3
