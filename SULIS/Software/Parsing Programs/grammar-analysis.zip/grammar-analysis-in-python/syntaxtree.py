##==============================================================================
##
## syntaxtree.py
##
## Routines for the manipulation and presentation of Syntax Trees.
##
##------------------------------------------------------------------------------
##
## Main Routines:
##
##      1) outputASCII(st)
##          Output the syntax tree as an ASCII-formatted tree structure on the
##          standard output (the tree is shown "sideways on"). 
##          Gives a quick view of the syntax tree structure.
##          
##          Argument:
##              st -- A syntax tree in the format described below.
##
##
##      2) outputTk(st)
##          Output the syntax tree as a diagram in a Tk Canvas widget window.
##          
##          Argument:
##              st -- A syntax tree in the format described below.
##
##
##      3) outputPS(st,filename)
##          Output the syntax tree as a diagram in a Tk Canvas widget window.
##          
##          Arguments:
##              st -- A syntax tree in the format described below.
##
##              filename -- A string, the name of the file to write.
##
##
##      4) outputDot(st,filename,outputForPS=True)
##          Write a DOT-language description of a syntax tree into a file.
##
##          Arguments:
##              st -- A syntax tree in the format described below.
##
##              filename -- A string, the name of the file to write.
##
##              outputForPS -- A Boolean.  If True (the default) generates
##                             a DOT-language description suitable for
##                             processing by the "-Tps" and "-Tps2" modes
##                             of "dot", which generate PostScript.  If
##                             False, generates DOT for all the other "dot"
##                             filters (including the -Tpdf" filter).  
##
## 
## N.B.  "outputDot" works, but the node placement is not very good (due
##       to known bugs in "dot").  Use "outputPS" instead, better node
##       placement for this problem of generating graphical diagrams of
##       syntax trees.
##
##------------------------------------------------------------------------------
##
##
## Using the routines defined in this module:
##
## (1) Import it into one of the analysis programs such as lalr1-propagate.
##
##     >>> import syntaxtree
##
## (2) Feed the output of a "parseST" run into "outputPS" like so:
##
##     >>> m1=LALR1PrecMachine(G1,{})
##     >>> syntaxtree.outputPS(m1.parseST("a b b b a a"),"st1.ps")
##
## (3) At the shell, process the file "st1.ps".
##
##     $ ps2pdf st1.ps
##
## The other routines are similar. "outputASCII" and "outputTk" don't need any
## postprocessing, "outputDot" needs to have its output run through "dot".
##
##
##------------------------------------------------------------------------------
##
##
## The format of a syntax tree data structure is as follows:
##
## (1) A syntax tree is either a simple Python string or a Python 2-tuple
##
## (2) If it is a simple Python string, this is the name of a terminal.
##
## (3) If it is a 2-tuple, it represents a nonterminal along with its
##     expansion in the syntax tree.
##
##        Element 0 of the tuple is a Python string which is the
##        nonterminal's name
##
##        Element 1 represents how this nonterminal has been expanded.
##        It is either a single element or a list of N elements,
##        corresponding to the symbol(s) on the RHS of the production
##        being expanded.  Each element is *recursively* a syntax tree,       
##        i.e., a simple string representing a terminal, or a 2-tuple
##        representing a subtree of the syntax tree.
##        
##
## For example, consider the LR(1) grammar:
##
##          E --> E + T   (1)
##          E --> T       (2)
##          T --> T * id  (3)
##          T --> id      (4)
##
## and input string "id + id * id". The corresponding syntax tree for
## this string parsed according to this grammar is the Python data 
## structure:
##
## ('E', [('E', ('T', 'id')), '+', ('T', [('T', 'id'), '*', 'id'])])
##
## If this is "pretty-printed" the tree structure becomes clear:
##
##     ('E', [('E', ('T', 'id')),
##            '+',
##            ('T', [('T', 'id'),
##                   '*',
##                   'id'])])
##
## Note how "unit" expansions, e.g., "T --> id", generate
## 2-tuples without embedded lists: "('T', 'id')", but
## other expansions have embedded lists.
##
##
##
##------------------------------------------------------------------------------
##
from defs import isterminal, isnonterminal

##------------------------------------------------------------------------------
##
## outputASCII.  Display a syntax tree as an ASCII formatted tree on the
##               terminal.
##
##    Argument 1 "st" is the tree, in the syntax tree format described
##               above.
##
##    Arguments 2 and 3 are internal arguments, used in the recursive
##               formatting of the tree.  They should not be modified
##               by the user. (Argument 2, "indent1" is the indentation 
##               string of a "primary" branch of the tree, Argument 3, 
##               "indent2", is the indentation string of a "secondary" 
##               branch.  A "primary branch" is that portion of the tree 
##               that appears on the same line of output as the nonterminal 
##               generating it, a secondary branch is the portion of the tree 
##               appearing on subsequent lines.
##
##
def outputASCII(st,indent1='',indent2=''):
    "Display a syntax tree as an ASCII formatted tree on the terminal."
    if isinstance(st,tuple):
        if isinstance(st[1],list):
            if len(st[1]) == 0:
                print indent1+('%s ---> \\eps' % st[0])
            elif len(st[1]) == 1:
                outputASCII(st[1][0],
                            indent1+'%s ---> ' % st[0],indent2)
            else:
                spaces = len(st[0])*' '
                outputASCII(st[1][0],
                            indent1+('%s -+-> ' % st[0]),
                            indent2+('%s  |   ' % spaces))
                for i in range(1,len(st[1])-1):
                    print indent2+('%s  |   ' % spaces)              
                    outputASCII(st[1][i],
                                indent2+('%s  +-> ' % spaces),
                                indent2+('%s  |   ' % spaces))
                print indent2+('%s  |   ' % spaces)
                outputASCII(st[1][-1],
                            indent2+('%s  +-> ' % spaces),
                            indent2+('%s      ' % spaces))
        else:
            outputASCII(st[1],
                        indent1+('%s ---> ' % st[0]),
                        indent2)
    else:
        print indent1+st


##------------------------------------------------------------------------------
##
## outputDot.  Generate a DOT format representation of the syntax tree (using
##             genDotV1 and walkTreeV1 to do the DOT generation and tree walk)
##             and output it to a text file.
##
##    Argument 1, "st", is the syntax tree.
##    Argument 2, "filename" is a string containing the name of the file to
##                be written.
##    Argument 3, "outputForPS" is a mode flag.  If True (the default), the
##                generated DOT-language description of the tree is
##                optimised for graph generation using the "-Tps2" processing 
##                flag of the "dot" program.  If False, the generated DOT
##                code is optimised for processing by any of the "dot"
##                filters that can handle Unicode characters (this includes
##                the "-Tpdf" and "-Tsvg" filters.
##
##
def outputDot(st,filename,outputForPS=True):
    "Output a DOT representation of a syntax tree to a file."
    f = open(filename,"w")
    print >>f,genDotV1(st,outputForPS)
    f.close()


 
##------------------------------------------------------------------------------
##
## genDotV1 / walkTreeV1 -- this pair of routines works by frst walking over the
## tree building a node list of nodes and their links, then generating the
## dot output.  Works pretty well -- the only problem is that the clustering of
## subgraphs is lot in this process (essentailly one of "flattening" the tree's
## hierarchy., so sometimes "dot" lays out the resulting trees in asthetically
## unpleasing ways; they are correct, in that they show the nodes and links in
## the right order, and correctly connected, but sometimes nodes are placed in
## unsatisfying positions.  There seems to be no really easy way to solve this,
## but genDotV2/walkTreeV2 (below) tries to do it by using clustering info.
## Unfortunately, due to bugs in dot do to with the interaction of mode
## 'ordering="out"' with clusters, that approach doesn't work well either.
##
##    
def genDotV1(st,outputForPS=True):
    "Return a string representing this syntax tree in the DOT (Graphviz) language."
    s = 'digraph syntaxtree {\n' +\
        '    ordering="out";' +\
        '    node [height="0.1", width="0.1", shape="box", ' +\
            'fontsize="11", fontname="Helvetica", peripheries="0"];\n' +\
        '    edge [color="blue", arrowsize="0.5"];\n'
    nodelist=[]
    walkTreeV1(st,nodelist)
    for i,node in enumerate(nodelist):
        s += '    %d [label=' % i
        if node[0] == '\\epsilon':
            s += '<<font point-size="12" face='
            if outputForPS: s += '"Symbol">e'
            else: s += '"Times-Roman">&#949;'
            s += '</font>>'
        elif isterminal(node[0]):
            s += '"%s" fontcolor="#40a040"' % node[0]
        else:
            s += '"%s"' % node[0]
        s += '];\n'
    for i,node in enumerate(nodelist):
        for target in node[1]: s += '    %d -> %d;\n' % (i,target)
    s += '}'
    return s


def walkTreeV1(st,nodelist,parentlinklist=None):
    "Walk (recursively) over a tree, filling in a list of nodes and links as we go."
    if parentlinklist != None:
        parentlinklist.append(len(nodelist))
    if isinstance(st,str): ## A terminal.
        nodelist.append((st,[]))
    else:
        node = (st[0],[])
        nodelist.append(node)
        if isinstance(st[1],list):
            if len(st[1]) == 0:  ## Empty list => null production
                walkTreeV1('\\epsilon',nodelist,node[1])
            else:
                for subtree in st[1]: walkTreeV1(subtree,nodelist,node[1])
        else:
            walkTreeV1(st[1],nodelist,node[1])

##------------------------------------------------------------------------------
##
## genDotV2 / walkTreeV2 -- this pair of routines works by using the "subgraph
## cluster" facilities of the DOT language to force layout of subgraphs first.
## Must more of the work falls to the tree-walking routine, which here both
## traverses the tree and generates the DOT code for the tree "en passant".
## On the way it recognises subgraphs and writes out the appropriate "subgraph
## clusterXX" information.
## 
## One interesting caveat: dot seems to require that the links info "0 -> 1",
## etc., come *after* all the subgraphs are constructed, this is why the
## link info strings are constructer by "walkTreeV2" and accumulated in a
## list which is eventually passed back to "genDotV2", this routine then
## writes them all out at the end. (An intial version mixed the link info
## into the clusters, with the result that the nodes ended up being displayed
## in the wrong order.)
## 
##
def genDotV2(st,outputForPS=True):
    s =  'digraph syntaxtree {\n' +\
         '    splines=False;\n'   +\
         '    margin="0.1";\n'    +\
         '    pad="0.0";\n'       +\
         '    ordering="out";\n'  +\
         '    node [height="0.3", width="0.4", shape="box", fontsize="11", ' +\
             'fontname="Helvetica", peripheries="0"];\n' +\
         '    edge [color="blue", arrowsize="0.5"];\n'
    s,nodenum,clusternum,linklist=walkTreeV2(st,s,0,0,4,None,[],outputForPS)
    print linklist
    linklist.sort(key=lambda e: e[0]*10000+e[1])
    print  linklist
    for link in linklist: s += ('    %d -> %d;\n' %(link[0],link[1]))
    s += '}'
    return s

def walkTreeV2(st,s,nodenum,clusternum,indent,parentnodenum,linklist,outputForPS):
    if isinstance(st,str):
        s += (indent*' ')
        s += '%d [label=' % nodenum
        if st == '':
            s += '<<font point-size="12" face='
            if outputForPS: s += '"Symbol">e'
            else: s += '"Times-Roman">&#949;'
            s += '</font>>'
        else:
            s += '"%s"' % st
            if isterminal(st): s += ' fontcolor="#40a040" '
        s += '];\n'
        if parentnodenum != None:
            linklist.append((parentnodenum,nodenum))
        nodenum += 1        
    else:
        if parentnodenum != None:
            s += (indent*' ') + ('subgraph cluster%d {\n' % clusternum)
            newindent = indent + 4
            s += (newindent*' ') + ('color=none\n')
            clusternum += 1
        else:
            newindent = indent
        newparentnodenum = nodenum
        s,nodenum,clusternum,linklist=walkTreeV2(st[0],s,nodenum,clusternum,newindent,\
                                                 parentnodenum,linklist,outputForPS)
        if isinstance(st[1],str):
            s,nodenum,clusternum,linklist,=walkTreeV2(st[1],s,nodenum,clusternum,newindent,\
                                                      newparentnodenum,linklist,outputForPS)
        else:
            if st[1] == []:
                s,nodenum,clusternum,linklist=walkTreeV2('',s,nodenum,clusternum,newindent,\
                                                         newparentnodenum,linklist,outputForPS)
            else:
                for element in st[1]:
                    s,nodenum,clusternum,linklist=walkTreeV2(element,s,nodenum,clusternum,\
                                                             newindent,newparentnodenum,\
                                                             linklist,outputForPS)
        if parentnodenum != None: s += (indent*' ') + '}\n'
    return s,nodenum,clusternum,linklist



##------------------------------------------------------------------------------
##
## outputTk.  Open a Python TkInter graphics window (a Canvas widget) and
##            display a graphical representation of the syntax tree on it.
##
##    Argument "st", is the syntax tree.
##
##
def outputTk(st):
    TkDrawing(SyntaxTreeGraph.build(st))    

##------------------------------------------------------------------------------
##
## outputPS.  Generate a PostScript representation of the syntax tree and
##            write it to a file.
##
##    Argument 1, "st", is the syntax tree.
##    Argument 2, "filename" is a string containing the name of the file to
##                be written.
##
##
def outputPS(st,filename=None):
    "Output a PostScript representation of a syntax tree to a file."
    PostScript(SyntaxTreeGraph.build(st),filename)


##------------------------------------------------------------------------------
##
## SyntaxTreeGraph is an internal class.  It is used to represent a syntax
## tree with positioning information embedded in it.  Positioning is based on
## a notional millimetre measuring system, with 10mm being the "unit of
## separation between subtrees.
##
## SyntaxTreeGraph has two subclasses, PrimStGraph, which represents a single
## node (a terminal or epsilon), and CompositeStGraph, representing a syntax
## tree with embedded subtrees.
##
## SyntaxTreeGraph can draw itself on a "DrawingSurface" object that provides
## methods to draw text and arrows at particular positions.  See below for two
## concrete implementations of DrawingSurface, one for TkInter and one
## for PostScript.
##
## The main work in SyntaxTreeGraph construction is carried out by routine
## "build", a static method of the class.  This takes a syntax tree in the
## format defined above and converts it into a SyntaxTreeGraph.
##
## The major attributes of SyntaxTreeGraph are:
##
##     Its width and height, which define a bounding box within which
##     all the elements of this graph will be drawn.
##
##     Its (x,y) position, which is the offset of the bottom left hand
##     corner of this SyntaxTreeGraph relative to the SyntaxTreeGraph
##     that encloses it.
##
##     Its rootname, which is the name of the root of this graph (a string).
##
##     Its rootdx and rootdy offsets.  These are the offsets of the centre
##     of the rootname string relative to the bottom left hand corner of its 
##     bounding box.
##
## CompositeStGraph objects also contain a list "subtrees", of subtrees of   
## the current object.  These are themselves SyntaxTreeGraph objects.
##
##
class SyntaxTreeGraph(object):
    def __init__(this,name='?'):
        this.rootname = name
        this.x = 0
        this.y = 0
        this.width = 10
        this.height = 10
        this.rootdx = 5
        this.rootdy = 5

    def drawRootName(this,drawingsurface,x,y):
        if this.rootname == '\\eps': colour="#f02020"       ## Red for epsilons
        elif isterminal(this.rootname): colour="#40a040"   ## Green for terminals
        else: colour="black"                                ## Black for nonterminals
        drawingsurface.drawText(x+this.x+this.rootdx,y+this.y+this.rootdy,\
                                this.rootname,colour)

    @staticmethod
    def build(st):
        "Convert a Syntax tree into a 'Syntax Tree Graph' (with pos info)."
        if isinstance(st,tuple):
            if st[1] == []:
                return CompositeStGraph(st[0],[PrimStGraph('\\eps')])
            elif isinstance(st[1],list):
                subtrees = []
                for s in st[1]: subtrees.append(SyntaxTreeGraph.build(s))
                return CompositeStGraph(st[0],subtrees)
            else:
                return CompositeStGraph(st[0],[SyntaxTreeGraph.build(st[1])])
        else:
            return PrimStGraph(st)
               
        
class PrimStGraph(SyntaxTreeGraph):
    def __init__(this,name='?'):
        SyntaxTreeGraph.__init__(this,name)

    def draw(this,drawingsurface,x,y):
        this.drawRootName(drawingsurface,x,y)


class CompositeStGraph(SyntaxTreeGraph):
    def __init__(this,rootname,subtreelist):
        SyntaxTreeGraph.__init__(this,rootname)
        this.rootname = rootname
        this.subtrees = subtreelist[:]
        maxheight = max([subtree.height for subtree in this.subtrees])
        this.height= maxheight+20
        this.width = sum([subtree.width for subtree in this.subtrees])
        if len(this.subtrees) > 1:
            this.width += (len(this.subtrees)-1)*10
            dx = 0
            for subtree in this.subtrees:
                subtree.x += dx ; dx += (subtree.width + 10)
                if subtree.height < maxheight:
                    subtree.y += (maxheight - subtree.height)
            ## If this node has an odd number of children, align
            ## the parent nonterminal with the root of the
            ## child in the middle of the list.
            if (len(this.subtrees) & 1):
                middleindex = len(this.subtrees) / 2
                this.rootdx = this.subtrees[middleindex].x + \
                              this.subtrees[middleindex].rootdx
            ## Otherwise (even number of children), put the
            ## parent node midway between the first and the last
            ## child node roots.
            else:
                this.rootdx = (this.subtrees[0].x + \
                               this.subtrees[0].rootdx + \
                               this.subtrees[-1].rootdx + \
                               this.subtrees[-1].x) / 2.0   
        else:
            this.rootdx = this.subtrees[0].rootdx
        this.rootdy = maxheight+15
        
    def draw(this,drawingsurface,x,y):
        this.drawRootName(drawingsurface,x,y)
        x1 = x + this.x + this.rootdx
        y1 = y + this.y + this.rootdy
        for subtree in this.subtrees:
            subtree.draw(drawingsurface,x+this.x,y+this.y)
            x2 = x + this.x + subtree.x + subtree.rootdx
            y2 = y + this.y + subtree.y + subtree.rootdy
            drawingsurface.drawArrow(x1,y1,x2,y2,colour="blue",radius=5)

        
        
###########################################################################################
##
## Device-specific drawing routines, encapsulated as subclasses of the abstract base
## class "DrawingSurface".  Put device-drivers for different classes of output device
## in here.
##
## DrawingSurface: Simply an abstract base class for all device-driver drawing classes.
##
import math
from Tkinter import *

class DrawingSurface(object):
    pass

##-------------------------------------------------------------------
##
## TkDrawing: a class that draws an syntaxtree on a Tk canvas widget.
##
## Use: Simply create a TkDrawing object with a syntax tree graph
## as argument:
##
## >>> TkDrawing(st)
##
##
class TkDrawing(DrawingSurface):
    SCALE = 4
    OFFSET = 20
    
    def __init__(this,stgraph):
        this.stgraph = stgraph
        this.root = Tk()
        this.canvas = Canvas(width  = TkDrawing.SCALE*stgraph.width + 2 * TkDrawing.OFFSET,
                             height = TkDrawing.SCALE*stgraph.height + 2 * TkDrawing.OFFSET,
                             bg='white', master=this.root)
        this.canvas.pack(expand=YES, fill=BOTH)
        this.stgraph.draw(this,0,0)
        this.canvas.mainloop()
        ##this.root.destroy()
        
    def drawArrow(this, x1, y1, x2, y2, colour=None,radius=5):
        x1 = x1 * TkDrawing.SCALE + TkDrawing.OFFSET
        x2 = x2 * TkDrawing.SCALE + TkDrawing.OFFSET
        y1 = (this.stgraph.height - y1) * TkDrawing.SCALE + TkDrawing.OFFSET
        y2 = (this.stgraph.height - y2) * TkDrawing.SCALE + TkDrawing.OFFSET
        theta = math.atan2(y2-y1,x2-x1)
        radius *= TkDrawing.SCALE
        dx = radius * math.cos(theta)
        dy = radius * math.sin(theta)
        x1 += dx ; y1 += dy
        x2 -= dx ; y2 -= dy
        if colour==None: colour="black"
        this.canvas.create_line(x1, y1, x2, y2, arrow=LAST, fill=colour)

    def drawCircle(this, x, y, radius, colour=None):
        y = this.stgraph.height - y
        x1 = (x - radius) * TkDrawing.SCALE + TkDrawing.OFFSET
        x2 = (x + radius) * TkDrawing.SCALE + TkDrawing.OFFSET
        y1 = (y - radius) * TkDrawing.SCALE + TkDrawing.OFFSET
        y2 = (y + radius) * TkDrawing.SCALE + TkDrawing.OFFSET
        if colour==None: colour="black"
        this.canvas.create_oval(x1, y1, x2, y2, fill='white', color=colour)

    def drawText(this, x, y, string, colour=None, ptsize=12):
        x = x * TkDrawing.SCALE + TkDrawing.OFFSET
        y = (this.stgraph.height - y) * TkDrawing.SCALE + TkDrawing.OFFSET
        if colour==None: colour="black"
        if string=='\\eps':
            this.canvas.create_text(x, y, text='e', font="Symbol", fill=colour)
        else:
            this.canvas.create_text(x, y, text=string, font="Helvetica", fill=colour)


##-------------------------------------------------------------------
##
## PostScript: a class that generates a PostScript representation of
##              finite-syntaxtree graph.
##
## Use: Simply create a PostScript object with an syntax tree graph 
## and a filename as arguments:
##
## >>> PostScript(stgraph,"st.eps")
##
## The generated PostScript can be converted to pdf using "ps2pdf".
## It contains a CropBox, so that the final pdf is (noramlly)
## correctly clipped.
##
## N.B., it may be necessary to specify a large paper
## size to ps2pdf, otherwise, if the width of the graph is wider
## than 210mm (the default A4 paper width built in to ghostscript),
## the graph will be cropped at this width regardless of the settings
## of the CropBox and BoundingBox in the PostScript output.  There
## should be a way to fix this in the generated PostScript, but I
## can't find it, so the proposed current solution is to specify
## a very wide paper size in the ps2pdf call, e.g.,
##
##   $ ps2pdf -sPAPERSIZE=a0 stgraph.eps
##
## (where "nfagraph.eps" is the file containing PostScript code
## generated by this routine).
##        

class PostScript(DrawingSurface):
    SCALE = 72.0 / 25.4   ## Postscript points to millimeters scaling.
    OFFSET = 10.0         ## Put a 10-pt border around the drawing.
    R2D = 180.0 / math.pi
    
    def __init__(this,stgraph,outputFileName=None):
        this.stgraph = stgraph
        old_outputstream = sys.stdout
        try:
            if outputFileName and isinstance(outputFileName,str):
                ## print "Attempting to open file", outputFileName
                new_outputstream = open(outputFileName, "w")
                ## print new_outputstream
                sys.stdout = new_outputstream
            this.outputPreamble()
            this.stgraph.draw(this,0,0)
            if outputFileName:
                sys.stdout = old_outputstream
                new_outputstream.close()
        except IOError:
            print "Output problem", IOError
            sys.stdout = old_outputstream

    def outputPreamble(this):
        print ("%!EPSF-3.0")
        w = PostScript.SCALE * this.stgraph.width + 2 * PostScript.OFFSET
        h = PostScript.SCALE * this.stgraph.height  + 2 * PostScript.OFFSET
        print ("%sBoundingBox: 0 0 %d %d" % ("%%",w,h))
        print ("%sCropBox: 0 0 %d %d" % ("%%",w,h))
        print ("%sDocumentFonts: Times-Roman" % "%%")
        print ("%sEndComments" % "%%")
        print ("[ /CropBox [ 0 0 %d %d ] /PAGES pdfmark" % (w,h)) 

    def drawArrow(this, x1, y1, x2, y2, colour=None, radius=5):
        x = x1 * PostScript.SCALE + PostScript.OFFSET
        y = y1 * PostScript.SCALE + PostScript.OFFSET
        radius *= PostScript.SCALE
        length = math.sqrt((y2-y1)**2+(x2-x1)**2) * PostScript.SCALE
        angle = PostScript.R2D * math.atan2(y2-y1, x2-x1)
        print ("gsave %f %f translate %f rotate" % (x,y,angle))
        PostScript.outputPSColour(colour)
        print ("newpath %f 0 moveto %f 0 lineto stroke" % (radius,length-radius-3))
        print ("%f 0 translate" % (length-radius) )
        print ("newpath 0 0 moveto -7.5 3 rlineto 3 -3 rlineto -3 -3 rlineto")
        print ("closepath fill grestore")
        
    def drawCircle(this, x, y, radius, colour=None):
        x = x * PostScript.SCALE + PostScript.OFFSET
        y = y * PostScript.SCALE + PostScript.OFFSET
        radius *= PostScript.SCALE
        print ("0 setgray")
        print ("newpath %f %f %f 0 360 arc fill" % (x,y,radius))
        PostScript.outputPSColour(colour)
        print ("newpath %f %f %f 0 360 arc stroke" % (x,y,radius))

    def drawText(this, x, y, string, colour=None, ptsize=12):
        x = x * PostScript.SCALE + PostScript.OFFSET
        y = y * PostScript.SCALE + PostScript.OFFSET
        PostScript.outputPSColour(colour)
        if string=='\\eps':
            print ("/Symbol findfont 14 scalefont setfont")
            string = 'e'
        else:
            print ("/Helvetica findfont 12 scalefont setfont")
        print ("newpath %f %f moveto" % (x,y))
        y_adjust = -4        
        print ("(%s) dup stringwidth pop 2 div neg %d rmoveto show" % (string, y_adjust))
        print ("0 setgray")

    @staticmethod
    def outputPSColour(colour):
        'Convert a colour name (or "#xxxxxx" hex spec) to PostScript setrgbcolor command.'
        s = None
        if colour == "red":      s = "1.0 0.2 0.2"
        elif colour == "blue":   s = "0.2 0.2 1.0"
        elif colour == "green":  s = "0.2 1.0 0.2"
        elif colour == "white":  s = "1.0 1.0 1.0"
        elif colour == "black":  s = "0.0 0.0 0.0"
        elif isinstance(colour,str) and len(colour) == 7 and colour[0] == "#":
            r = int(colour[1:3],16) / 255.0
            g = int(colour[3:5],16) / 255.0
            b = int(colour[5:],16)  / 255.0
            s = "%4.2f %4.2f %4.2f" % (r,g,b)
        if s != None: print ("%s setrgbcolor" % s)
            
