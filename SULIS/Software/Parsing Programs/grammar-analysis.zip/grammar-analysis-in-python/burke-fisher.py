lalr1prop=__import__('lalr1-propagate')    ## Need to import like this because of hyphen in name.
from grammars import Gappel79
from defs import findallsyms, isterminal

##----------------------------------------------------------------------------
##
##
## BurkeFisherParser - A class implementing a parser with
## simplified (single-token) Burke-Fisher global error repair
## as described by Appel.
##
##           Constructor parameters:
##
##              lrMachine - the LR automaton.
##
##              inputStr  - a string of space-separated tokens to
##                          be parsed.
##
##              K         - "Lookback" - size of queue used by BF.
##              N         - The number of tokens beyond the error
##                          position that a repair has to
##                          successfully parse to in order to be
##                          accepted.
##
## Use:
##
##    >>>  lrmachine = LALR1Machine(Gappel79,False,True)  
##    >>>  bfp = BurkeFisherParser(lrmachine,K=3,N=4)
##    >>>  bfp.doParse("id + + id")
##
## 
##
## Implementation:
##
## The main idea is to keep two parse-stacks running at the same time.  The  
## main stack is the usual S-R parsing stack, the second (here called the
## "shadow stack") is another S-R stack, but running N shift actions behind
## the main stack.  When a syntax error is discovered by the main parsing
## stack (via a blank entry in the Action table), the parser trys all possible
## single-token deletions, insertions and substitutions in the "input window"
## of (up to) K tokens that separates the state of the main stack and the
## shadow stack.  If one of these allows a "trial run" of the parse to continue
## N tokens beyond the point of the discoverde error, this deletion/insertion/
## substitution is reported as the "real" syntax error and the parse is restarted
## using this modified input and the shadow stack (which is copied over the
## main stack).  In this implementation, all possible deletions are tried first,
## then insertions, and finally substitutions.  The first successful repair is
## immediately accepted.  These are essentially arbitrary decisions, and can be
## changed without fundamentally affecting the performance of the error-repair
## mechanism.  The design here is probably the simplest.
## 
## The ideas behind BF error-repiar are really quite simple, the algorithm is
## quite complicated to implement, however, as the details are tricky.  Note
## how the length of the "lookback" actually varies from 0 (at startup) to
## K (the "steady state" length), and shifts onto the shadow stack only happen
## when the steady state is reached.  Also, the shadow stack has to be kept in
## a state where it is always ready to accept a shift, so when a shift onto it 
## is performed, all potential reduce actions that follow from this must be
## performed.
##
## The parser maintains two stacks:
##
##  mainStack   -- the SR stack associated with the "main" operation of the parser.
##  shadowStack -- an SR stack up to K input tokens "behind" the main stack.
##
## It also maintains two "lookahead pointers" that point at the next lookahead
## position:
## 
##  mainIndex   -- A pointer to the lookahead associated with the main parse.
##  shadowIndex -- A pointer to the lookahead associated with the "shadow"
##                 parse.
## 
## 
## 
## 
class BurkeFisherParser(object):
    def __init__(this,lrMachine,K=5,N=4):
        this.machine = lrMachine
        this.K = K
        this.N = N

    ##------------------------------------------------------------------------
    ##
    ## Main parsing routine.
    ##
    def doParse(this,inputStr):
        this.setupNewParse(inputStr)
        print "Burke-Fisher parser with lookback (K) = %d and scanahead (N) = %d\n" %\
              (this.K,this.N)
        while True:
            ## print 80*'-'
            ## print "Main stack   = ", this.mainStack
            ## print "Shadow stack = ", this.shadowStack
            ## this.showInputState()
            ## print "--"
            action = this.getAction('main') 
            if action == 'S':                        
                if this.mainIndex - this.shadowIndex >= this.K:
                    this.runShadowOps()
                this.doShift("main")
                ## print "Action: Shift"
            elif action == 'A':
                ## print "Action: Accept"
                print "Success: Input accepted"
                break
            elif isinstance(action,int):
                this.doReduction(action,this.mainStack)
                ## print "Action: Reduce using production %d (%s)" % \
                ##       (action,this.machine.grammar[action])
            else:
                if this.syntaxErrorHandler():
                    print "\nSyntax error repaired.\n"
                    continue
                else:
                    print "Error hander has not resolved error: Exit"
                    break              
            
            goto = this.getGoTo(this.mainStack)
            if goto:
                this.mainStack.append(goto)
                ## print "GoTo:   New state", goto
            else:
                print "Error: main stack, GoTo lookup is empty"
                break

    ##------------------------------------------------------------------------
    ##
    ## Handle a shift action.  Argument refers to the stack to shift
    ## onto, "main" for mainStack, "shadow" for the shadowStack.
    ## Note how the lookahead pointers are adjusted.
    ## 
    def doShift(this,mainOrShadow):
        if mainOrShadow == 'main':
            sym = this.inputSyms[this.mainIndex]
            this.mainStack.append(sym)
            if sym != '$': this.mainIndex += 1
        else:
            sym = this.inputSyms[this.shadowIndex]
            this.shadowStack.append(sym)
            if sym != '$': this.shadowIndex += 1

    ##------------------------------------------------------------------------
    ##
    ## Handle a reduction action.  Arguments are the index of
    ## the grammar production to employ for the reduction and
    ## the stack the reduction is to be applied to.
    ## 
    def doReduction(this,prodIndex,stack):
        prod = this.machine.grammar[prodIndex]
        for i in range(2*len(prod.rhs)): stack.pop()
        stack.append(prod.lhs)

    ##------------------------------------------------------------------------
    ##
    ## Look up the action required by either the main or
    ## shadow machines.  Argument as for "doShift".
    ## 
    def getAction(this,mainOrShadow):
        if mainOrShadow == 'main':
            stack = this.mainStack
            index = this.mainIndex
        else:
            stack = this.shadowStack
            index = this.shadowIndex
        return this.machine.lookupAction(stack, this.inputSyms[index])

    ##------------------------------------------------------------------------
    ##
    ## Given a stack as argument, use the top two entries on 
    ## it to decide the next state the machine (i.e. stack)
    ## should go to.
    ##
    def getGoTo(this,stack):
        tos = stack[-1]
        tos_1 = stack[-2]
        return this.machine.gotoTable.get((tos,tos_1),False)

    ##------------------------------------------------------------------------
    ##
    ## Given a new string to parse, set up the various data
    ## structures needed by the parse.
    ##
    ## mainStack and shadowStack instance variables are
    ## both initialised to stacks containing the start
    ## state (i.e., stacks as lists, so [0])
    ##
    ## The input string is split into a list of tokens,
    ## (this.inputSyms), and an "end-of-input" token
    ## ('$') is appended if not already there.
    ##
    ## mainIndex and shadowIndex are the pointers to the
    ## lookahead, they are both initialised to 0.
    ##
    def setupNewParse(this,inputStr):
        this.inputSyms = inputStr.split()
        if len(this.inputSyms) == 0 or this.inputSyms[-1] != '$':
            this.inputSyms.append('$')
        this.mainStack = [0]
        this.shadowStack = [0]
        this.mainIndex = 0
        this.shadowIndex = 0

    ##------------------------------------------------------------------------
    ##
    ## Perform a shift onto the shadow stack, and then perform
    ## all reductions that follow from it.  The idea is to get
    ## the shadow stack into a state where it will accept 
    ## another shift.
    ##
    def runShadowOps(this):
        ## print "runShadowOps: shifting onto shadow stack"
        this.doShift('shadow')
        this.shadowStack.append(this.getGoTo(this.shadowStack))
        action = this.getAction('shadow')
        while isinstance(action,int):
            this.doReduction(action,this.shadowStack)
            this.shadowStack.append(this.getGoTo(this.shadowStack))
            action = this.getAction('shadow')
        assert(action == 'S')  ## When done, the machine should be ready for a shift.


    ##========================================================================
    ##
    ## The Burke-Fisher error handler.  This is implemented as a main routine
    ## "syntaxErrorHandler", and routines that try deletions, insertions and
    ## substitutions.  Support routines (trialRun and showInputState) are also
    ## implemented, and are described below.
    ##
    ##------------------------------------------------------------------------
    ##
    ## syntaxErrorHandler:  Trys deletions first, then insertions, finally
    ##                      substitutions.  Insertions and substitutions use
    ##                      all available terminal symbols, apart from '$',
    ##                      this set is calculated by 'findallsyms' from
    ##                      'defs.py'.
    ##
    def syntaxErrorHandler(this):
        print "Syntax Error Detected at main lookahead index %d" % this.mainIndex
        print "  Main stack   = ", this.mainStack
        print "  Shadow stack = ", this.shadowStack
        this.showInputState("  Input state: ")
        print "\nTrying possible deletions"
        if this.tryDeletions(): return True
        print "No available deletion.  Trying possible insertions"
        terminals = findallsyms(this.machine.grammar,lambda s: isterminal(s) and s != '$')
        if this.tryInsertions(terminals): return True
        print "No available insertion.  Trying possible substitutions"
        if this.trySubstitutions(terminals): return True
        print "No available substitution."
        return False

    ##------------------------------------------------------------------------
    ##
    ## tryDeletions: Try all single-token deletions in the range from the 
    ## current shadow lookahead pointer to N symbols beyond the current main
    ## lookahead pointer.  Complications are caused by the possiblity that
    ## there may not be N symbols available from the current main lookahead
    ## to the end of input, and that the '$' token may not be deleted.
    ##    
    ## A successful deletion is found if "trialRun" returns true, in this    
    ## case a new input sequence is set up and the main stack is copied
    ## from the shadow stack.  The main lookahead pointer is set to the
    ## shadow one, and the routine returns.
    ## 
    def tryDeletions(this):
        workingInput = this.inputSyms[this.shadowIndex:this.mainIndex+1]
        restOfInput = this.inputSyms[this.mainIndex+1:]
        extraInput = restOfInput[0:this.N+1]
        for i in range(len(workingInput)):
            newWorkingInput = workingInput[:]
            deletedSymbol = newWorkingInput.pop(i)
            if deletedSymbol == '$': return False ## Never allow deletion of the end of input symbol
            ## print "       Trying deletion of %s (index %d), new input range is %s" %\
            ##       (deletedSymbol,i,newWorkingInput + extraInput)
            if this.trialRun(this.shadowStack[:],newWorkingInput + extraInput):
                print "  SUCCESS: (deleted symbol '%s' at input index %d)" % (deletedSymbol,this.shadowIndex+i)
                newWorkingInput = workingInput[:]
                newWorkingInput.pop(i)
                this.mainStack = this.shadowStack[:]
                this.mainIndex = this.shadowIndex
                this.inputSyms = this.inputSyms[0:this.shadowIndex] + newWorkingInput + restOfInput
                print "    Main stack now   =", this.mainStack
                print "    Shadow stack now =", this.shadowStack
                this.showInputState("    Input modified to: ")
                return True
        return False

    ##------------------------------------------------------------------------
    ##
    ## tryInsertions: Try all single-token insertions in the range from the 
    ## current shadow lookahead pointer to N symbols beyond the current main
    ## lookahead pointer.  Complications are caused by the possiblity that
    ## there may not be N symbols available from the current main lookahead
    ## to the end of input.
    ##    
    ## A successful insertion is found if "trialRun" returns true, in this    
    ## case a new input sequence is set up and the main stack is copied
    ## from the shadow stack.  The main lookahead pointer is set to the
    ## shadow one, and the routine returns.
    ##
    def tryInsertions(this, insertionSymbols):
        workingInput = this.inputSyms[this.shadowIndex:this.mainIndex+1]
        restOfInput = this.inputSyms[this.mainIndex+1:]
        extraInput = restOfInput[0:this.N+1]
        for i in range(len(workingInput)):
            for sym in insertionSymbols:
                newWorkingInput = workingInput[:]
                newWorkingInput.insert(i,sym)
                ## print "       Trying insertion of '%s' (index %d), new input range is %s" %\
                ##       (sym,i,newWorkingInput + extraInput)
                if this.trialRun(this.shadowStack[:],newWorkingInput + extraInput):
                    print "  SUCCESS: (inserted symbol '%s' at input index %d)" % (sym,this.shadowIndex+i)
                    newWorkingInput = workingInput[:]
                    newWorkingInput.insert(i,sym)
                    this.mainStack = this.shadowStack[:]
                    this.mainIndex = this.shadowIndex
                    this.inputSyms = this.inputSyms[0:this.shadowIndex] + newWorkingInput + restOfInput
                    print "    Main stack now   =", this.mainStack
                    print "    Shadow stack now =", this.shadowStack
                    this.showInputState("    Input modified to: ")
                    return True
        return False

    ##------------------------------------------------------------------------
    ##
    ## trySubstitutions: Try all single-token substitutions in the range from
    ## the current shadow lookahead pointer to N symbols beyond the current
    ## main lookahead pointer.  Complications are caused by the possiblity
    ## that there may not be N symbols available from the current main 
    ## lookahead to the end of input, and that '$' must not be substituted
    ## over.
    ##    
    ## A successful substitution is found if "trialRun" returns true, in this    
    ## case a new input sequence is set up and the main stack is copied
    ## from the shadow stack.  The main lookahead pointer is set to the
    ## shadow one, and the routine returns.
    ##
    def trySubstitutions(this, substSymbols):
        workingInput = this.inputSyms[this.shadowIndex:this.mainIndex+1]
        restOfInput = this.inputSyms[this.mainIndex+1:]
        extraInput = restOfInput[0:this.N+1]
        for i in range(len(workingInput)):
            oldsym = workingInput[i]
            newWorkingInput = workingInput[:]
            if oldsym == '$': break  ## If at end of input, can't substitute over '$' 
            for sym in substSymbols:
                if sym == oldsym: continue  ## If current symbol is the same as the propsed substitution, skip this iteration.                
                newWorkingInput[i] = sym
                ## print "       Trying substitution of '%s' by '%s' (index %d), new input range is %s" %\
                ##       (oldsym,sym,i,newWorkingInput + extraInput)
                if this.trialRun(this.shadowStack[:],newWorkingInput + extraInput):
                    print "  SUCCESS: (substituted symbol '%s' for '%s' at input index %d)" %\
                          (sym,oldsym,this.shadowIndex+i)
                    newWorkingInput = workingInput[:]
                    newWorkingInput[i] = sym
                    this.mainStack = this.shadowStack[:]
                    this.mainIndex = this.shadowIndex
                    this.inputSyms = this.inputSyms[0:this.shadowIndex] + newWorkingInput + restOfInput
                    print "    Main stack now   =", this.mainStack
                    print "    Shadow stack now =", this.shadowStack
                    this.showInputState("    Input modified to: ")
                    return True
        return False

    ##------------------------------------------------------------------------
    ##
    ## trialRun: Do a "trial-run" over a newly-prepared input sequence, 
    ## performing a full set of shift-reduce actions.  If the machine runs
    ## until the input is empty, the trial suceeds and this routine returns
    ## True.  If, however, the machine encounters a 'Reject' entry in the
    ## Action table it immediately exits with status: False.
    ##            
    def trialRun(this,stack,inputSyms):
        while len(inputSyms) > 0:
            action = this.machine.lookupAction(stack,inputSyms)
            if action == 'Reject':
                ## print "            Failed"
                return False
            else:
                if action == 'S': stack.append(inputSyms.pop(0))
                elif isinstance(action,int): this.doReduction(action,stack)
                else: return True
                stack.append(this.getGoTo(stack))
        return True
                
    ##------------------------------------------------------------------------
    ##
    ## showInputState: Pretty-print the current state of the input, showing
    ## input tokens, their indices, and the current position of the main and
    ## shadow lookahead pointers.  A "preamble" may be supplied, this is a
    ## string that gets printed to the left of the toekn display.
    ## 
    ## Here is an example where the preamble is "Input State" ", the
    ## main lookahead pointer has value 2 and the shadow lookahead has value
    ## 0.
    ##
    ##                   0   1   2   3   4   5   
    ##      Input state: id  +   +   id  ;   $   
    ##                   ^       ^
    ##                   S       M
    ##
    ## Note how the indices of the tokens are indicated immediately above
    ## each one (this is useful, as the erro reporting in in terms of token
    ## indices).  Also note the main lookahead point ('M') and shadow
    ## pointer ('S').
    ## 
    def showInputState(this,preamble=None):
        if preamble: inputStr = preamble
        else: inputStr = ""
        padding = len(inputStr)*' '
        fieldWidth = max([len(s)+2 for s in this.inputSyms])
        if fieldWidth < 3: fieldWidth = 3
        indicesStr = padding
        for index,sym in enumerate(this.inputSyms):
            indicesStr += str(index).ljust(fieldWidth)
            inputStr += sym.ljust(fieldWidth)
        print(indicesStr)
        print(inputStr)
        s1 = padding ; s2 = padding
        for i in range(this.mainIndex):
            if i == this.shadowIndex:
                s1 += '^'.ljust(fieldWidth)
                s2 += 'S'.ljust(fieldWidth)
            else:
                s1 += fieldWidth*' '; s2 += fieldWidth*' '
        s1 += '^' ; s2 += 'M'
        print s1
        print s2
        
    ##------------------------------------------------------------------------
    ##
    ## End of code for BurkeFisherParser.
    ##
    ##------------------------------------------------------------------------

####################################################################################
##
## A simple debug setup.
##
print "Creating LALR1Machine lr79 from grammar Gappel79"
lr79=lalr1prop.LALR1Machine(Gappel79,False,True)
print "Creating a Burke-Fisher parser object in bfp, with lookback (K) = 2, N = 2"
bfp=BurkeFisherParser(lr79,K=2,N=2)
