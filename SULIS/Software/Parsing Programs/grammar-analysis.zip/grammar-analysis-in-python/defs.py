##==============================================================================
##
## defs.py
##
## Useful definitions and routines for grammar analysis programs.
##
##
##  Production is a class representing a BNF production.  It has a left-hand-
##      side (lhs) which is a nonterminal symbol and a right-hand-side (rhs) 
##      which is an array of symbols.  A null production is represented by 
##      an rhs array of length 0.
##
##  A grammar is simply a list (array) of Production objects.
##
##
##  Routines associated with Production objects:
##
##    isterminal(sym)  - checks to see if a symbol is a terminal.
##
##    isnonterminal(sym) - checks to see if a symbol is a nonterminal.
##
##
##  Routines associated with grammars (lists of Productions)
##
##    findallsyms(grammar,decision_predicate)  - finds and returns a set
##        of all the symbols in a grammar which meet a certain criterion 
##        (defined by the second argument, the "decision_predicate", a 
##        one-argument function that returns True when the criterion
##        is met).  Useful for finding, for example, all the nonterminals 
##        in a grammar, or all the terminals.  The grammar is a list of
##        Production objects.
##
##    augmentGrammar(grammar) - augment a grammar with a new initial
##        Production, "<Aug> --> S $", where 'S' is the start symbol
##        of the original grammar.  The idea is to guarantee that
##        the end-of-input marker '$' is included in the grammar, hence
##        the predictors for the grammar can't include 'eps', the null
##        string.  It is useful for first and follow calculations, but
##        vital for the LR shift-reduce parser-construction routines.
##
##
##==============================================================================
##
## The basic Production object.  A (BNF) Production is represented as a
## string for the left-hand-side of the production, and a list of strings
## for its right-hand-side.  The null production is represented by having an
## empty list for the right-hand-side.
##
## This class includes a simple initialisation routine and a __repr__ routine
## which generates a "pretty-printed" representation of the production in
## the form "A --> B C D a b c".
##
## A grammar is represented as a list of such Productions.  There are example
## grammars at the end of the file.
##
##

class Production(object):
    "The lhs is a nonterminal.  The rhs is a list of symbols (empty for a null production)."
    def __init__(self,lhs,rhs):
        if not isnonterminal(lhs):
            raise Exception, 'The lhs "%s" of a production must be a non-terminal' % lhs
        if not isinstance(rhs,list):
            raise Exception, 'The rhs "%s" of a production must be a list of symbols' % rhs
        self.lhs = lhs
        self.rhs = rhs

    def __repr__(self):
        s = '%s -->' % self.lhs
        if len(self.rhs) == 0:
            s += ' eps'
        else:
            for sym in self.rhs: s += ' %s' % sym
        return s

    def equals(self,prod):
        "Check to see if two productions are the same."
        if self.lhs != prod.lhs or len(self.rhs) != len(prod.rhs): return False
        else:
            status = True
            for i in range(len(self.rhs)):
                if self.rhs[i] != prod.rhs[i]:
                    status = False
                    break
            return status

    def formatHTML(self,targetPS=True,size=10):
        "Format a production as part of an HTML table suitable for dot."
        ## Generate code for arrow and epsilon depending on targetPS.
        ARROW = '<td align="center"><font point-size="%d" face=' % size
        EPS   = '<td align="left"><font point-size="%d" face=' % size
        if targetPS:
            ARROW += '"Symbol">&#174;</font></td>'
            EPS   += '"Symbol">e</font></td>'
        else:
            ARROW += '"Times-Roman">&#8594;</font></td>'
            EPS   += '"Times-Roman">&#949;</font></td>'
        ## Format LHS of production.
        if self.lhs[0] == '<': lhssym = ('&lt;%s&gt;' % self.lhs[1:-1])
        else: lhssym = self.lhs[0]
        s = '<td align="right"><font face="Times-Italic" '
        s += 'point-size="%d">%s</font></td>' % (size,lhssym)
        s += ARROW
        rhs = self.rhs
        if len(rhs) == 0: s += EPS
        else:
            s += '<td align="left">'
            s += '<font face="Times-Italic" point-size="%d">' % size
            for sym in rhs:
                if sym[0] =='<': s += ('&lt;%s&gt;' % sym[1:-1])
                else: s += sym
            s += '</font></td>'
        return s
        
##==============================================================================
##
##  Support routines useful in dealing with grammars (lists of Production
##  objects.
##
##------------------------------------------------------------------------------
##
## isnonterminal - returns True if its argument is a nonterminal symbol.
##
## In this program, a nonterminal is a string which is either a single
## uppercase letter, or a string which starts with a '<' and ends with
## a '>'.
##

def isnonterminal(sym):
    "Returns True if the argument is a string representing a non-terminal symbol."
    return isinstance(sym,str) and \
           (len(sym) == 1 and sym[0].isupper() or \
            len(sym) >= 2 and sym[0] == '<' and sym[-1] == '>')


##------------------------------------------------------------------------------
##
## isterminal - returns True if its argument is a terminal symbol.
##
## In this program, terminal is something which is not the string 'eps'
## and is not a nonterminal.
##

def isterminal(sym):
    "Return True if the argument is anything other than a nonterminal symbol or 'eps'."
    return sym != 'eps' and not isnonterminal(sym)


##------------------------------------------------------------------------------
##
## findallsyms - find and return a set of all the symbols in a grammar which
## meet a certain criterion (defined by the second argument, the "decision_
## predicate", a one-argument function that returns True when the criterion
## is met).
##
## Useful for finding, for example, all the nonterminals in a grammar, or
## all the terminals.
##

def findallsyms(grammar,decision_predicate):
    "Return the set of symbols in a grammar for which the 'decision_predicate' returns True."
    theset = set()
    for prod in grammar:
        if decision_predicate(prod.lhs): theset.add(prod.lhs)
        for sym in prod.rhs:
            if decision_predicate(sym): theset.add(sym)
    return theset


##------------------------------------------------------------------------------
##
## augmentGrammar(grammar) - augment a grammar with a new initial
## Production, "<Aug> --> S $", where 'S' is the start symbol
## of the original grammar.  The idea is to guarantee that
## the end-of-input marker '$' is included in the grammar, hence
## the predictors for the grammar can't include 'eps', the null
## string.  It is useful for first and follow calculations, but
## vital for the LR shift-reduce parser-construction routines.
##
## N.B. No action is taken if the grammar is already augmented, that
## is, if the lhs of the first production of the grammar is already
## '<Aug>'.
##

def augmentGrammar(grammar):
    if len(grammar) > 0 and isinstance(grammar[0],Production) \
       and grammar[0].lhs != '<Aug>':
        augmentedG = grammar[:]
        startSym = augmentedG[0].lhs
        augmentedG.insert(0,Production('<Aug>', [startSym, '$']))
        return augmentedG
    else:
        return grammar

##==============================================================================
##
##  Support routines useful in formating symbols and sets of symbols
##  as HTML-compatable strings.
##
##------------------------------------------------------------------------------##------------------------------------------------------------------------------
##
## formatSetAsHtml -- Return a string containing the elements of a set of
##                    symbols in HTML format.
##
def formatSetAsHtml(theSet,outputForPS=True):
    if len(theSet) == 0: s = '{}'
    else:
        s = '{'
        first = True
        for sym in theSet:
            if first: first = False
            else:
                s += ','
            s += formatSymAsHtml(sym,outputForPS)
        s += '}'
    return s

##------------------------------------------------------------------------------
##
## formatSymAsHtml -- Return a string containing a Symbol formatted in HTML.
##
def formatSymAsHtml(theSym,outputForPS=True):
    if theSym == 'eps':
        if outputForPS:
            s = '<font face="Symbol">e</font>'
        else:
            s = '<font face="Times-Roman">&#949;</font>'
    else:
        if len(theSym) >= 2 and theSym[0] == '<':
            s = '&lt;%s&gt;' % theSym[1:-1]
        else:
            s = theSym
    return s

##------------------------------------------------------------------------------
