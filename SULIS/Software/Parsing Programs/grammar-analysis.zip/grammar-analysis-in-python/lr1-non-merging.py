##==============================================================================
##
## lr1-non-merging.py
##
## A Python program that builds the LR1 Finite State Machine and the 
## corresponding Action and GoTo tables for an LR(1) grammar.
##
## Use:
##
##     >>> from grammars import *    ## <-- Get some grammar definitions.
##     >>> lr1g11=LR1Machine(G11)    ## <-- Create an LR(1) automation for G11.
##     >>> lr1g11.displayFSM()       ## <-- Show the LR(1) FSM.
##     >>> lr1g11.displayAction()    ## <-- Show the LR(1) Action table for G11.
##     >>> lr1g11.displayGoTo()      ## <-- Show the GoTo table for G11.
##     >>> lr1g11.parse('( id  )')   ## <-- Parse an input string, displaying
##                                   ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, '(id)' would be scanned as the single
## token '(id)', not the three tokens '(', 'id', ')'.
##
##------------------------------------------------------------------------------
##
## Note that this LR(0) implementation uses a "non-merging" approach to 
## the generation of item sets for new LR(1) states.  This is a perfectly
## good approach, but is not the usual one employed to construct an LR(1)
## parser.  The more standard appraoch uses "item merging". See lr1.py for 
## an implementation of the usual approach, and, in particular, the discussion 
## of method "close" in class "LR1State" in that implementation.  N.B. The 
## "non-merging" approach used here doesn't extend to LALR construction by 
## cognate state identification, a reason why the alternative is the
## standard.
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LR1Machine -- This represents the LR(1) recogniser for a given
##                    grammar.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  This flag argument
##              defaults to True.
##
##          buildFSM.  Builds the LR(1) Finite State Machine for the grammar.
##              Called automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayFSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          checkLR1.  Checks to see if the FSM built by 'buildFSM' is
##              in fact, LR(1), (i.e., that it does not contain any
##              inadequate states).  Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(1) automaton
##              from its FSM.  Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this FSM in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          genGoTo.  Generates the GoTo table for an LR(1) automaton
##              from its FSM.  Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayGoTo.  Displays the GoTo table associated with
##              this FSM in "pretty-printed" tabular style.
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this LR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from LRBase (abstract base class).
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from LRBase (abstract base class).
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from LRBase (abstract base class).
##
##
##      Utility Methods needed by base class methods and implemented here
##      -----------------------------------------------------------------
##
##          rejectMessage.  Returns a string representing a 'Reject'
##              action coming from the Action table.
##
##          getFSMStateCount.  Returns a count of the number of states in
##              this parsing automaton's LR(1) FSM.
##
##          getFSM.  Returns the LR(1) FSM of this parsing automaton.
##
##
##------------------------------------------------------------------------------
##
##      LR1State --  Represents a set of LR(1) Items making up a state of the
##                   LR(1) Finite State Machine.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(1) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation of the Items in this state.
##
##          equals.  Check to see if this LR(1) state and the argument, 
##              another such state, are equal.  Two LR(1) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR1State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR0States.
##
##          isAdequate.  Return True if this LR1State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state.
##
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
## LR(1) Items (dotted productions) are represented as LR1Item objects.
##
##------------------------------------------------------------------------------
##
##

from defs import isterminal, findallsyms, augmentGrammar
from ff import fill_first_sets
from lrbase import LRBase
from lr1item import LR1Item

##==============================================================================
##
## class LR1Machine -- This represents the LR(1) recogniser for a given
##      grammar.
##
##      N.B. the grammar is quietly augmented before the LR(1) FSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Default to True.
##
##          buildFSM.  Builds the LR(1) FSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayFSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          checkLR1.  Checks to see if the FSM built by 'buildFSM' is
##              in fact, LR(1), that is does not contain any inadequate
##              states. Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(1) automaton
##               from its FSM. Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this LR(1) automaton in "pretty-printed" tabular style.
##
##          genGoTo.  Generates the GoTo table for an LR(1) automaton
##               from its FSM. Called automatically by constructor.
##
##          displayGoTo.  Displays the GoTo table associated with
##              this LR(1) automaton in "pretty-printed" tabular style.
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this LR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##
##
##

class LR1Machine(LRBase):
    "The LR(1) recogniser for a grammar."
    def __init__(this,grammar,verbose=True):
        this.grammar = augmentGrammar(grammar)  ## Note augmentation.
        this.fsm = this.buildFSM(verbose)       ## Build the LR(1) FSM.
        if verbose: print 35*"=="
        if this.checkLR1(verbose):
            this.actionTable = this.genActions()
            this.gotoTable = this.genGoTo()
        else:
            this.actionTable = None
            this.gotoTable = None

    ##----------------------------------------------------------------------
    ##
    ## Build the LR(1) FSM for the grammar. Verbose is a flag controlling 
    ## whether or not to do lots of output to the terminal describing the 
    ## progress of the build. Returns a list of LR1state objects.
    ##
    def buildFSM(this,verbose):
        "Build the LR(1) FSM for the supplied grammar."
        first_sets = fill_first_sets(this.grammar)
        states = [LR1State(this.grammar)]
        states[0].close(first_sets)
        stateQueue = [0]
        while stateQueue != []:
            stateNum = stateQueue.pop(0)
            state = states[stateNum]
            if verbose:
                print "-------------------------------------------------------"
                print "Working with state %d (%s)" % (stateNum, state)
            for sym,itemSet in state.findTransitions().items():
                candidateNewState = LR1State(this.grammar,itemSet)
                if verbose:
                    s = "   Working with transition on '%s' to { " % sym
                    for targetItem in itemSet:
                        s += "%s" % targetItem
                    s += '}'
                    print "%s\n      Candidate new state is %s" % \
                          (s,candidateNewState)
                isNewState = True
                for i,s in enumerate(states):
                    if candidateNewState.equals(s):
                        isNewState = False
                        state.transitions[sym] = i
                        if verbose:
                            print "            Not new, is existing state %d." % i
                        break
                if isNewState:
                    newStateNumber = len(states)
                    state.transitions[sym] = newStateNumber
                    candidateNewState.close(first_sets)
                    states.append(candidateNewState)
                    stateQueue.append(newStateNumber)
                    if verbose:
                        print "            New, adding as state %d." \
                              % newStateNumber
        return states

    ##----------------------------------------------------------------------
    ##
    ## displayFSM -- output the LR(1) FSM of this automaton in
    ## "pretty-printed" style.
    ##
    def displayFSM(this):
        "Pretty-print the LR(1) Finite State Machine of this automaton."
        for i,lr1state in enumerate(this.fsm):
            print "=====================================\nState %d" % i
            for item in lr1state.kernel: print "    (k) %s" % item
            if len(lr1state.closure) > 0:
                for item in lr1state.closure: print "    (c) %s" % item
            if len(lr1state.transitions) > 0:
                print "  Transitions:"
                for (sym,target) in lr1state.transitions.iteritems():
                    print "    '%s' ==> %d" % (sym,target)
            else:
                print "  No transitions out of this state"

    ##----------------------------------------------------------------------
    ##
    ## checkLR1 -- Check to see if the LR(1) FSM is correct, i.e., that
    ##      it contains no inadequate states (i.e., no shift-reduce or
    ##      reduce-reduce conflicts).  Returns True if no inadequate LR(1)
    ##      states are found, False otherwise.  If the automaton contains
    ##      inadequate states, reports on them to the output as well.
    ##
    def checkLR1(this,verbose=False):
        "Check to see if this FSM contains no inadequate states."
        if verbose:
            print "Checking if grammar is LR(1)"
            print "============================"
        status = []
        for stateNum,lr1state in enumerate(this.fsm):
            status.append(lr1state.isAdequate(stateNum,verbose))
        for s in status:
            if not s:
                if verbose: print "It is not LR(1)"
                return False
        if verbose: print "It is LR(1)"
        return True

    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an LR(1) automaton
    ##               from its FSM.
    ##
    ## Note: Assumes that the grammar has been checked by "checkLR1".  This
    ## happens automatically in the constructor.  What is generated is a
    ## dictionary indexed by (sym,stateNumber) tuples indicating the action
    ## to take with "stateNumber" on the top of the parse stack and lookahead
    ## "sym".  An entry in the dictionary is either 'S' (a shift action),
    ## 'A' (an accept action), or a positive number corresponding to a
    ## production number in the augmented grammar associated with the
    ## machine.  Blank entries in the table are not represented explictly.
    ## 
    ##
    def genActions(this):
        actionTable = dict()
        for stateNum,lr1state in enumerate(this.fsm):
            for item in lr1state.kernel + lr1state.closure:
                lookaheadSym = item.getDottedSym()
                if lookaheadSym == 'eps':  ## Dot at right-end => reduction.
                    ## Find index of production to reduce by.
                    for prodNum,prod in enumerate(this.grammar):
                        if prod == item.production: break
                    ## Now iterate over the symbols in the lookahead context.
                    for lookaheadSym in item.lookahead:
                        if lookaheadSym != 'eps':
                            actionTable[(lookaheadSym,stateNum)] = prodNum
                        else:
                            if prodNum == 0: ## Augmenting production
                                actionTable[('$',stateNum)] = 'A'
                            else:
                                print "Error in Action Table construction"
                                print "Lookahead of eps encountered on item %s" %\
                                      item
                                return None
                elif isterminal(lookaheadSym):
                    actionTable[(lookaheadSym,stateNum)] = 'S'
        return actionTable

    ##----------------------------------------------------------------------
    ##
    ## The following methods of this class are utilites needed by routines
    ## from LRBase, and are not designed to be called directly.
    ##
    ##----------------------------------------------------------------------
    ##
    ## rejectMessage --  Returns a reject message suitable to a Reject
    ##                   action comming back from the Action table. This 
    ##                   should never happen in a proper LR(0) parse, so
    ## is an error (an LR(0) parse will pick up on illegal input when it
    ## looks at the GoTo table).  For an SLR parse, on the other hand,
    ## rejects in the Action table represent perfectly normal behaviour
    ## on illegal input, so we have this trivial method to allow for
    ## differentiated reporting. Ditto for an LALR(1) machine.
    ##
    def rejectMessage(this):
        return "Reject"

    ##----------------------------------------------------------------------
    ##
    ## getFSMStateCount --  Returns a count of the number of states in this
    ##                      machine.
    ##
    def getFSMStateCount(this):
        if this.fsm:
            return len(this.fsm)
        else:
            return 0

    ##----------------------------------------------------------------------
    ##
    ## getFSM --  Returns the FSM of the current machine (a list of LR(1)
    ##            states).
    ##
    def getFSM(this):
        if this.fsm:
            return this.fsm
        else:
            return None

    ##----------------------------------------------------------------------
        
##==============================================================================
##
## class LR1State -- This represents an LR(1) state, which is a list of
##      LR(1) Items.
##      Separate kernel and closure lists are maintained.  This is a non-
##      merging version of LR1State.  Note that LR1State as defined
##      in "lr1state.py" implements a "merging" LR1State object, which
##      is one where items with identical cores but differing 
##      lookahead sets are merged.  In this implementation items with
##      identical cores but differing lookahead sets are *not* merged.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.  If it is None, a new Item generated from the
##              first production, with lookahead context {'eps'} is added.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(1) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation state in terms of its Items.
##
##          equals.  Check to see if this LR(1) state and the argument, 
##              another such state, are equal.  Two LR(1) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR1State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR1States.
##
##          isAdequate.  Return True if this LR1State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state. Note that shift actions
##              only result from items with terminals to the right of
##              their dots.  Items with dots at their right hand ends
##              contribute reduce actions.  Items with nonterminals to
##              the right of their dots don't contribute any action,
##              (i.e., neither shift nor reduce).  An LR(1) state is
##              adequate if it has either (a) exactly one reduce item
##              but no shift items, or (b) one or more shift items but
##              no reduce items, or (c) one or more shift items and
##              one or more reduce items, but the lookahead contexts
##              are distinct.  If it has neither shift nor reduce
##              items, this is an error, and should never happen.
##
            
class LR1State(object):
    "An LR(1) state is a set of LR(1) items (kernel & closure)."
    def __init__(self,grammar,kernelItems=None):
        self.grammar = grammar
        self.kernel = []
        self.closure = []
        if kernelItems == None:
            self.addItem(LR1Item(grammar[0],set(['eps'])))
        else:
            for item in kernelItems: self.addItem(item)
        self.transitions = dict()
        
    def addItem(self,item):
        "Add another LR(0) item to the kernel set of this state."
        self.kernel.append(item)

    def close(self,first_sets):
        "Close this state. first is a dict of the first sets of the grammar syms."
        itemQueue=list()
        for item in self.kernel:
            for newItem in item.close(self.grammar,first_sets):
                if not newItem in self.kernel and not newItem in self.closure:
                    self.closure.append(newItem)
                    itemQueue.append(newItem)
        while len(itemQueue) > 0:
            item = itemQueue.pop(0)
            for newItem in item.close(self.grammar,first_sets):
                if not newItem in self.kernel and not newItem in self.closure:
                    self.closure.append(newItem)
                    itemQueue.append(newItem)
            
    def __repr__(self):
        s = '{ kernel('
        for item in self.kernel: s += ' %s' % item
        s += ' ) closure('
        for item in self.closure: s += ' %s' % item
        s += ') }'
        return s

    ## Compare two LR(1) Items by checking to see if they have identical
    ## kernel sets (since, if these are identical, their closure sets must
    ## also be identical.  Note that sets are being represented as lists
    ## of LR(1) Items, hence the clumsy code needed for the comparison.
    ##
    def equals(self,lr1state):
        "Check for equality with another LR(1) State."
        if len(self.kernel) == len(lr1state.kernel):
            equals = True
            for item in self.kernel:
                if not item in lr1state.kernel:
                    equals = False
                    break
            return equals
        else:
            return False

    def findTransitions(self):
        """Find symbols marking transitions out of this state & the
           associated items which result from these transitions."""
        trans = dict()
        for item in self.kernel + self.closure:
            sym = item.getDottedSym()
            if sym != 'eps':
                newItem = item.advanceDot()
                if trans.has_key(sym): trans[sym].add(newItem)
                else: trans[sym] = set([newItem])
        return trans

    ##----------------------------------------------------------------------
    ##
    ## isAdequate -- Check to see if a fsm state has any shift-reduce or
    ##               recuce-reduce conflicts.  Uses the LR(1) lookahead
    ## context for each item to help resolve this.
    ##
    ## Flag "verbose" (which defaults to True) controls printing of
    ## messages about the check to the output stream.
    ## If it is set to True, detailed progress information is displayed,
    ## including information about conflicts. If False, noting is displayed
    ## and the only feedback from the method is the True/False status of
    ## the check.
    ##
    def isAdequate(self,stateNum,verbose=False):
        shiftItems = []
        reduceItems = []
        adequateState = True
        for item in self.kernel + self.closure:
            sym = item.getDottedSym()
            if sym == 'eps':
                reduceItems.append((item,item.lookahead))
            elif isterminal(sym):
                shiftItems.append((item,sym))
        for (reduceitem,lookaheadset) in reduceItems:
            for (shiftitem,lookaheadsym) in shiftItems:
                if lookaheadsym in lookaheadset:
                    adequateState = False
                    if verbose:
                        print "-------------------------------------------------"
                        print "FSM state %d, shift-reduce conflict:" % stateNum
                        print "  Item %s (shift on %s) conflicts with" % \
                              (shiftitem,lookaheadsym)
                        print "  item %s (reduce on %s)" % \
                              (reduceitem,lookaheadset)
        for i in range(len(reduceItems)):
            reduceSetA = reduceItems[i][1]
            for j in range(1+i,len(reduceItems)):
                reduceSetB = reduceItems[j][1]
                if len(reduceSetA.intersection(reduceSetB)) != 0:
                    adequateState = False
                    if verbose:
                        print "-------------------------------------------------"
                        print "FSM state %d, reduce-reduce conflict:" % stateNum
                        print "  Item %s (reduce on %s) conflicts with" % \
                              (reduceItems[i][0],reduceSetA)
                        print "  item %s (reduce on %s)" % \
                              (reduceItems[j][0],reduceSetB)
        return adequateState
