##==============================================================================
##
## fftable.py
##
## A Python program to build LL(1) table-driven parsers and show their
## operation on sample inputs.
##
## A grammar is represented as a list of "Production" objects (see below).
##
## An LL(1) parse table is implemented as a Python dictionary with entries
## indexed by tuples (nonterminal,terminal).  
##
##
## The routines provided for constructing and using LL(1) table-parsers
## are as follows:
##
##
## buildLL1ParseTable(grammar)
##                      - If the supplied grammar is LL(1), build and
##                        return an LL(1) parse table for it.  If the
##                        grammar is not LL(1), display an appropriate
##                        error message and return None.
##
## displayLL1ParseTable(table,grammar)
##                      - "Pretty-print" the parse table for the grammar.
##
## parse(input_string,table,grammar)
##                      - Parse the input "input_string" according to the
##                        parse table supplied in argument 2 and the grammar
##                        suplied in argument 3.  The parse table should, of
##                        course, have been generated from the grammar
##                        beforehand.  No consistency checks are made between
##                        the table and the grammar.
##
##
##
##==============================================================================



from defs import Production, isterminal, isnonterminal, findallsyms
from ff import gen_predict_sets, checkLL1


 
DELTA = '<>'             ## Marker for the bottom of the parse stack.
POP_RD = -1              ## Marks 'pop/read' action in parse table.
ACCEPT = -2              ## Marks 'accept' action in parse table.
REJECT = -3              ## Marks 'reject' action in parse table.
                         ## 'Replace' actions are indexed by (+ve)
                         ## production numbers (0-based).
ILLEGAL = -4             ## Occurs if input which is not in the alphabet
                         ## of the parser is supplied to routine 'parse'.



##==============================================================================
##
## buildLL1ParseTable
##
## Build and return an LL(1) parse table for the supplied grammar, if the
## grammar is LL(1).  If it isn't, complain to the user and return None.
##
##

def buildLL1ParseTable(grammar):
    "Build an LL(1) parse table for the grammar supplied as an argument."
    predictors = gen_predict_sets(grammar)
    (isLL1,conflictset) = checkLL1(grammar,predictors)
    if isLL1:
        parseTable = dict()
        terminals = findallsyms(grammar,isterminal)
        allsyms   = findallsyms(grammar, lambda x : True)
        terminals.add('$')
        allsyms.add(DELTA)
        for row in terminals:
            for col in allsyms:
                if ( row == col ): action = POP_RD
                elif row == '$' and col == DELTA: action = ACCEPT
                else: action = REJECT
                parseTable[(row,col)] = action
        for pr_index in range(len(grammar)):
            lhs = grammar[pr_index].lhs
            for lookahead in predictors[pr_index]:
                parseTable[(lookahead,lhs)] = pr_index
        return parseTable
    else:
        print "This grammar is not LL(1), conflicts %s" % conflictset
        return None



##==============================================================================
##
## displayLL1ParseTable
##
## Display a parse table built by buildLL1ParseTable
##

def displayLL1ParseTable(table,grammar):
    "Display an LL(1) parse table."
    row_indices = list(findallsyms(grammar,isterminal))
    col_indices = []
    for p in grammar:
        lhs = p.lhs
        if lhs not in col_indices: col_indices.append(lhs)
    col_indices.extend(row_indices)
    col_indices.append(DELTA)
    row_indices.append('$')
    s   = '    |'
    sep = '----+'
    for col_index in col_indices:
        s += ' %3s |' % col_index
        sep += '-----+'
    print s
    print sep
    for row_index in row_indices:
        s = '%3s |' % row_index
        for col_index in col_indices:
            action = table[(row_index,col_index)]
            if action == REJECT:  s += '     |'
            elif action == POP_RD:  s += ' p/r |'
            elif action == ACCEPT:  s += ' acc |'
            else: s += ' %3d |' % action
        print s
        print sep



##==============================================================================
##
## parse
##
## Parse an input string using an LL(1) parse table. Terminal tokens are
## assumed separated by whitespace so a "real" scanner isn't needed.
##
## Note that the grammar is needed as well as the parse table because we push
## the right-hand-sides of a production in a replace action.  The parse table
## just contains the production number, not the actual symbols needed
##
## N.B. Don't supply a parse table and grammar that are inconsistent, this
## routine doesn't do any checking and will proceed to make a mess of things.
##
## Pop/read, Reject and Accept actions are coded by negative integers whereas
## Replace actions are coded (implicitly) by the positive indices of their 
## associated gramamr productions.  This is a typical approach.
##
## It is always possible for an illegal token to be returned (something that
## isn't part of the input alphabet of terminal tokens).  A special 'ILLEGAL'
## action is reserved for these circumstances.
##
## Note how the replace action pops the current top-of-stack symbol and then
## pushes the symbols of the right-hand-side of the associated production
## in reverse order.
##
##

def parse(input_string,table,grammar):
    tokenlist = input_string.split()    # Split input into a list of tokens.
    tokenlist.append('$')               # Augment the list with end of input marker.
    stack = [DELTA,grammar[0].lhs]      # Initialise parse stack, start symbol on top.
    index = 0                           # Reader index.
    while True:
        # ---- Debugging output, shows progress of parse.
        s = 'Stack: %-50s Input: ' % stack
        for j in range(index,len(tokenlist)): s += '%s ' % tokenlist[j]
        print s
        # -----
        token = tokenlist[index]                        # Get current input token
        tos_symbol = stack[-1]                          # and top of parse stack
        action = table.get((token,tos_symbol),ILLEGAL)  # Lookup the action.
        if action == POP_RD:        
            print "    Pop/Rd"
            stack.pop()                                 # Pop/read, pop stack
            index += 1                                  # and read to next token.
        elif action == ACCEPT:
            print "    Accept: String is valid"
            return True
        elif action == REJECT:
            print "    Reject: String is invalid, (%s,%s) => Reject" % \
		  (token,tos_symbol)
            return False
        elif action == ILLEGAL:
            print "    Input %s is not a valid terminal for this grammar" % token
            return False
        else:                         # The Replace action.
            stack.pop()               # Pop parse stack and push the rhs of
            rhs = grammar[action].rhs # production(i).  Note reverse push order.
            for i in range(len(rhs)-1,-1,-1): stack.append(rhs[i])
            print "    Applying production %s, %s" % (action,grammar[action])
