##==============================================================================
##
## class LR1State -- This represents an LR(1) state, which is a list of
##      LR(1) Items.  This list is held in the object variable "items".
##      No clear distinction is maintained between kernel and closure items
##      in this list, as the distinction is not really meaningful for LR(1)
##      in the way that it is for LR(0).
##
##      Note that this is a "merging" LR(1) state implementation.  When
##      a new state is generated, items that share a common core are
##      merged.  This is quite a tricky operation, here all possible
##      items are first generated, then merged.  An earlier attempt
##	to merge "on the fly" lead to problems with very complex
##	closure sets (grammar Gappel79, for example), so this version
##	is "extra catious".
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.  If it is None, a new Item generated from the
##              first production, with lookahead context {'eps'} is added.
##
##          addItem.  Add a new Item to this state.
##
##          close.  Perform the LR(1) closure operation on the Items already
##              in this state.
##
##              N.B. Note that this implementation of "close" *merges*
##              candidate new LR1Items with LR1Items already present in the 
##              state.  A new Item is merged with an existing one if the new 
##              Item shares the same production and dot position as the
##              existing one, *even if their lookahead contexts differ*.
##
##              Why is this a valid thing to do?  Consider if the candidate
##              item were treated as distinct from the existing item because
##              of differing lookahead contexts (this is what occurs in the 
##              LR(1) generator implemented in file "lr1-non-merging.py").
##              The new item will be added to the queue of items to process,
##              so will eventually be closed.  But, in closing, it can
##              only generate items that have already been seen (because it
##              shares a production and dot with an already existing item),
##              hence, it won't add anything new to the item set. So it
##              shortens the item set to just merge lookahead contexts
##              when the match on the "core" of the item is first seen.
##              (This is why the method @hasSameCore@ is used in the
##              item comparison below).
##
##          __repr__.  Print a representation state in terms of its Items.
##
##          equals.  Check to see if this LR(1) state and the argument, 
##              another such state, are equal.  Two LR(1) states are equal
##              if they possess the same Item sets.
##
##          findTransitions.  Find all possible transitions out of this
##              LR1State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR1States.
##
##          isAdequate.  Return True if this LR1State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state. Note that shift actions
##              only result from items with terminals to the right of
##              their dots.  Items with dots at their right hand ends
##              contribute reduce actions.  Items with nonterminals to
##              the right of their dots don't contribute any action,
##              (i.e., neither shift nor reduce).  An LR(1) state is
##              adequate if it has either (a) exactly one reduce item
##              but no shift items, or (b) one or more shift items but
##              no reduce items, or (c) one or more shift items and
##              one or more reduce items, but the lookahead contexts
##              are distinct.  If it has neither shift nor reduce
##              items, this is an error, and should never happen.
##
##          getInadequates.  Return a triple (inadequates,sitems,ritems),
##              where 'inadequates' is a set of the inadequate items in
##              this LR1State, 'sitems' is a list of the shift items in 
##              the state, and 'ritems' is a list of the reduce items in
##              the state.  Used by methods 'isAdequate' and
##  
##          isCognate.  Return True if this LR1State is cognate with
##              its argument (another LR1State).  Two LR1States are
##              cognate if they have the LR(0) cores, i.e., the same
##              items, ignoring lookahead.
##
##          genDotHtml.  Generate an HTML representation of this state
##              suitable for inclusion in a Graphviz description of the
##              automaton's graph (i.e., LR(1) FSM).
##              If the state is inadequate, outline it in red and display
##              inadequate items in red.
##              If this is a final state of the automaton, display the
##              action associated with the state (i.e., reduce by N or
##              Accept) in blue below the display of items.
##              If parameter 'outputForPS' is True (the default),
##              generate HTML designed to be processed by the -Tps and
##              -Tps2 drivers of the 'dot' program.  If 'outputForPS' is
##              False, generate HTML designed to be processed by the
##              -Tsvg driver of the 'dot' program.
##              If paramter 'stateDisplayName' is omitted, generate the
##              name of the state by prefixing 'State' in front of the
##              'dotInternalName' of the state.
##
##
from defs import isterminal, formatSetAsHtml
from lr1item import LR1Item

class LR1State(object):
    "An LR(1) state is a set of LR(1) items."
    def __init__(self,grammar,initialKernelItems=None):
        self.grammar = grammar
        self.items = []
        if initialKernelItems == None:
            self.addItem(LR1Item(grammar[0],set(['eps'])))
        else:
            for item in initialKernelItems: self.addItem(item)
        self.transitions = dict()
        
    def addItem(self,lr1Item):
        "Add another LR(1) item to this state."
        self.items.append(lr1Item)

    def close(self,first_sets):
        "Close this state. first_sets is a dict of the first sets of the grammar syms."
        itemQueue = self.items[:]
        ## First generate new items, not merging then at this point.
        while len(itemQueue) > 0:
            item = itemQueue.pop(0)
            for newItem in item.close(self.grammar,first_sets):
                if not newItem in self.items:
                    self.items.append(newItem)
                    itemQueue.append(newItem)
        ## This is the merging code. It carefully merges all items that share the same core.
        sharecorelist = len(self.items)*[-1]
        for i,item in enumerate(self.items):
            if sharecorelist[i] == -1:
                for j in range(i+1,len(self.items)):
                    newItem = self.items[j]
                    if newItem.hasSameCore(item):
                        sharecorelist[j] = i
                        item.lookahead.update(newItem.lookahead)
        newItems=[]
        for i,item in enumerate(self.items):
            if sharecorelist[i] == -1:  newItems.append(item)
        self.items = newItems
                

    def __repr__(self):
        s = '{ '
        for item in self.items: s += ' %s' % item
        s += ' }'
        return s

    ## Compare two LR(1) Items by checking to see if they have identical
    ## item sets. Note that the item sets are being represented as lists
    ## of LR(1) Items, hence the clumsy code needed for the comparison.
    ##
    def equals(self,lr1state):
        "Check for equality with another LR(1) State."
        if len(self.items) == len(lr1state.items):
            equals = True
            for item in self.items:
                if not item in lr1state.items:
                    ## print "     Mismatch on item", item, "in", self.items
                    ## print "       Comparing with", lr1state.items
                    equals = False
                    break
            return equals
        else:
            ## print "Mismatch, lengths differ", len(self.items), len(lr1state.items)
            return False

    def findTransitions(self):
        """Find symbols marking transitions out of this state & the
           associated items which result from these transitions."""
        trans = dict()
        for item in self.items:
            sym = item.getDottedSym()
            if sym != 'eps':
                newItem = item.advanceDot()
                if trans.has_key(sym): trans[sym].add(newItem)
                else: trans[sym] = set([newItem])
        return trans

    ##----------------------------------------------------------------------
    ##
    ## isAdequate -- Check to see if a fsm state has any shift-reduce or
    ##               reduce-reduce conflicts.  Uses the LR(1) lookahead
    ## context for each item to help resolve this.
    ##
    ## Flag "verbose" (which defaults to True) controls printing of
    ## messages about the check to the output stream.
    ## If it is set to True, detailed progress information is displayed,
    ## including information about conflicts. If False, noting is displayed
    ## and the only feedback from the method is the True/False status of
    ## the check.
    ##
    def isAdequate(self,stateNum,verbose=False):
        inadequates,shiftItems,reduceItems = self.getInadequates(stateNum,verbose)
        return (len(inadequates) == 0)


    ##----------------------------------------------------------------------
    ##
    ## getInadequates -- Return a triple (inadequates,sitems,ritems), where
    ##                   'inadequates' is a set of the inadequate items in
    ## this LR1State, 'sitems' is a list of the shift items in the state,
    ## and 'ritems' is a list of the reduce items in the state.
    ##    
    def getInadequates(self,stateNum,verbose=False):
        shiftItems = []
        shiftLookaheads = []
        reduceItems = []
        reduceLookaheads = []
        inadequateItems = set([])
        for item in self.items:
            sym = item.getDottedSym()
            if sym == 'eps':
                reduceItems.append(item)
                reduceLookaheads.append(item.lookahead)
            elif isterminal(sym):
                shiftItems.append(item)
                shiftLookaheads.append(sym)
        for (reduceitem,lookaheadset) in zip(reduceItems,reduceLookaheads):
            adequate = True
            for (shiftitem,lookaheadsym) in zip(shiftItems,shiftLookaheads):
                if lookaheadsym in lookaheadset:
                    inadequateItems.add(shiftitem)
                    adequate = False
                    if verbose:
                        print "-------------------------------------------------"
                        print "FSM state %d, shift-reduce conflict:" % stateNum
                        print "  Item %s (shift on %s) conflicts with" % \
                              (shiftitem,lookaheadsym)
                        print "  item %s (reduce on %s)" % \
                              (reduceitem,lookaheadset)
            if not adequate: inadequateItems.add(reduceitem)
        for i in range(len(reduceItems)):
            reduceSetA = reduceLookaheads[i]
            adequate = True
            for j in range(1+i,len(reduceItems)):
                reduceSetB = reduceLookaheads[j]
                if len(reduceSetA.intersection(reduceSetB)) != 0:
                    inadequateItems.add(reduceItems[j])
                    adequate = False
                    if verbose:
                        print "-------------------------------------------------"
                        print "FSM state %d, reduce-reduce conflict:" % stateNum
                        print "  Item %s (reduce on %s) conflicts with" % \
                              (reduceItems[i],reduceSetA)
                        print "  item %s (reduce on %s)" % \
                              (reduceItems[j],reduceSetB)
            if not adequate: inadequateItems.add(reduceItems[i])
        return inadequateItems,shiftItems,reduceItems
    

    ##----------------------------------------------------------------------
    ##
    ## isCognate -- Compare two LR1States to see of they have the same
    ##              LR(0) cores (i.e., their items are the same, ignoring
    ##              lookahead).  Returns True if the states are cognate.
    ##
    ## Flag "verbose" (which defaults to False) controls printing of
    ## messages about the check to the output stream.
    ##
    ## Because there is no guarantee about the order of the item lists in
    ## the two states, fairly clumsy code is needed to perform this
    ## check.  Note that the check depends on the states being in "merged"
    ## form.
    ##
    def isCognate(this,lr1state,verbose=False):
        if verbose:
            print "isCognate check:", this, lr1state
        cognate = True
        if len(this.items) == len(lr1state.items):
            for item in this.items:
                found = False
                for otherItem in lr1state.items:
                    if item.hasSameCore(otherItem):
                        found = True
                        break
                if not found:
                    if verbose: print "    No matching item for", item
                    cognate = False
                    break
        else:
            if verbose: print "    item list lengths don't match, can't be cognate"
            cognate = False
        if verbose: print "    Returning", cognate
        return cognate


    ##----------------------------------------------------------------------
    ##
    ## genDotHtml -- Generate a string describing this LR1State in
    ##               "dot-html" (i.e., the HTML-like syntax understood by
    ##               dot, neato and othe GraphViz programs).
    ##
    ## 'dotInternalName' is a number, the nuber of the state being
    ## described.  Used to generate the name of the state used internally
    ## by the GraphViz programs while processing.
    ##
    ## 'stateDisplayName' is a string, the name to be displayed in the
    ## state.  If omitted, defaults to 'State <num>', where <num> is the
    ## value passed to 'dotInternalName'.
    ##
    ## 'outputForPS' is a boolean.  If set, it tells the methods to
    ## generate HTMl suitable for processing by dots -Tps or -Tps2 filters.
    ##
    ## Note the use of the LR1Item method "formatAsHtml", and the
    ## funtion "formatSetAsHtml" from source file 'defs.py'.
    ##
    def genDotHtml(self,dotInternalName,stateDisplayName=None,outputForPS=True):
        """Generate a Graphviz language HTML representation of this state.  If
           the state is inadequate, outline it in red and display inadequate
           items in red.
           
           If parameter 'outputForPS' is True (the default),
           generate HTML designed to be processed by the -Tps and -Tps2
           drivers of the 'dot' program.  If 'outputForPS' is False,
           generate HTML designed to be processed by the -Tsvg driver of
           the 'dot' program.

           If paramter 'stateDisplayName' is omitted, generate the name
           of the state by prefixing 'State' in front of the
           'dotInternalName' of the state."""
        (inadequateItems,sItems,rItems) = self.getInadequates(dotInternalName)
        if len(inadequateItems) > 0: stateBorderColour = "red"
        else: stateBorderColour = "black"
        if not stateDisplayName: stateDisplayName = "State %s" % str(dotInternalName)
        s = """%s [shape=box, style="rounded", color="%s", """ %\
            (dotInternalName,stateBorderColour)
        if len(self.transitions) == 0:   ## A final state of the CFSM, with no transitions out.
            s += "peripheries=\"2\", "   ## has a "double circle".
        s += 'label=<\n<table border="0" cellborder="0" cellspacing="2" cellpadding="0">\n'
        ## If we have shift or reduce items, we will need 4 colums in the table, otherwise
        if len(rItems) > 0  or len(sItems) > 0: columnCount = 5  ## just 4 (no S or Rxx).
        else: columnCount = 4
        s += '<tr>\n    <td colspan="%d"><font color="#40a040">%s</font></td>\n</tr>\n' %\
             (columnCount,stateDisplayName)
        for item in self.items:
            if item in inadequateItems: itemColour = "red"
            else: itemColour = "black"
            ## Display the dotted item first in a row,
            s += '<tr>\n%s    ' % item.formatAsHtml(itemColour,outputForPS)
            ## and then the 'local predictor set' for reduce actions (all items have these
            ## sets in LR(1), but they only get used for reduce actions).
            s += '<td align="left"><font point-size="8" face="Helvetica">'
            s += '&#32;%s</font></td>' % formatSetAsHtml(item.lookahead)
            ## Finally, if the item has an associated shift or reduce action, display it.
            if item in sItems or item in rItems:
                ## Display shift and reduce actions in blue (2020f0).
                s += '<td>&#32;&#32;<font point-size="9" face="Helvetica" color="#2020f0">'
                if item in sItems: s += 'S'
                else:
                    ## For a reduce action, need to scan for production number.
                    pnum = 999
                    for i,p in enumerate(self.grammar):
                        if p == item.production:
                            pnum = i
                            break
                    if pnum == 0: s += 'A'    ## 'Reduction' by prod 0 is Accept.
                    else: s += 'R%d' % pnum   ## Otherwise just report by number, 'R2', etc.
                s += '</font></td>'
            s += '</tr>\n'
        s += "</table>>];"
        return s
