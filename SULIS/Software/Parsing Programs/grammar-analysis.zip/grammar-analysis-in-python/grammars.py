##==============================================================================
##
## grammars.py  
##
## Example grammars for use by the analysis algorithms.
##
## N.B. A grammar is represented very simply as a list of Production
## objects.  The definition of the Production class comes from 'def.py'.
##
##
from defs import Production, isterminal


##------------------------------------------------------------------------------
##
## First a group of utility functions to aid in pretty-printing a grammar.  Can
## output plain text (the default), a LaTeX tabular description or an HTML table
## suitable for processing by the GraphViz programs.
##
##
def prettyPrint(grammar,mode=None,start_index=0):
    "Pretty-Print a grammar as plain text (default), LaTeX or HTML."
    if mode == "latex":
        print genLaTeXGrammar(grammar,start_index)
    elif mode == "html":
        print genHtmlGrammar(grammar,start_index,targetPS=False)
    else:
        print genPlainTextGrammar(grammar,start_index)

def genLaTeXGrammar(grammar,start_index=0):
    "Format a grammar as a LaTeX tabular environment."
    s = "\\begin{tabular}{rcl@{\\hspace{5em}}r}\n"
    for i in range(start_index,len(grammar)):
        s += " $%s$ & $\\longrightarrow$ & $" % formatSymAsLaTeX(grammar[i].lhs)
        rhs = grammar[i].rhs
        if len(rhs) == 0: s += "\\epsilon"
        else:
            for sym in rhs: s += formatSymAsLaTeX(sym)
        s += "$ & (%d) \\\\[.5ex]\n" % i
    s += "\\end{tabular}"
    return s

def formatSymAsLaTeX(sym):
    "Format a grammar symbol in a form suitable for LaTeX."
    if sym == "eps": s = "\\epsilon"
    elif sym == "$": s = "\:\$"
    elif isterminal(sym):
        if len(sym) == 1: s = sym
        else: s = "\\mbox{``{\\bf %s}''}" % sym
    else:
        if len(sym) < 3: s = sym
        else: s = "\\langle\\mbox{\\sf %s}\\rangle" % sym[1:-1]
    return s

## Parameter "targetPS" means generate HTML code targeted at the
## "-Tps" or "-Tps2" filters of dot/GraphViz.  If False, generate
## more "generic" HTML (using the Unicode "righarrow" char, code 8596).
## Parameter "fontSize" is the desired point size.
def genHtmlGrammar(grammar,start_index=0,targetPS=True,fontSize=10):
    "Format a grammar as an HTML table suitable for processing by dot."
    s = '<table border="0" cellborder="0" cellspacing="2" cellpadding="2">\n'
    for i in range(start_index,len(grammar)):
        s += '<tr>' + grammar[i].formatHTML(targetPS,fontSize)
        s += '<td><font face="Helvetica" color="#2020f0"'
        s += ' point-size="%d">' % (fontSize-1)
        s += '&#32;&#32;(%d)</font></td></tr>\n' % i
    s += '</table>'
    return s

def genPlainTextGrammar(grammar,start_index=0):
    "Format a grammar in plain text suitable for a terminal."
    maxLHSlen = max([len(prod.lhs) for prod in grammar[start_index:]])
    rhses = []
    for prod in grammar:
        rhs = prod.rhs
        if len(rhs) == 0: rhses.append('eps')
        elif len(rhs) == 1: rhses.append(rhs[0])
        else: rhses.append(reduce(lambda a,b: a + ' ' + b, prod.rhs))
    maxRHSlen = max([len(rhs) for rhs in rhses])
    s = ""
    for i in range(start_index,len(grammar)):
        lhs = grammar[i].lhs
        rhs = rhses[i]
        s1 = lhs.rjust(maxLHSlen) + ' --> ' + rhs.ljust(maxRHSlen)
        s += '%s  (%d)\n' % (s1,i)
    return s

##------------------------------------------------------------------------------
##
## Another utility, good for parsing a simple BNF grammar from a string.
##
## parseGrammar - parse a text string (with possible multiple productions
## into a grammar (a list of Production objects).
##
## Productions are separated by newlines (one production per line).
## A production is a nonterminal on its left-hand-side, followed by
## '-->', followed by zero or more space-separated terminals and/or
## nonterminals.  A nonterminal is an uppercase letter or a string
## in <> brackets.  A terminal is anything else.  Terminal 'eps' is
## special, is is the null string.  Note that you can't have spaces
## inside nonterminals, they won't parse properly.  Use underscores
## instead, (e.g., <An_Identifier> instead of <An Indentifier>).
##
## N.B.  This routine does very little sanity checking, it expects
## 'reasonable' inputs.
##

def parseGrammar(grammarString):
    grammar = []
    grammarProdStrs = grammarString.splitlines()
    ##print grammarProdStrs
    for prodStr in grammarProdStrs:
        prodList = prodStr.split('-->')
        lhs = prodList[0].strip()
        if len(lhs) > 0:
            ## print lhs, prodList
            if len(prodList) < 2: rhs = []
            else:
                rhs = [ s for s in prodList[1].split() if s.lower() != 'eps' ]
            grammar.append(Production(lhs,rhs))
    return grammar
                       

##------------------------------------------------------------------------------
##
## G1 is the example grammar from p 123 & 134 of the printed notes.  It is
## not LR(0), but is SLR, LR(1) and LALR(1).
##
G1 = parseGrammar("""S --> a B A
                     B --> b B
                     B --> eps
                     A --> a A
                     A --> eps""")


##------------------------------------------------------------------------------
##
## G2 is from p 125 of the printed notes.  It is a simple LR(0) grammar.
## (It is also a finite grammar, with exactly one sentence in its
## language.)
##
G2 = parseGrammar("""S --> A B A B
                     A --> a
                     B --> b""")


##------------------------------------------------------------------------------
##
## G3 is from page 132 of the printed notes.  It is an LR(0) grammar
## describing an infinite language.  Note that it is left-recursive,
## LR(0) has no problem with this.
##
G3 = parseGrammar("""
                    S --> A B C
                    A --> A a
                    A --> a
                    B --> B b
                    B --> b
                    C --> c
     """)
      

##------------------------------------------------------------------------------
##
## A simple left-recursive grammar which is not LL(1), but is LR(0).
##
G4  = [Production('A',['A','a']),              # A --> A a
       Production('A',['a'])]                  # A --> a


##------------------------------------------------------------------------------
##
## This, very similar, grammar is also not LL(1), but is LR(0).
## It is interesting in that its LR(0) CFSM has a default
## reduce action associated with state 0. State 0 of the CFSM
## has three items, but two of them ([<Aug> -> _ A $] and
## [A --> _ A a]) have nonterminals to the right of their
## dots, so don't contribute to the Action table.  Only the
## item [A --> eps _] associated with the null-production 
## contributes, with R2 actions on lookahead 'a' and '$'.
##
G5  = [Production('A',['A','a']),              # A --> A a
       Production('A',[])]                     # A --> eps


##------------------------------------------------------------------------------
##
## The LL(1) expression grammar from the notes is not LR(0), but is
## SLR, LR(1) and LALR(1).
##
G6  = [Production('S',['B', 'A']),             # S --> B A
       Production('A',['a', 'B', 'A']),        # A --> a B A
       Production('A',[]),                     # A --> eps
       Production('B',['E', 'C']),             # B --> E C
       Production('C',['c', 'E', 'C']),        # C --> c E C 
       Production('C',[]),                     # C --> eps 
       Production('E',['e', 'S', 'f']),        # E --> e S g 
       Production('E',['g'])]                  # E --> g


##------------------------------------------------------------------------------
##
## This ambiguous grammar is neither LR(0), SLR, LR(1) or LALR(1).
##
G7  = [Production('S',['A', 'B', 'B', 'A']),   # S --> A B B A   (messy 
       Production('A',['C', 'D']),             # A --> C D        ambiguous
       Production('B',['b']),                  # B --> b          grammar)
       Production('B',['B', 'b']),             # B --> B b
       Production('B',[]),                     # B --> eps
       Production('C',['C', 'c']),             # C --> C c
       Production('C',[]),                     # C --> eps
       Production('D',['C'])]                  # D --> C


##------------------------------------------------------------------------------
##
## This dangling-else grammar is also ambiguous, so is not LL(1),
## LR(0), SLR, LR(1) or LALR(1).
##
G8  = [Production('S',['A']),                  # S --> A
       Production('S',['I']),                  # S --> I
       Production('S',['B']),                  # S --> B 
       Production('A',['a']),                  # A --> a
       Production('I',['i','O','t','S','E']),  # I --> i O t S E
       Production('E',['e','S']),              # E --> e S
       Production('E',[]),                     # E --> eps
       Production('O',['o']),                  # O --> o
       Production('B',['b','L','n']),          # B --> b L n
       Production('L',['S','s','L']),          # L --> S s L
       Production('L',[])]                     # L --> eps


##------------------------------------------------------------------------------
##
## This grammar is from the notes, where it is used to generate
## an LL(1) table-driven parser.
##
G9  = [Production('E',['T','A']),              # E --> T A    
       Production('A',['+', 'T','A']),         # A --> + T A
       Production('A',['-','T','A']),          # A --> - T A
       Production('A',[]),                     # A --> eps
       Production('T',['F','B']),              # T --> F B
       Production('B',['*','F','B']),          # B --> * F B
       Production('B',['/','F','B']),          # B --> / F B
       Production('B',[]),                     # B --> eps
       Production('F',['-','S']),              # F --> - S
       Production('F',['S']),                  # F --> S
       Production('S',['v']),                  # S --> v
       Production('S',['(','E',')'])]          # S --> ( E )


##------------------------------------------------------------------------------
##
## This is Grammar G3 from Fischer & LeBlanc, p 156.  This
## grammar is not LR(0), but it is SLR and LR(1).  Its LR(0)
## CFSM (used by SLR) has 13 states, its LR(1) machine has
## 23 states.
##
G10 = [Production('E',['E','+','T']),          # E --> E + T
       Production('E',['T']),                  # E --> T
       Production('T',['T','*','P']),          # T --> T * P
       Production('T',['P']),                  # T --> P
       Production('P',['id']),                 # P --> id
       Production('P',['(', 'E', ')'])]        # P --> ( E )


##------------------------------------------------------------------------------
##
## This is Grammar G4 from Fischer & LeBlanc, p 163.  This
## grammar is not SLR, but is LR(1) and LALR(1).  Note that I have replaced
## the terminal ',' in the F7LeB version with 'c', this makes the 'dot'
## diagrams of the grammar's SLR and LALR(1) FSM's easier to read.
##
G11 = [Production('E',['(', 'L', 'c', 'E', ')']),
       Production('E',['S']),
       Production('L',['L', 'c', 'E']),
       Production('L',['E']),
       Production('S',['id']),
       Production('S',['(', 'S', ')'])]


##------------------------------------------------------------------------------
##
## This is Grammar G6 from Fischer & LeBlanc, p 168.  This
## grammar is LR(1) but is not LALR(1) (or SLR).
##
G12 = [Production('S',['(', '<Exp1>', ')' ]),
       Production('S',['[', '<Exp1>', ']' ]),
       Production('S',['(', '<Exp2>', ']' ]),
       Production('S',['[', '<Exp2>', ')' ]),
       Production('<Exp1>',['id']),
       Production('<Exp2>',['id'])]

##------------------------------------------------------------------------------
##
## A simplified form of a "dangling-else grammar".  This should generate
## shift-reduce conflicts.
##
Gde = parseGrammar("""
<stmt> --> if <stmt> else <stmt>
<stmt> --> if <stmt>
<stmt> --> n
""")

##------------------------------------------------------------------------------
##
## This is Grammar G7 from Fischer & LeBlanc, p 171.  This
## is used to illustrate the construction of propagate links
## and spontaneous lookahead sets in a LALR(1) propagate
## construction.
##
## N.B.  Renaming from F&LB
##
##       Production 0 (S --> Opts $) is handled by the
##       automatically generated augmenting production, so
##       looks like <Aug> --> <Opts> $.
##
##      F&LB's symbol        Here
##          S                <Aug>
##          Opts             <Opts>
##          Opt              <Opt>
##          Id               id
##
flbG7 = [Production('<Opts>',['<Opt>','<Opt>']),
         Production('<Opt>',['id'])]

##------------------------------------------------------------------------------
##
## This is the non-SLR(k) grammar from page 242 of the new version of
## Fischer & LeBlanc.
##
G100 = [Production('S',['A','B']),                # S --> A B  
        Production('S',['a','c']),                # S --> a c  
        Production('S',['x','A','c']),            # S --> x A c
        Production('A',['a']),                    # A --> a
        Production('B',['b']),                    # B --> b
        Production('B',[])]                       # B --> eps

##------------------------------------------------------------------------------
##
## This is the second version of the grammar from page 242 of the new version of
## Fischer & LeBlanc.  Nonterminal "A" from the original is now split into two
## "version".  F&LeB call them $A_1$ and $A_2$.  I've used W (for $A_1$) and
## V (for $A_2$).  This introduces an extra production but makes the resulting
## grammar SLR(1).
##
G101 = [Production('S',['W','B']),                # S --> W B   (FLB: S --> A_1 B)  
        Production('S',['a','c']),                # S --> a c  
        Production('S',['x','V','c']),            # S --> x V c (FLB: S --> x A_2 c)
        Production('W',['a']),                    # W --> a     (FLB: A_1 --> a)
        Production('V',['a']),                    # V --> a     (FLB: A_2 --> a)
        Production('B',['b']),                    # B --> b
        Production('B',[])]                       # B --> eps


##------------------------------------------------------------------------------
##
## This is the grammar from example 4.61, p 271, Aho, Lam Sethi, Ullman, used
## to illustrate LALR(1) construction from the kernel sets of the LR(0) CFSM.
##
G200 = [Production('S',['L', '=', 'R']),          # S --> L = R
        Production('S',['R']),                    # S --> R
        Production('L',['*','R']),                # L --> * R
        Production('L',['id']),                   # L --> id
        Production('R',['L'])]                    # R --> L


##------------------------------------------------------------------------------
##
## This ambiguous expression grammar is neither LR(0), SLR, LR(1) or LALR(1).
## However, if shift-reduce parsing conflicts are allowed in the FSM of the
## grammar, and resolved by default as reductions, then the grammar
## is parsable.  "lalr1-propagate.py" has this ability to allow shift-
## reduce conflicts in a grammar.
##
G201 = parseGrammar("""
    E --> E * E
    E --> E + E
    E --> id""")

## One point to be aware of, however: resolving in favour of shifts is the
## approach used to generate a working parser for a grammar with shift-
## reduce conflicts (this is used by lalr1-propagate.py if S-R conflicts
## are explicitly allowed).  This approach allows "dangling-else" grammars
## to be handled neatly, but may not have the intended result for other
## grammars with S-R conflicts.
##
## For example, "id + id * id" associates as "id + (id * id)",
## but "id * id + id" as "id * (id + id)", and "id * id + id * id" as
## "id * (id + (id * id))".  In other words, favouring shifts makes
## the grammer automatically right-associative, and does not convey the
## "natural" precedence of the operators.
##
## One way to overcome this, while allowing ambiguous grammars, is to
## allow precedence to be explicitly tied to operators.  The idea is that
## if a shift-reduce conflict occurs, a reduction is applied if one of the
## operators in the predict set of the reduction has a higher precedence
## than the operator involved in the shift, otherwise the shift is
## applied.  This is what happens in Yacc, which favours shifts over
## reductions (as in lalr1-propagate.py), but can also use explicitly
## supplied precedence information to override this rule on a case-by-case
## basis.
##



##------------------------------------------------------------------------------
##
## This is a test grammar, based on Appel, 1st ed, p 78, where he is 
## discussing error recovery in LR(k).
## The discussion on p 78-9 concerns using the Yacc ERROR token.  His claim
## is that the ERROR token should be treated as a simple terminal during
## table construction.
##
## This grammar has an inbuilt shift-reduce conflict in state 10.  In Yacc
## and Bison, this conflict can be resolved by giving precedence to reduce
## actions over shifts.  Most of my LR parser generators can't handle this,
## but "lalr1-propagate.py" has been modified to allow it.  Set the third
## argument to the LALR1Machine constructor from this code to True to allow
## it to accept S-R conflicts but still generate an Action table.
##
## A point worth noting, this grammar makes a really good test of the
## programs' ability to work with a very complex recursive grammar that
## has conflicts.  It is a particularly good test of the ability of the
## programs to handle complex closures.
##
##  <exp>  --> "id"
##  <exp>  --> <exp> "+ <exp>
##  <exp>  --> "(" <exps> ")"
##  <exps> --> <exp>
##  <exps> --> <exps> ";" <exp>
##  <exp>  --> "(" ERROR ")"   <-- special Error token
##  <exps> --> ERROR ";" <exp>
##
## The construction should treat ERROR like a terminal, so it is specified 
## here by terminal "error".
##
## Parsing should be performed by routine "parseER", which implements yacc/
## Bison style error recovery using an 'error' pseudotoken.  See the
## method documentation for 'parseER' and 'syntaxError' in class LRBase
## for details of how this works (file lrbase.py).
##
##
Gappel78 = [Production("<exp>", ["id"]),
            Production("<exp>", ["<exp>", "+", "<exp>"]),
            Production("<exp>", ["(", "<exps>", ")"]),
            Production("<exps>",["<exp>"]),
            Production("<exps>",["<exps>",";","<exp>"]),
            Production("<exp>", ["(", "error", ")"]),     ## Error-recovery production.
            Production("<exps>",["error", ";", "<exp>"])] ## Error-recovery production.

##
## Gappel79 is the same as Gappel78 but with the error-token removed. Has
## the same shift-reduce conflict in state 10.  A good test of the programs.
##
Gappel79 = [Production("E",["id"]),
            Production("E",["E","+","E"]),
            Production("E",["(","S",")"]),
            Production("S",["E"]),
            Production("S",["S",";","E"])]

##
## Here is a simple grammar that avoids the shift-reduce conflict of the Appel
## grammars above, but has error productions.  The sync points are on ";" and
## ")".
## This grammar is LALR(1), SLR(1) and LR(1).  Try with strings like
## "id - id ; ( id - id )" to see error recovery to the two sync points 
## using "parseER".
##
G300=parseGrammar("""
                  <explist> --> <explist> ; <exp>
                  <explist> --> error ; <exp>
                  <explist> --> <exp>
                  <exp>     --> <term>
                  <exp>     --> <exp> + <term>
                  <term>    --> ( <explist> )
                  <term>    --> ( error )
                  <term>    --> id
                  """)
##------------------------------------------------------------------------------
##
