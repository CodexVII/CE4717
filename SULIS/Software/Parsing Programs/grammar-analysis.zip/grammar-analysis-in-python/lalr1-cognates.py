##==============================================================================
##
## lalr1-cognates.py
##
## A Python program that builds the LALR(1) machine for a grammar by first
## constructing the LR(1) Finite State Machine for the grammar and then
## merging the LR(1) states into an LALR(1) fsm.  This is the "long-winded"
## approach to LALR(1) construction.
##
## Once the LALR FSM is built, an LALR(1) check is performed and, if this
## passes, corresponding Action and GoTo tables for the LALR(1) parser
## are constructed.  Note that this program uses the "merging-states"
## approach to LR(1) FSM construction; and this is key to the approach
## used to build the LALR(1) FSM form the LR(1) FSM, the underlying
## assumption in this conversion being that there are duplicate core
## LR(1) items in any LR1State, i.e., that duplicate items differing
## only in lookahead context are not allowed.
##
##------------------------------------------------------------------------------
##
## Use:
##
##     >>> from grammars import *      ## <-- Get some grammar definitions.
##     >>> lalr1g11=LALR1Machine(G11)  ## <-- Create LALR(1) automation for G11.
##     >>> lalr1g11.displayLR1FSM()    ## <-- Show the LR(1) FSM for G11.
##     >>> lalr1g11.displayLALR1FSM()  ## <-- Show the LALR(1) FSM for G11.
##     >>> lalr1g11.displayAction()    ## <-- Show the LALR(1) Action table.
##     >>> lalr1g11.displayGoTo()      ## <-- Show the GoTo table.
##     >>> lalr1g11.parse('( id  )')   ## <-- Parse an input string, displaying
##                                     ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, '(id)' would be scanned as the single
## token '(id)', not the three tokens '(', 'id', ')'.
##
##
##     >>> lr1g11.outputDot('l.dot') ## <-- Output a description of the FSM 
##                                   ##     of this LALR(1) automaton to file 
##                                   ##     'l.dot' in a form suitable for
##                                   ##     processing by 'dot -Tps2'.
####
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LALR1Machine -- This represents the LALR(1) recogniser for a given
##                    grammar.
##
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Defaults to True.
##
##          findCognates.  Finds sets of cognate LR(1) states in the LR(1)
##              FSM.  Returns a list of such cognate state sets.  These
##              can be used to build a LALR(1) FSM for the grammar.  This
##              routine is called automatically by the constructor.
##
##          merge.  Builds a list of LALR(1) states (i.e., an LALR(1) FSM)
##              using an LR(1) FSM and a list of set of cognate LR(1)
##              states.  Assumes that "buildLR1FSM" and "findCognates"
##              have already completed their work. This routine is called
##              automatically by the constructor.
##
##          buildFSM.  Builds the LR(1) FSM for the grammar. Called
##              automatically by the constructor. Method inherited from
##              superclass "LR1Machine".
##
##
##          displayLR1FSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          displayLALR1FSM.  Ditto, but for the LALR(1) FSM.
##
##          checkAdequate.  Checks to see if the FSM supplied as an argument
##              does not contain any inadequate states (i.e., no shift-
##              reduce or reduce-reduce conflicts).  Called automatically by
##              the constructor on both the LR(1) and LALR(1) candidate
##              FSMs.
##
##          genActions.  Generates the Action table for an LALR(1) automaton
##              from its FSM. Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayAction.  Displays the Action table associated with
##              this LALR(1) automaton in "pretty-printed" tabular style.
##
##          genGoTo.  Generates the GoTo table for an LALR(1) automaton
##              from its FSM. Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayGoTo.  Displays the GoTo table associated with
##              this LALR(1) automaton in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this LALR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from LRBase (abstract base class).
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from LRBase (abstract base class).
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from LRBase (abstract base class).
##
##          genDot.  Return a multi-line string containing a description
##              of the LALR(1) FSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##              Inherited from LR1Machine.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LALR(1) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##              Inherited from LR1Machine.
##
##      Utility Method -- not for general use:
##      ----------------------------------------------------------------
##
##          displayFSM.  Displays an FSM in "pretty-printed" style to
##              the terminal.  A static method, it is passed the FSM
##              to display.  Used by methods "displayLR1FSM" and
##              "displayLALR1FSM".
##
##------------------------------------------------------------------------------
##
##      LR1State --  Represents a set of LR(1) Items making up a state of the
##                   LR(1) Finite State Machine.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(1) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation of the Items in this state.
##
##          equals.  Check to see if this LR(1) state and the argument, 
##              another such state, are equal.  Two LR(1) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR1State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR0States.
##
##          isAdequate.  Return True if this LR1State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state.
##
##          isCognate.  Return True if this LR1State is "cognate" with
##              another one (passed as an argument).  "Cognate" means that
##              the two LR1States have the same LR(0) cores, i.e. the same
##              LR(0) items (ignoring LR(1) lookahead contexts) and are
##              suitable to be merged together into a single LALR(1) state.
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
## LR(1) Items (dotted productions) are represented as LR1Item objects.
##
##------------------------------------------------------------------------------
##
##

from defs import isterminal, findallsyms, augmentGrammar
from ff import fill_first_sets
from lr1item import LR1Item
from lr1state import LR1State
from lr1 import LR1Machine

##==============================================================================
##
## class LALR1Machine -- This represents the LALR(1) recogniser for a given
##      grammar.
##
##      N.B. the grammar is quietly augmented before the LR(1) FSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Defaults to True.
##
##          findCognates.  Finds sets of cognate LR(1) states in the LR(1)
##              FSM.  Returns a list of such cognate state sets.  These
##              can be used to build a LALR(1) FSM for the grammar.  This
##              routine is called automatically by the constructor.
##
##          merge.  Builds a list of LALR(1) states (i.e., an LALR(1) FSM)
##              using an LR(1) FSM and a list of set of cognate LR(1)
##              states.  Assumes that "buildLR1FSM" and "findCognates"
##              have already completed their work. This routine is called
##              automatically by the constructor.
##
##          displayLR1FSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          displayLALR1FSM.  Ditto, but for the LALR(1) FSM.
##
##          checkAdequate.  Checks to see if the FSM supplied as an argument
##              does not contain any inadequate states (i.e., no shift-
##              reduce or reduce-reduce conflicts).  Called automatically by
##              the constructor on both the LR(1) and LALR(1) candidate
##              FSMs.
##
##
##

class LALR1Machine(LR1Machine):
    "The LALR(1) recogniser for a grammar."
    def __init__(this,grammar,verbose=True):
        this.grammar = augmentGrammar(grammar)  ## Note augmentation.
        this.lr1fsm = this.buildFSM(False)      ## Build the LR(1) FSM first.
        if LALR1Machine.checkAdequate(this.lr1fsm,"LR(1)",verbose):
            this.lr1cognates=this.findCognates()
            if verbose: print "LR(1) cognate states:", this.lr1cognates
            this.fsm=this.merge()
            if verbose: print 35*"=="
            if LALR1Machine.checkAdequate(this.fsm,"LALR(1)", verbose):
                this.actionTable = this.genActions(this.fsm)
                this.gotoTable = this.genGoTo()
            else:
                print "Can't build LALR(1) machine, grammar is LR(1) but not LALR(1)"
                this.actionTable = None
                this.gotoTable = None
        else:
            print "Can't build LALR(1) machine, grammar is not LR(1)"
            this.actionTable = None
            this.gotoTable = None


    ##----------------------------------------------------------------------
    ##
    ## Find the sets of cognate states in the LR(1) FSM for the grammar.
    ##
    ## "this.lr1fsm" is the list of LR(1) states.
    ##
    ## Returns a list of sets.  Each element of the list is a set of LR(1)
    ## cognate states, each such LR(1) state represented by its state number
    ## (i.e., index into "this.lr1fsm").
    ##
    ## Two LR(1) states are cognate if they share the same core (i.e., have
    ## exactly the same items, disregarding lookahead context).
    ##
    ## N.B., duplicate sets of cognate states are not allowed in the list
    ## (i.e., every set of cognate states is unique).  This is important
    ## because it is assumed by method "merge".
    ##
    def findCognates(this):
        cognates_list=[]
        for statenum,lr1state in enumerate(this.lr1fsm):
            state_not_already_in_cognates = True
            for cognates_set in cognates_list:
                if statenum in cognates_set:
                    state_not_already_in_cognates = False
                    break
            if state_not_already_in_cognates:
                new_cognate_set = set([statenum])
                for other_statenum,other_lr1state in enumerate(this.lr1fsm):
                    if other_statenum != statenum and lr1state.isCognate(other_lr1state):
                        new_cognate_set.add(other_statenum)
                cognates_list.append(new_cognate_set)
        return cognates_list

    ##----------------------------------------------------------------------
    ##
    ## Merge the states of the LR(1) FSM to build the LALR(1) FSM.
    ## Needs the list of sets of cognate LR(1) states build by method
    ## "findCognates".  The LR(1) state list is in "this.lr1fsm", the
    ## list of sets of cognate LR(1) states in "this.lr1cognates".
    ##
    ## Returns the LALR(1) FSM for the grammar.  This is a list of
    ## LR1State objects, just like the LR(1) FSM but representing the
    ## LALR(1) FSM.
    ##
    ##
    def merge(this):
        lalr1fsm = []
        lr1mapping = len(this.lr1fsm)*['?'] ## A map from LR(1) states to LALR(1) states.
        for cognate_index,cognate_set in enumerate(this.lr1cognates):
            if len(cognate_set) == 0:   ## Error, can't have an empty set of cognates.
                print "Error, LALR state %s, no LR(1) cognates" % cognate_index
                return []
            first_state_in_cognate_set = True
            for state_index in cognate_set:
                lr1mapping[state_index] = cognate_index
                lr1_state = this.lr1fsm[state_index]
                if first_state_in_cognate_set:
                    item_list = []
                    for item in lr1_state.items:
                        new_item=LR1Item(item.production,set(item.lookahead))
                        new_item.dotPosition=item.dotPosition
                        item_list.append(new_item)
                    lalr1_state = LR1State(this.grammar,item_list)
                    lalr1fsm.append(lalr1_state)
                    first_state_in_cognate_set = False
                else:
                    lalr1_state = lalr1fsm[cognate_index]
                    for itemA in lalr1_state.items:
                        for itemB in lr1_state.items:
                            if itemA.production == itemB.production and \
                               itemA.dotPosition == itemB.dotPosition:
                                itemA.lookahead.update(itemB.lookahead)
            
        ## Build LALR1 transitions for new state machine
        for index,lalr1_state in enumerate(lalr1fsm):
            lr1_state = list(this.lr1cognates[index])[0]
            for sym,lr1_target_state in this.lr1fsm[lr1_state].transitions.iteritems():
                lalr1_state.transitions[sym] = lr1mapping[lr1_target_state]

        return lalr1fsm
                        
    ##----------------------------------------------------------------------
    ##

    def displayLR1FSM(this):
        this.displayFSM(this.lr1fsm,"The LR(1) FSM for the grammar.")

    def displayLALR1FSM(this):
        this.displayFSM(this.fsm,"The LALR(1) FSM for the grammar.")
        
    ##----------------------------------------------------------------------
    ##
    ## displayFSM -- output a FSM in "pretty-printed" style.  The FSM
    ## is passed in as a parameter, allowing the LR(1) FSM or the LALR(1)
    ## FSM to be displayed.
    ##
    @staticmethod
    def displayFSM(fsm,title=None):
        "Pretty-print a Finite State Machine of this automaton."
        if title and isinstance(title,str):
            print title
        for i,lr1state in enumerate(fsm):
            print "=====================================\nState %d" % i
            if len(lr1state.items) > 0:
                print "  Items:"
                for item in lr1state.items: print "    %s" % item
            else:
                print "  No items in this state!! ERROR!!"
            if len(lr1state.transitions) > 0:
                print "  Transitions:"
                for (sym,target) in lr1state.transitions.iteritems():
                    print "    '%s' ==> %d" % (sym,target)
            else:
                print "  No transitions out of this state"

    ##----------------------------------------------------------------------
    ##
    ## checkAdequate -- Check to see if an FSM is adequate, i.e., that
    ##      it contains no inadequate states (i.e., no shift-reduce or
    ##      reduce-reduce conflicts).  Returns True if no inadequate LR(1)
    ##      states are found, False otherwise.  If the automaton contains
    ##      inadequate states, reports on them to the output as well.
    ##
    @staticmethod
    def checkAdequate(fsm,title,verbose=False):
        "Check to see if this FSM contains no inadequate states."
        if verbose:
            s = "Checking if grammar is " + title
            print s
            print len(s)*"="
        status = []
        for stateNum,lr1state in enumerate(fsm):
            status.append(lr1state.isAdequate(stateNum,verbose))
        for s in status:
            if not s:
                if verbose: print "Grammar is NOT " + title
                return False
        if verbose: print "Grammar is " + title
        return True

    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an automaton (LR(1) or
    ##               LALR(1)) from its FSM.
    ##
    ## Note: Assumes that the grammar has been checked by "checkAdequate".
    ## Happens automatically in the constructor.  What is generated is a
    ## dictionary indexed by (sym,stateNumber) tuples indicating the action
    ## to take with "stateNumber" on the top of the parse stack and lookahead
    ## "sym".  An entry in the dictionary is either 'S' (a shift action),
    ## 'A' (an accept action), or a positive number corresponding to a
    ## production number in the augmented grammar associated with the
    ## machine.  Blank entries in the table are not represented explictly.
    ## 
    ##
    def genActions(this,fsm):
        actionTable = dict()
        for stateNum,lr1state in enumerate(fsm):
            for item in lr1state.items:
                lookaheadSym = item.getDottedSym()
                if lookaheadSym == 'eps':  ## Dot at right-end => reduction.
                    ## Find index of production to reduce by.
                    for prodNum,prod in enumerate(this.grammar):
                        if prod == item.production: break
                    ## Now iterate over the symbols in the lookahead context.
                    for lookaheadSym in item.lookahead:
                        if lookaheadSym != 'eps':
                            actionTable[(lookaheadSym,stateNum)] = prodNum
                        else:
                            if prodNum == 0: ## Augmenting production
                                actionTable[('$',stateNum)] = 'A'
                            else:
                                print "Error in Action Table construction"
                                print "Lookahead of eps encountered on item %s" %\
                                      item
                                return None
                elif isterminal(lookaheadSym):
                    actionTable[(lookaheadSym,stateNum)] = 'S'
        return actionTable

        

##==============================================================================
##==============================================================================
##==============================================================================
##
## Debugging. G11 is of interest here because it is LALR(1) but *not* SLR.
## 
##
##
from grammars import *
print "G11 = ", G11

lalr1g11=LALR1Machine(G11,False)

print "lalr1g11 = ", lalr1g11
