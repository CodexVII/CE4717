##==============================================================================
##
##
## lr1.py
##
## A Python program that builds the LR1 Finite State Machine and the 
## corresponding Action and GoTo tables for an LR(1) grammar.
##
## Use:
##
##     >>> from grammars import *    ## <-- Get some grammar definitions.
##     >>> lr1g11=LR1Machine(G11)    ## <-- Create an LR(1) automation for G11.
##     >>> lr1g11.displayFSM()       ## <-- Show the LR(1) FSM.
##     >>> lr1g11.displayAction()    ## <-- Show the LR(1) Action table for G11.
##     >>> lr1g11.displayGoTo()      ## <-- Show the GoTo table for G11.
##     >>> lr1g11.parse('( id  )')   ## <-- Parse an input string, displaying
##                                   ##     stack, input and actions/gotos.
##
## N.B. Parse employs a primitive approach to identifying tokens in the input
## string, they are simply separated by whitespace.  Parse doesn't include
## a full scanner, so, for example, '(id)' would be scanned as the single
## token '(id)', not the three tokens '(', 'id', ')'.
##
##
##     >>> lr1g11.outputDot('l.dot') ## <-- Output a description of the FSM 
##                                   ##     of this LR(1) automaton to file 
##                                   ##     'l.dot' in a form suitable for
##                                   ##     processing by 'dot -Tps2'.
##
##
##
##------------------------------------------------------------------------------
##
## Main Classes and Methods:
##
##      LR1Machine -- This represents the LR(1) recogniser for a given
##                    grammar.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  This flag argument
##              defaults to True.
##
##          buildFSM.  Builds the LR(1) Finite State Machine for the grammar.
##              Called automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayFSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          checkLR1.  Checks to see if the FSM built by 'buildFSM' is
##              in fact, LR(1), (i.e., that it does not contain any
##              inadequate states).  Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(1) automaton
##              from its FSM.  Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this FSM in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          genGoTo.  Generates the GoTo table for an LR(1) automaton
##              from its FSM.  Called automatically by constructor.
##              Inherited from LRBase (abstract base class).
##
##          displayGoTo.  Displays the GoTo table associated with
##              this FSM in "pretty-printed" tabular style.
##              Inherited from LRBase (abstract base class).
##
##          parse.  Parses an input string (of simple, space-separated
##              terminal symbols) according to the Action and GoTo
##              tables of this LR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##              Inherited from LRBase (abstract base class).
##
##          parseER.  "Error Recovery" parsing.  A version of parse that
##              implements a basic version of the Yacc/Bison error-
##              recovery scheme.  Uses the same "pretty-printed"
##              output style as "parse".
##              Inherited from LRBase (abstract base class).
##
##          parseST. "Quietly" parses an input string and returns a data
##              structure representing the Syntax Tree of the input.
##              N.B., If the parse fails (bad input, causing a syntax
##              error), the routine returns None.  It will also print
##              out some terse diagnostic information about the source
##              of the error, but, in general, it is best to run
##              "parse" (or better, "parseER") to get detailed info
##              about the problem.
##              Inherited from LRBase (abstract base class).
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(1) FSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(1) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##
##
##      Utility Methods needed by base class methods and implemented here
##      -----------------------------------------------------------------
##
##          rejectMessage.  Returns a string representing a 'Reject'
##              action coming from the Action table.
##
##          getFSMStateCount.  Returns a count of the number of states in
##              this parsing automaton's LR(1) FSM.
##
##          getFSM.  Returns the LR(1) FSM of this parsing automaton.
##
##
##------------------------------------------------------------------------------
##
##      LR1State --  Represents a set of LR(1) Items making up a state of the
##                   LR(1) Finite State Machine.
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              associated with this state, the second a list or set
##              of kernel items associated with the state.  This defaults
##              to None.
##
##          addItem.  Add a new Item to the kernel set of this state.
##
##          close.  Perform the LR(1) closure operation on the Items already
##              in this state.
##
##          __repr__.  Print a representation of the Items in this state.
##
##          equals.  Check to see if this LR(1) state and the argument, 
##              another such state, are equal.  Two LR(1) states are equal
##              if they possess the same Item sets.  Since two identical
##              kernel sets must have identical closure sets, only equality
##              of the kernel sets is checked.
##
##          findTransitions.  Find all possible transitions out of this
##              LR1State (which is assumed to have been closed).  A 
##              dictionary is returned indexed by transition symbol and
##              containing sets of target Items that will become the
##              basis for new LR0States.
##
##          isAdequate.  Return True if this LR1State is free of shift-
##              reduce and reduce-reduce conflicts.  Accepts a state
##              number as argument and, if the state is inadequate,
##              prints an error report to the output using the state
##              number to identify the state.
##
##
##------------------------------------------------------------------------------
##
## A grammar is represented as a list of "Production" objects.
##
## LR(1) Items (dotted productions) are represented as LR1Item objects.
##
##------------------------------------------------------------------------------
##
##

from defs import isterminal, findallsyms, augmentGrammar
from grammars import genHtmlGrammar 
from ff import fill_first_sets
from lrbase import LRBase
from lr1item import LR1Item
from lr1state import LR1State

##==============================================================================
##
## class LR1Machine -- This represents the LR(1) recogniser for a given
##      grammar.
##
##      N.B. the grammar is quietly augmented before the LR(1) FSM is 
##      constructed.  The augmenting production always has the form
##      <Aug> --> <start symbol> $. 
##
##      Methods:
##          Constructor.  Takes two arguments, the first is the grammar
##              for which a recogniser is to be built, the second a flag
##              ('verbose') which indicates whether to print out messages
##              during the course of construction.  Default to True.
##
##          buildFSM.  Builds the LR(1) FSM for the grammar. Called
##              automatically by the constructor. Takes 'verbose' as a
##              flag argument (as described above).
##
##          displayFSM.  Outputs the LR(1) FSM in "pretty-printed" style.
##
##          checkLR1.  Checks to see if the FSM built by 'buildFSM' is
##              in fact, LR(1), that is does not contain any inadequate
##              states. Called automatically by constructor.
##
##          genActions.  Generates the Action table for an LR(1) automaton
##               from its FSM. Called automatically by constructor.
##
##          displayAction.  Displays the Action table associated with
##              this LR(1) automaton in "pretty-printed" tabular style.
##
##          genGoTo.  Generates the GoTo table for an LR(1) automaton
##               from its FSM. Called automatically by constructor.
##
##          displayGoTo.  Displays the GoTo table associated with
##              this LR(1) automaton in "pretty-printed" tabular style.
##
##          parse.  Parses an input string (of simple, single-character
##              terminal symbols) according to the Action and GoTo
##              tables of this LR1Machine.  Displays operation
##              to terminal, showing each step of the parse.
##
##          genDot.  Return a multi-line string containing a description
##              of the LR(1) FSM of this automaton in a form suitable
##              for generating PostScript (and hence PDF) graphs of the
##              CFSM using the 'dot' program.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##
##          outputDot.  Write a GraphViz-format description of the CFSM
##              of this LR(1) automaton to a file (using a call to
##              genDot to do the work).  The output is suitable for
##              processing, via the chain
##                   $ dot -Tps2 <file> | ps2pdf - > <output-pdf>'
##              to generate a pdf of the CFSM graph.  Can also generate
##              Graphviz output suitable for rendering to SVG, see
##              detailed comments with code.
##

class LR1Machine(LRBase):
    "The LR(1) recogniser for a grammar."
    def __init__(this,grammar,verbose=True):
        this.grammar = augmentGrammar(grammar)  ## Note augmentation.
        this.fsm = this.buildFSM(verbose)       ## Build the LR(1) FSM.
        if verbose: print 35*"=="
        if this.checkLR1(verbose):
            this.actionTable = this.genActions()
            this.gotoTable = this.genGoTo()
        else:
            this.actionTable = None
            this.gotoTable = None

    ##----------------------------------------------------------------------
    ##
    ## Build the LR(1) FSM for the grammar. Verbose is a flag controlling 
    ## whether or not to do lots of output to the terminal describing the 
    ## progress of the build. Returns a list of LR1state objects.
    ##
    def buildFSM(this,verbose):
        "Build the LR(1) FSM for the supplied grammar."
        first_sets = fill_first_sets(this.grammar)
        states = [LR1State(this.grammar)]
        states[0].close(first_sets)
        stateQueue = [0]
        while stateQueue != []:
            stateNum = stateQueue.pop(0)
            state = states[stateNum]
            if verbose:
                print "-------------------------------------------------------"
                print "Working with state %d (%s)" % (stateNum, state)
            for sym,itemSet in state.findTransitions().items():
                candidateNewState = LR1State(this.grammar,itemSet)
                candidateNewState.close(first_sets)
                if verbose:
                    s = "   Working with transition on '%s' to { " % sym
                    for targetItem in itemSet:
                        s += "%s" % targetItem
                    s += '}'
                    print "%s\n      Candidate new state is %s" % \
                          (s,candidateNewState)
                isNewState = True
                for i,s in enumerate(states):
                    if candidateNewState.equals(s):
                        isNewState = False
                        state.transitions[sym] = i
                        if verbose:
                            print "            Not new, is existing state %d." % i
                        break
                if isNewState:
                    newStateNumber = len(states)
                    state.transitions[sym] = newStateNumber
                    candidateNewState.close(first_sets)
                    states.append(candidateNewState)
                    stateQueue.append(newStateNumber)
                    if verbose:
                        print "            New, adding as state %d." \
                              % newStateNumber
        return states

    ##----------------------------------------------------------------------
    ##
    ## displayFSM -- output the LR(1) FSM of this automaton in
    ## "pretty-printed" style.
    ##
    def displayFSM(this):
        "Pretty-print the LR(1) Finite State Machine of this automaton."
        for i,lr1state in enumerate(this.fsm):
            print "=====================================\nState %d" % i
            if len(lr1state.items) > 0:
                print "  Items:"
                for item in lr1state.items: print "    %s" % item
            else:
                print "  No items in this state!! ERROR!!"
            if len(lr1state.transitions) > 0:
                print "  Transitions:"
                for (sym,target) in lr1state.transitions.iteritems():
                    print "    '%s' ==> %d" % (sym,target)
            else:
                print "  No transitions out of this state"

    ##----------------------------------------------------------------------
    ##
    ## checkLR1 -- Check to see if the LR(1) FSM is correct, i.e., that
    ##      it contains no inadequate states (i.e., no shift-reduce or
    ##      reduce-reduce conflicts).  Returns True if no inadequate LR(1)
    ##      states are found, False otherwise.  If the automaton contains
    ##      inadequate states, reports on them to the output as well.
    ##
    def checkLR1(this,verbose=False):
        "Check to see if this FSM contains no inadequate states."
        if verbose:
            print "Checking if grammar is LR(1)"
            print "============================"
        status = []
        for stateNum,lr1state in enumerate(this.fsm):
            status.append(lr1state.isAdequate(stateNum,verbose))
        for s in status:
            if not s:
                if verbose: print "It is not LR(1)"
                return False
        if verbose: print "It is LR(1)"
        return True

    ##----------------------------------------------------------------------
    ##
    ## genActions -- Generate the Action table for an LR(1) automaton
    ##               from its FSM.
    ##
    ## Note: Assumes that the grammar has been checked by "checkLR1".  This
    ## happens automatically in the constructor.  What is generated is a
    ## dictionary indexed by (sym,stateNumber) tuples indicating the action
    ## to take with "stateNumber" on the top of the parse stack and lookahead
    ## "sym".  An entry in the dictionary is either 'S' (a shift action),
    ## 'A' (an accept action), or a positive number corresponding to a
    ## production number in the augmented grammar associated with the
    ## machine.  Blank entries in the table are not represented explictly.
    ## 
    ##
    def genActions(this):
        actionTable = dict()
        for stateNum,lr1state in enumerate(this.fsm):
            for item in lr1state.items:
                lookaheadSym = item.getDottedSym()
                if lookaheadSym == 'eps':  ## Dot at right-end => reduction.
                    ## Find index of production to reduce by.
                    for prodNum,prod in enumerate(this.grammar):
                        if prod == item.production: break
                    ## Now iterate over the symbols in the lookahead context.
                    for lookaheadSym in item.lookahead:
                        if lookaheadSym != 'eps':
                            actionTable[(lookaheadSym,stateNum)] = prodNum
                        else:
                            if prodNum == 0: ## Augmenting production
                                actionTable[('$',stateNum)] = 'A'
                            else:
                                print "Error in Action Table construction"
                                print "Lookahead of eps encountered on item %s" %\
                                      item
                                return None
                elif isterminal(lookaheadSym):
                    actionTable[(lookaheadSym,stateNum)] = 'S'
        return actionTable


    ##----------------------------------------------------------------------
    ##
    ## genDot -- Generate a GraphViz format string representing the
    ##           FSM of this LR(1) automaton.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## The argument "includeGrammar" governs whther or node to include
    ## a dummy state in the GraphViz output that contains a list of the
    ## grammar's productions.  This is included in the GrapViz as a
    ## "free-floating" state, i.e., one not connected to anything.
    ##
    ##
    def genDot(this,outputForPS=True,includeGrammar=True):
        s = "digraph lr1fsm {\nrankdir=LR;\n"
        for i,state in enumerate(this.fsm):
            s += state.genDotHtml(i,outputForPS=outputForPS)
            s += "\n"
        if includeGrammar:
            s += "grammar [shape=none, label=<\n%s>];\n" % \
                 genHtmlGrammar(this.grammar,targetPS=outputForPS)
        for i,state in enumerate(this.fsm):
            for ch,target in state.transitions.iteritems():
                s += "%d -> %d [label=\"%s\" fontname=\"Helvetica\""% \
                     (i,target,ch)
                s += " fontcolor=\"#40a040\" fontsize=\"11\"];\n"
        s += "}"
        return s

    ##----------------------------------------------------------------------
    ##
    ## outputDot -- Utility to output a GraphViz representation of the
    ##              CFSM of this LR(0) automaton to a file.  The work is
    ##              done by a call to 'genDot' above, this is just a
    ##              wrapper designed to write the results of 'genDot' to
    ##              a specified file.
    ##
    ## Note the argument "outputForPS".  If this is True (the default) the
    ## GraphViz code generated by this routine will aimed at the '-Tps' or
    ## '-Tps2' modes of "dot" (i.e., using PostScript Symbol fonts to
    ## generate the "read-ahead dot" and arrow symbols).  If False, the
    ## code will be "generic-GraphViz", designed for processing by the
    ## SVG filter (or similar, "-Tsvg").
    ##
    ## 1) Processing chain for default (i.e., GraphViz for PostScript):
    ##
    ## In Python:
    ##
    ##     >>>  lr0g2.outputDot('lr0g2.dot')
    ##
    ## At the shell prompt:
    ##
    ##     $ dot -Tps2 lr0g2.dot > lr0g2.ps
    ##     $ ps2pdf lr0g2.ps
    ##
    ## (or, in one go):
    ##
    ##     $ dot -Tps2 lr0g2.dot | ps2pdf - > lr0g2.pdf
    ##
    ## 2) Processing chain for "generic GraphViz" (i.e., for SVG):
    ##
    ## In Python:
    ##
    ##     >>>  lr0g2.outputDot('lr0g2.dot',outputForPS=False)
    ##
    ## At the shell prompt:
    ##
    ##     $ dot -Tsvg lr0g2.dot > lr0g2.svg
    ##
    def outputDot(this,filename,outputForPS=True,includeGrammar=True):
        f = open(filename,"w")
        print >>f,this.genDot(outputForPS)
        f.close()

    
    ##----------------------------------------------------------------------
    ##
    ## The following methods of this class are utilites needed by routines
    ## from LRBase, and are not designed to be called directly.
    ##
    ##----------------------------------------------------------------------
    ##
    ## rejectMessage --  Returns a reject message suitable to a Reject
    ##                   action comming back from the Action table. This 
    ##                   should never happen in a proper LR(0) parse, so
    ## is an error (an LR(0) parse will pick up on illegal input when it
    ## looks at the GoTo table).  For an SLR parse, on the other hand,
    ## rejects in the Action table represent perfectly normal behaviour
    ## on illegal input, so we have this trivial method to allow for
    ## differentiated reporting. Ditto for an LALR(1) machine.
    ##
    def rejectMessage(this):
        return "Reject"

    ##----------------------------------------------------------------------
    ##
    ## getFSMStateCount --  Returns a count of the number of states in this
    ##                      machine.
    ##
    def getFSMStateCount(this):
        if this.fsm:
            return len(this.fsm)
        else:
            return 0

    ##----------------------------------------------------------------------
    ##
    ## getFSM --  Returns the FSM of the current machine (a list of LR(1)
    ##            states).
    ##
    def getFSM(this):
        if this.fsm:
            return this.fsm
        else:
            return None

    ##----------------------------------------------------------------------


##==============================================================================
##==============================================================================
##==============================================================================
##
## Debugging
## 
##
##
##from grammars import *
##print "G1 = ", G1
##print "G2 = ", G2
##print "G3 = ", G3
##print "G4 = ", G4
##print "G5 = ", G5
##
##lr1g1=LR1Machine(G1,False)
##lr1g2=LR1Machine(G2,False)
##lr1g3=LR1Machine(G3,False)
##lr1g4=LR1Machine(G4,False)
##lr1g5=LR1Machine(G5,False)
##
##print "lr1g1 = ", lr1g1
##print "lr1g2 = ", lr1g2
##print "lr1g3 = ", lr1g3
##print "lr1g4 = ", lr1g4
##print "lr1g5 = ", lr1g5


