##==============================================================================
##
## class LR1Item    Represents an LR(1) Item.  This is a dotted production
##                  with a specific lookahead context.
##
## Fields:
##
##     production:   The Production object this Item is associated with.
##     dotPosition:  The position of the dot in the RHS of the production.
##     lookahead:    The LR(1) lookahead context associated with this Item.
##
## Methods:
##
##     __init__:      Generate a new Item with dot position = 0.  If no
##                    lookahead context is supplied, default to the null set.
##     __repr__:      Generate a pretty-printed representation of this Item.
##     __eq__:        Compare this Item with another one, return True if the
##                    two Items refer to the same Production object, have
##                    dots in identical positions and have the same lookahead
##                    contexts.
##     hasSameCore:   Compare this Item with another one, returning True if
##                    they refer to the same Production object and have dots
##                    in identical positions.  Note that their lookeahead
##                    contexts do not have to be the same.  The name comes
##                    from regarding the production and dot as the "core" of
##                    the LR1Item (since this is what is in an LR(0) Item).
##     advanceDot:    Advance the dot in this Item, generating a new Item with
##                    the dot advanced, but sharing the same Production and
##                    lookahead context as this one.  Note that the current
##                    Item is not changed.
##     getDottedSym:  Return the symbol immediately to the right of the dot
##                    in this Item.  If the dot is at the right-hand-end of the
##                    Item, return 'eps'.
##     close:         Close this Item, returning a list of new Items
##                    representing the LR(1) closure of this one. Note, needs
##                    the grammar and a dictionary of the first sets of the
##                    terminal and nonterminal symbols of the grammar to be
##                    passed as parameters to it.
##
##     gen_lookahead: This static method generates a new lookahead context
##                    appropriate for the closure of an Item.
##
##     formatAsHtml:  This method generates a string representing this
##                    LR1Item in a "dot-HTML" format suitable for processing
##                    by one of the Graphviz programs (e.g., "dot", "neato").
##
from defs import isnonterminal

class LR1Item(object):
    "An LR(1) Item is a dotted production with a lookahead context."
    def __init__(self,production,lookahead=None):
        self.production = production
        self.dotPosition = 0
        if lookahead:
            self.lookahead = lookahead
        else:
            self.lookahead = set()

    def __repr__(self):
        DOT = ' _'
        s = '[%s -->' % self.production.lhs
        if len(self.production.rhs) == 0: s += ' eps'
        for pos,sym in enumerate(self.production.rhs):
            if pos == self.dotPosition: s += DOT
            s += ' %s' % sym
        if self.dotPosition == len(self.production.rhs): s += DOT
        s += ', {'
        for terminal in self.lookahead: s += ' %s' % terminal
        s += ' }]'
        return s

    def __eq__(self,item):
        "Test if two LR(1) Items are identical."
        if self.production == item.production and \
           self.dotPosition == item.dotPosition and \
           len(self.lookahead.symmetric_difference(item.lookahead)) == 0:
            return True
        else:
            return False

    def __ne__(self,item):
        return not self.__eq__(item)
    
    def hasSameCore(self,item):
        "Test if two LR(1) items share the same production and dot position."
        return self.production == item.production and \
               self.dotPosition == item.dotPosition
        
    ##------------------------------------------------------------------------------
    ##
    ## advanceDot - Advance the dot one position to the right in an LR(1) item,
    ## returning a new LR(1) item representing the result of the advance.
    ##
    ## N.B., if the dot is already at the end of the rhs of the item, simply
    ## return an exact copy of this item, as no advance is possible in this
    ## case.
    ##
    def advanceDot(self):
        newItem = LR1Item(self.production,self.lookahead)
        dotPos = self.dotPosition
        if dotPos < len(self.production.rhs): dotPos += 1
        newItem.dotPosition = dotPos
        return newItem
       
    ##------------------------------------------------------------------------------
    ##
    ## getDottedSym - Return the symbol immediately to the right of the dot in
    ## an item.  If the dot is at the end of an item, return 'eps' as a marker
    ## for the null string (i.e., there is no real symbol avaiable).
    ##
    def getDottedSym(self):
        "Return the symbol immediately to the right of the dot."
        if self.dotPosition == len(self.production.rhs): sym = 'eps'
        else: sym = self.production.rhs[self.dotPosition]
        return sym

    ##------------------------------------------------------------------------------
    ##
    ## close - Return a list of new LR(1) items that are the
    ## closure of the current item. "first_sets" is a dictionary indexed by
    ## symbol that contains the first sets for all the terminals and
    ## nonterminals in the grammar.
    ## 
    ##
    def close(self,grammar,first_sets):
        "Generate a list of new items that are the LR(1) closure of this one."
        closure = []
        sym = self.getDottedSym()
        if isnonterminal(sym):
            lookahead_context = LR1Item.gen_lookahead(\
                self.production.rhs[self.dotPosition+1:],\
                first_sets,self.lookahead)
            for prod in grammar:
                if prod.lhs == sym:
                    closure.append(LR1Item(prod,lookahead_context))
        return closure
                                                   
    ##------------------------------------------------------------------------------
    ##
    ## gen_lookahead - Generate the lookahead context for items being generated
    ## from the closure of a nonterminal symbol. Note that this is a static
    ## method, as it does not need any context from a particular LR1Item object.
    ##
    ## Arguments:
    ##
    ## sentential_form: a list of symbols (i.e., strings) representing the
    ##     "tail" of the sentential form following the symbol that is involved
    ##      in the closure operation.
    ##
    ## first_sets: a dictionary indexed by symbol containing the first sets
    ##     of all the terminal and nonterminal symbols in the grammar.
    ##
    ## lookahead: a set representing the "current lookahead context", i.e.
    ##     the lookahead context of the item being closed.
    ##
    @staticmethod
    def gen_lookahead(sentential_form,first_sets,lookahead):
        new_lookahead_context = set(['eps'])
        i = 0
        while 'eps' in new_lookahead_context:
            new_lookahead_context.remove('eps')
            if i == len(sentential_form):
                new_lookahead_context.update(lookahead)
                break
            else:
                new_lookahead_context.update(first_sets[sentential_form[i]])
                i += 1
        return new_lookahead_context                                                   


    ##------------------------------------------------------------------------------
    ##
    ## formatAsHtml - Return a representation of the item as an HTML-formatted
    ## string suitable for display in a Graphviz (i.e., DOT) representation.
    ##
    ## Note the parameter 'outputForPS'.  If this is True (the default), then
    ## this routine outputs HTML for the item that is optimised to be processed
    ## by the '-Tps' or '-Tps2' modes of the "dot" program.  This means that
    ## explicit switches are made into the 'Symbol' font by the HTML in order
    ## to display the "read-head dot" symbol and the "right arrow" symbol.
    ##
    ## If the parameter is False, then the code uses the Unicode "bull"
    ## character (code #8226) for the "read-ahead dot" and the Unicode
    ## "rarr" character (code #8594) for the "right arrow", along with the
    ## Unicode "epsilon" character (code #949) for epsilon, and omits explicit
    ## calls to switch into the 'Symbol' font.  The PostScript drivers in
    ## Graphviz unfortunately do not understand this cleaner HTML.  The
    ## SVG driver (-Tsvg), amongst others, does, but doesn't understand the
    ## explicit switches into the 'Symbol' font, and messes up its output
    ## if it sees these (n.b., unfortunately, the SVG driver doesn't
    ## understand the HTML names, &epsilon;, &rarr; and &bull;, so we
    ## need explicit character codes in this case too).
    ##
    ## Hence the need for the 'outputForPS' parameter, it's a workaround
    ## for the shortcomings of the Graphviz HTML parsers.
    ##
    ##
    def formatAsHtml(self,colour,outputForPS=True):
        "Generate an HTML representation of an item (as part of a table)."
        DOT = '<font color="purple"'
        if outputForPS: DOT += ' face="Symbol">&#183;</font>' ## 183 is a filled circle in Symbol.
        else: DOT += '>&#8226;</font>'  ## SVG driver doesn't understand HTML &bull;, so need code.
        ## Output the LHS of the Item. Note the check for < > brackets.
        if self.production.lhs[0] == '<':  lhs = ('&lt;%s&gt;' % self.production.lhs[1:-1])
        else: lhs = self.production.lhs
        s =  '    <td align="right"><font face="Times-Italic"'
        s += ' color="%s" point-size="10">%s</font></td>\n' % (colour,lhs)
        ## Output the arrow '-->' according to whether this is for PS or SVG.
        s += '    <td align="center"><font color="%s" point-size="12"' % colour
        if outputForPS: s += ' face="Symbol">&#174;' ## 174 is a right-arrow in the Symbol font.
        else: s += '>&#8594;'  ## SVG driver doesn't understand HTML &rarr;, so need code.
        ## Output the RHS of the Item.  Note the special handling of the \eps Item.
        s += '&#32;</font></td>\n    <td align="left">'
        l = len(self.production.rhs)
        if l == 0:  ## Item has an empty RHS, special handling of the dot.
            s += '<font point-size="10" color="%s"' % colour
            if outputForPS: s += ' face="Symbol">e'
            else: s += '>&#949;'  ## SVG driver doesn't understand HTML &epsilon;, so need code.
            s += DOT
        else:  ## Non-empty RHS, walk over the elements.
            s += '<font face="Times-Italic" color="%s" point-size="10">' % colour
            for i in range(l):
                if i == self.dotPosition: s += DOT  ## Insert the dot.
                element = self.production.rhs[i]
                ## Note special handing of < > brackets.
                if element[0] == '<':  s += ('&lt;%s&gt;' % element[1:-1])
                else: s += '%s' % element
            if self.dotPosition >= l: s += DOT
        s += '</font></td>\n'
        return s

##----------------------------------------------------------------------
